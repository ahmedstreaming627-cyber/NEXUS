# NEXUS - PowerShell Windows Launcher
$Host.UI.RawUI.WindowTitle = "NEXUS Desktop Launcher"
Write-Host "===================================================================" -ForegroundColor Green
Write-Host "    NEXUS - Next-Gen Cross-Platform Communication Platform" -ForegroundColor Green
Write-Host "===================================================================" -ForegroundColor Green
Write-Host ""

Set-Location -LiteralPath $PSScriptRoot

if (-not (Test-Path "package.json")) {
    Write-Host "[!] ZIP file was not extracted yet!" -ForegroundColor Red
    Write-Host "Please extract nexus-windows-app.zip to a folder first." -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit
}

$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) {
    Write-Host "[!] Node.js not found on this PC." -ForegroundColor Red
    Write-Host "Please install Node.js from https://nodejs.org" -ForegroundColor Yellow
    $ans = Read-Host "Open https://nodejs.org now? (Y/N)"
    if ($ans -eq 'Y' -or $ans -eq 'y') {
        Start-Process "https://nodejs.org"
    }
    Read-Host "Press Enter to exit"
    exit
}

Write-Host "[*] Node.js is ready: $(node -v)" -ForegroundColor Green

if (-not (Test-Path "node_modules\express")) {
    Write-Host "[*] Installing dependencies..." -ForegroundColor Cyan
    npm install --legacy-peer-deps
}

Write-Host ""
Write-Host "[SUCCESS] Starting server at http://localhost:3000..." -ForegroundColor Green
Start-Process "http://localhost:3000"

if (Test-Path "server.js") {
    node server.js
} else {
    npm run dev
}

Read-Host "Server stopped. Press Enter to exit"
