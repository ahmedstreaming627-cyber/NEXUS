===================================================================
  NEXUS - Next-Gen Cross-Platform Communication Platform
  Windows Quick-Start Guide (1-Click Run)
===================================================================

REQUIREMENTS:
- Windows 10 or Windows 11
- Node.js 18, 20, or 22 installed (Download from https://nodejs.org if needed)

HOW TO RUN ON WINDOWS:

OPTION 1: THE EASIEST 1-CLICK METHOD
1. Double-click "run-windows.bat"
2. It will automatically check Node.js, install dependencies cleanly, and launch the server.
3. Open your browser and go to:
   http://localhost:3000

OPTION 2: COMMAND LINE (MANUAL)
1. Open Command Prompt or PowerShell in this folder.
2. Run:
   npm install --legacy-peer-deps
3. Start the server:
   npm run dev
4. Open your browser at:
   http://localhost:3000

HOW TO RUN THE NATIVE WINDOWS DESKTOP APP (ELECTRON):
1. Keep the server running in your first terminal.
2. Double-click "run-desktop-electron.bat"
   OR in a second terminal run:
   npm run electron:start

HOW P2P (PEER-TO-PEER) WORKS:
- Voice Calls: In any DM or Friend view, click the Phone icon.
- Video Calls: In any DM or Friend view, click the Camera icon.
- Community Voice Lounges: Click "Neural Lounge" in any community server.
- Screen Sharing: Click the Screen Share (Monitor) button during any call.
- P2P Diagnostics: Click the "P2P WebRTC Mesh" badge in the title bar
  to run live loopback tests, STUN server checks, latency pings, and ICE stats!

CUSTOMIZING PROFILE & THEMES:
- Avatar & Banner: Open Settings (Gear icon) -> "My Account".
  Click "Upload from Device" to upload any photo and use the circular Discord-like
  crop tool to move/scale your avatar, or upload an animated GIF banner/avatar!
- Theme Presets: Open Settings -> "Themes & Presets".
  Click any preset (Neon Green, Electric Cyan, Synthwave Violet, Crimson, Amber, Slate)
  to instantly transform the entire app interface.
===================================================================
