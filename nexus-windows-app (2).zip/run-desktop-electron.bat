@echo off
setlocal enabledelayedexpansion
title NEXUS Native Windows Desktop Client (Electron)
color 0B
cd /d "%~dp0"

echo ===================================================================
echo     Launching NEXUS Native Windows Desktop Client (Electron)
echo ===================================================================
echo.
echo Checking if server is running...
echo.

call npm run electron:start

echo.
echo Desktop window closed.
pause
