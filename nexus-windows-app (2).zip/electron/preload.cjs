const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('nexusDesktop', {
  isElectron: true,
  platform: 'desktop-windows',
  minimize: () => ipcRenderer.send('window:minimize'),
  maximize: () => ipcRenderer.send('window:maximize'),
  close: () => ipcRenderer.send('window:close'),
  isMaximized: () => ipcRenderer.invoke('window:is-maximized'),
  getScreenSources: () => ipcRenderer.invoke('desktop:get-sources'),
  showNotification: (title, body) => ipcRenderer.send('desktop:notify', { title, body }),
  onWindowStateChange: (callback) => {
    ipcRenderer.on('window:state-changed', (event, data) => callback(data));
  }
});
