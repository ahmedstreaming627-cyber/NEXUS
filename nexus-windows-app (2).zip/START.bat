@echo off
:: START.bat - Keeps command prompt open unconditionally using cmd /k
cd /d "%~dp0"
cmd /k "%~dp0run-windows.bat"
