import zlib
import struct
import os
import math

def create_png(width, height, filename):
    # Create raw RGBA image data
    raw_data = bytearray()
    
    cx, cy = width / 2.0, height / 2.0
    r_outer = width * 0.44
    r_inner = width * 0.36
    
    for y in range(height):
        raw_data.append(0) # filter byte (None)
        for x in range(width):
            dx = x - cx
            dy = y - cy
            dist = math.hypot(dx, dy)
            
            # Background: dark slate #0b0e14 -> (11, 14, 20)
            # Outer ring: neon green #00ff87 -> (0, 255, 135)
            # Center letter 'N' or hexagon
            if dist < r_outer:
                # Inside circle
                if dist > r_inner:
                    # Neon cyan-green border
                    raw_data.extend((0, 255, 135, 255))
                else:
                    # Inner dark background
                    # Draw a stylized 'N'
                    nx = (x - cx) / (width * 0.25)
                    ny = (y - cy) / (height * 0.25)
                    
                    is_n = False
                    # Left vertical bar of N
                    if -0.7 <= nx <= -0.3 and -0.7 <= ny <= 0.7:
                        is_n = True
                    # Right vertical bar of N
                    elif 0.3 <= nx <= 0.7 and -0.7 <= ny <= 0.7:
                        is_n = True
                    # Diagonal bar of N
                    elif -0.5 <= nx <= 0.5 and abs(ny - nx) <= 0.3:
                        is_n = True
                        
                    if is_n:
                        raw_data.extend((0, 255, 135, 255))
                    else:
                        raw_data.extend((11, 14, 20, 255))
            else:
                # Outside circle
                raw_data.extend((11, 14, 20, 255))
                
    # PNG format
    png = bytearray(b'\x89PNG\r\n\x1a\n')
    
    # IHDR
    ihdr_data = struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)
    ihdr_crc = zlib.crc32(b'IHDR' + ihdr_data)
    png.extend(struct.pack('>I', len(ihdr_data)))
    png.extend(b'IHDR')
    png.extend(ihdr_data)
    png.extend(struct.pack('>I', ihdr_crc))
    
    # IDAT
    compressed = zlib.compress(bytes(raw_data), 9)
    idat_crc = zlib.crc32(b'IDAT' + compressed)
    png.extend(struct.pack('>I', len(compressed)))
    png.extend(b'IDAT')
    png.extend(compressed)
    png.extend(struct.pack('>I', idat_crc))
    
    # IEND
    iend_crc = zlib.crc32(b'IEND')
    png.extend(struct.pack('>I', 0))
    png.extend(b'IEND')
    png.extend(struct.pack('>I', iend_crc))
    
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, 'wb') as f:
        f.write(png)
    print(f"Created {filename} ({len(png)} bytes)")

if __name__ == '__main__':
    create_png(192, 192, 'public/icon-192.png')
    create_png(512, 512, 'public/icon-512.png')
