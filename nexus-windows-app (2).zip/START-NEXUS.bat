@echo off
title NEXUS Launcher
cd /d "%~dp0"

echo ===================================================================
echo   NEXUS - High-Speed Launcher
echo ===================================================================
echo.
echo [*] Opening NEXUS in your browser at http://localhost:3000 ...
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:3000"

if exist "%~dp0server.js" (
    echo [*] Starting instant server engine...
    node "%~dp0server.js"
) else (
    echo [*] Starting server...
    call npm run dev
)

echo.
echo Server closed.
pause
