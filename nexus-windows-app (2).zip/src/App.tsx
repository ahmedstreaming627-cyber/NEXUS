import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ChatProvider, useChat } from './context/ChatContext';
import { CallProvider } from './context/CallContext';

import { TitleBar } from './components/layout/TitleBar';
import { ServerBar } from './components/layout/ServerBar';
import { ChannelBar } from './components/layout/ChannelBar';
import { ChatArea } from './components/chat/ChatArea';
import { FriendsView } from './components/friends/FriendsView';
import { CallOverlay } from './components/call/CallOverlay';
import { AuthScreen } from './components/auth/AuthScreen';
import { SettingsModal } from './components/settings/SettingsModal';
import {
  CreateCommunityModal,
  JoinCommunityModal,
  CreateChannelModal
} from './components/communities/CommunityModals';
import { DownloadZipModal } from './components/desktop/DownloadZipModal';
import { P2PDiagnosticsModal } from './components/call/P2PDiagnosticsModal';

const MainLayout: React.FC = () => {
  const { user, isLoading, isDesktopMode } = useAuth();
  const { activeView } = useChat();

  const [showSettings, setShowSettings] = useState(false);
  const [showCreateCommunity, setShowCreateCommunity] = useState(false);
  const [showJoinCommunity, setShowJoinCommunity] = useState(false);
  const [showCreateChannel, setShowCreateChannel] = useState(false);
  const [showDownloadZip, setShowDownloadZip] = useState(false);
  const [showP2PModal, setShowP2PModal] = useState(false);

  if (isLoading) {
    return (
      <div
        className="h-screen w-screen flex flex-col items-center justify-center space-y-4 select-none"
        style={{ backgroundColor: 'var(--nexus-bg-base)' }}
      >
        <div
          className="w-16 h-16 rounded-2xl flex items-center justify-center font-black text-black text-2xl animate-pulse shadow-lg"
          style={{
            backgroundColor: 'var(--nexus-accent)',
            boxShadow: `0 0 30px var(--nexus-accent-glow)`
          }}
        >
          N
        </div>
        <div className="text-slate-400 font-mono text-xs tracking-widest uppercase">
          CONNECTING TO NEXUS NEURAL GRID...
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthScreen />;
  }

  return (
    <div
      className="h-screen w-screen flex flex-col overflow-hidden transition-colors duration-200"
      style={{
        backgroundColor: 'var(--nexus-bg-base)',
        border: isDesktopMode ? '1px solid var(--nexus-border)' : 'none'
      }}
    >
      {/* Top Title Bar (Windows Native or Web Titlebar) */}
      <TitleBar
        onOpenDownloadModal={() => setShowDownloadZip(true)}
        onOpenP2PModal={() => setShowP2PModal(true)}
      />

      {/* Main Workspace Frame */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Server / Guild Navigation */}
        <ServerBar
          onOpenCreateCommunity={() => setShowCreateCommunity(true)}
          onOpenJoinCommunity={() => setShowJoinCommunity(true)}
        />

        {/* Channels & DM Conversation List */}
        <ChannelBar
          onOpenSettings={() => setShowSettings(true)}
          onOpenCreateChannel={() => setShowCreateChannel(true)}
        />

        {/* Central Active View */}
        {activeView === 'friends' ? (
          <FriendsView />
        ) : (
          <ChatArea />
        )}
      </div>

      {/* WebRTC Video & Voice Call Screen Overlay */}
      <CallOverlay />

      {/* Modals */}
      <SettingsModal
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        onOpenDownloadModal={() => setShowDownloadZip(true)}
      />

      <CreateCommunityModal
        isOpen={showCreateCommunity}
        onClose={() => setShowCreateCommunity(false)}
      />

      <JoinCommunityModal
        isOpen={showJoinCommunity}
        onClose={() => setShowJoinCommunity(false)}
      />

      <CreateChannelModal
        isOpen={showCreateChannel}
        onClose={() => setShowCreateChannel(false)}
      />

      <DownloadZipModal
        isOpen={showDownloadZip}
        onClose={() => setShowDownloadZip(false)}
      />

      <P2PDiagnosticsModal
        isOpen={showP2PModal}
        onClose={() => setShowP2PModal(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <ChatProvider>
        <CallProvider>
          <MainLayout />
        </CallProvider>
      </ChatProvider>
    </AuthProvider>
  );
}
