import React, { useRef, useEffect } from 'react';
import { useCall } from '../../context/CallContext';
import {
  Phone,
  PhoneOff,
  Video,
  VideoOff,
  Mic,
  MicOff,
  Monitor,
  Maximize2,
  Volume2,
  Sparkles,
  Radio
} from 'lucide-react';

export const CallOverlay: React.FC = () => {
  const {
    activeCall,
    incomingCall,
    acceptCall,
    rejectCall,
    endCall,
    localStream,
    remoteStream,
    isMuted,
    isCameraOff,
    isScreenSharing,
    toggleMute,
    toggleCamera,
    toggleScreenShare
  } = useCall();

  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);

  // Bind local stream
  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  // Bind remote stream
  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);

  // 1. Incoming Call Dialog
  if (incomingCall) {
    return (
      <div className="fixed inset-0 bg-black/70 backdrop-blur-md flex items-center justify-center p-4 z-50 select-none animate-in fade-in duration-200">
        <div className="bg-[#0f1422] border border-[#00ff87]/40 rounded-2xl p-6 max-w-sm w-full text-center shadow-[0_0_40px_rgba(0,255,135,0.25)] space-y-4">
          <div className="relative inline-block">
            <div className="w-20 h-20 rounded-full border-2 border-[#00ff87] overflow-hidden mx-auto shadow-[0_0_20px_#00ff87]">
              <img
                src={incomingCall.caller.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80'}
                alt={incomingCall.caller.displayName}
                className="w-full h-full object-cover"
              />
            </div>
            <span className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[#00ff87] flex items-center justify-center text-black">
              {incomingCall.callType === 'video' ? <Video className="w-3.5 h-3.5" /> : <Phone className="w-3.5 h-3.5" />}
            </span>
          </div>

          <div>
            <h3 className="text-base font-bold text-white font-mono">
              {incomingCall.caller.displayName}
            </h3>
            <p className="text-xs text-[#00ff87] font-mono mt-0.5 animate-pulse">
              Incoming {incomingCall.callType === 'video' ? 'Video & Screen' : 'Voice'} Transmission...
            </p>
          </div>

          <div className="flex items-center justify-center space-x-4 pt-2">
            <button
              onClick={rejectCall}
              className="flex-1 py-2.5 px-4 rounded-xl bg-red-600/20 text-red-400 border border-red-500/30 hover:bg-red-600 hover:text-white transition-all font-mono text-xs font-bold flex items-center justify-center space-x-1.5"
            >
              <PhoneOff className="w-4 h-4" />
              <span>Decline</span>
            </button>

            <button
              onClick={acceptCall}
              className="flex-1 py-2.5 px-4 rounded-xl bg-[#00ff87] text-black hover:bg-[#00df76] transition-all font-mono text-xs font-bold flex items-center justify-center space-x-1.5 shadow-[0_0_15px_rgba(0,255,135,0.4)]"
            >
              <Phone className="w-4 h-4" />
              <span>Accept</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 2. Active Call Window
  if (!activeCall) return null;

  const isVideoCall = activeCall.type === 'video' || isScreenSharing;

  return (
    <div className="fixed inset-0 bg-[#07090e]/95 backdrop-blur-lg flex flex-col z-50 select-none">
      {/* Top Header */}
      <div className="h-14 border-b border-[#151c2a] px-6 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-3 h-3 rounded-full bg-[#00ff87] animate-pulse shadow-[0_0_8px_#00ff87]" />
          <div>
            <span className="font-bold text-sm text-slate-100 font-mono">
              Transmission with {activeCall.targetUser.displayName}
            </span>
            <span className="text-xs text-slate-400 font-mono ml-2">
              {activeCall.isConnected ? 'Connected · 100% Signal' : 'Establishing WebRTC Peer Signaling...'}
            </span>
          </div>
        </div>

        {isScreenSharing && (
          <div className="flex items-center space-x-1.5 px-3 py-1 rounded-full bg-[#00e5ff]/20 text-[#00e5ff] text-xs font-mono border border-[#00e5ff]/40">
            <Monitor className="w-3.5 h-3.5" />
            <span>Screen Sharing Transmitting</span>
          </div>
        )}
      </div>

      {/* Media Feed Area */}
      <div className="flex-1 p-6 flex items-center justify-center relative overflow-hidden">
        {isVideoCall ? (
          <div className="w-full h-full max-w-5xl rounded-2xl bg-[#0e1320] border border-[#1b253b] relative overflow-hidden flex items-center justify-center shadow-2xl">
            {/* Remote Video Stream (Full) */}
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className="w-full h-full object-contain"
            />

            {/* Fallback if remote stream has no video yet */}
            {(!remoteStream || remoteStream.getVideoTracks().length === 0) && (
              <div className="absolute inset-0 flex flex-col items-center justify-center space-y-3 bg-[#0d121c]">
                <div className="w-24 h-24 rounded-full border-2 border-[#00ff87]/50 overflow-hidden shadow-[0_0_20px_rgba(0,255,135,0.2)]">
                  <img
                    src={activeCall.targetUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80'}
                    alt="Remote User"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="text-sm font-bold text-slate-200 font-mono">
                  {activeCall.targetUser.displayName}
                </div>
                <div className="text-xs text-[#00ff87] font-mono animate-pulse">
                  {activeCall.isConnected ? 'Voice active · Waiting for remote camera/screen' : 'Ringing...'}
                </div>
              </div>
            )}

            {/* Picture-in-Picture Local Stream */}
            <div className="absolute bottom-4 right-4 w-48 h-32 rounded-xl bg-black border border-[#00ff87]/40 shadow-xl overflow-hidden z-10">
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-1 left-2 text-[10px] font-mono text-[#00ff87] bg-black/60 px-1 rounded">
                You
              </div>
            </div>
          </div>
        ) : (
          // Voice Only Layout
          <div className="flex flex-col items-center justify-center space-y-6">
            <div className="relative">
              <div className="w-32 h-32 rounded-full border-4 border-[#00ff87] overflow-hidden shadow-[0_0_35px_rgba(0,255,135,0.35)]">
                <img
                  src={activeCall.targetUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80'}
                  alt={activeCall.targetUser.displayName}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -inset-4 rounded-full border border-[#00ff87]/20 animate-ping pointer-events-none" />
            </div>

            <div className="text-center space-y-1">
              <h2 className="text-xl font-bold text-white font-mono">
                {activeCall.targetUser.displayName}
              </h2>
              <p className="text-xs text-[#00ff87] font-mono animate-pulse">
                {activeCall.isConnected ? 'Spatial Audio Active' : 'Ringing peer...'}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Floating Control Bar */}
      <div className="h-20 border-t border-[#151c2a] flex items-center justify-center space-x-3 bg-[#0a0d14]/90 backdrop-blur px-4">
        {/* Mute Mic */}
        <button
          onClick={toggleMute}
          className={`p-3.5 rounded-full transition-all border ${
            isMuted
              ? 'bg-red-500/20 border-red-500/40 text-red-400 hover:bg-red-500/30'
              : 'bg-[#151c2b] border-[#1e2a40] text-slate-200 hover:text-[#00ff87] hover:border-[#00ff87]/50'
          }`}
          title={isMuted ? 'Unmute' : 'Mute'}
        >
          {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>

        {/* Toggle Camera */}
        <button
          onClick={toggleCamera}
          className={`p-3.5 rounded-full transition-all border ${
            isCameraOff
              ? 'bg-red-500/20 border-red-500/40 text-red-400 hover:bg-red-500/30'
              : 'bg-[#151c2b] border-[#1e2a40] text-slate-200 hover:text-[#00e5ff] hover:border-[#00e5ff]/50'
          }`}
          title={isCameraOff ? 'Enable Camera' : 'Disable Camera'}
        >
          {isCameraOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
        </button>

        {/* Screen Share */}
        <button
          onClick={toggleScreenShare}
          className={`p-3.5 rounded-full transition-all border ${
            isScreenSharing
              ? 'bg-[#00e5ff]/20 border-[#00e5ff] text-[#00e5ff] shadow-[0_0_15px_rgba(0,229,255,0.4)]'
              : 'bg-[#151c2b] border-[#1e2a40] text-slate-200 hover:text-[#00e5ff] hover:border-[#00e5ff]/50'
          }`}
          title={isScreenSharing ? 'Stop Screen Sharing' : 'Share Screen (WebRTC Capture)'}
        >
          <Monitor className="w-5 h-5" />
        </button>

        {/* End Call Button */}
        <button
          onClick={endCall}
          className="p-3.5 rounded-full bg-red-600 hover:bg-red-500 text-white shadow-[0_0_20px_rgba(239,68,68,0.5)] transition-all"
          title="Disconnect Transmission"
        >
          <PhoneOff className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
