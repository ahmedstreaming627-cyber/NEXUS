import React, { useState } from 'react';
import { useChat } from '../../context/ChatContext';
import { X, Hash, Volume2, Plus, Compass } from 'lucide-react';

interface CreateCommunityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreateCommunityModal: React.FC<CreateCommunityModalProps> = ({ isOpen, onClose }) => {
  const { createCommunity } = useChat();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [iconUrl, setIconUrl] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setIsSubmitting(true);
    setError('');
    try {
      await createCommunity(name.trim(), description.trim(), iconUrl.trim() || undefined);
      setName('');
      setDescription('');
      setIconUrl('');
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to create community');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 z-50 select-none">
      <div className="bg-[#0f1422] border border-[#1b253b] rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white uppercase tracking-wider font-mono">
            CREATE COMMUNITY NODE
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-mono text-slate-400 mb-1">
              COMMUNITY NAME *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Cyber Syndicate"
              className="w-full bg-[#141b2b] border border-[#202c42] rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-[#00ff87]/50 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-400 mb-1">
              DESCRIPTION
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What is this community node about?"
              className="w-full bg-[#141b2b] border border-[#202c42] rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-[#00ff87]/50 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-400 mb-1">
              ICON IMAGE URL (OPTIONAL)
            </label>
            <input
              type="url"
              value={iconUrl}
              onChange={(e) => setIconUrl(e.target.value)}
              placeholder="https://images.unsplash.com/..."
              className="w-full bg-[#141b2b] border border-[#202c42] rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-[#00ff87]/50 font-mono"
            />
          </div>

          {error && (
            <div className="text-xs text-red-400 font-mono bg-red-500/10 p-2 rounded border border-red-500/20">
              {error}
            </div>
          )}

          <div className="flex items-center justify-end space-x-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-mono text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!name.trim() || isSubmitting}
              className="px-5 py-2 rounded-xl bg-[#00ff87] text-black font-bold text-xs font-mono hover:bg-[#00df76] disabled:opacity-40 transition-all shadow-[0_0_15px_rgba(0,255,135,0.3)]"
            >
              {isSubmitting ? 'Initializing...' : 'Create Community'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface JoinCommunityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const JoinCommunityModal: React.FC<JoinCommunityModalProps> = ({ isOpen, onClose }) => {
  const { joinCommunity } = useChat();
  const [inviteCode, setInviteCode] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteCode.trim()) return;

    setIsSubmitting(true);
    setError('');
    try {
      await joinCommunity(inviteCode.trim());
      setInviteCode('');
      onClose();
    } catch (err: any) {
      setError(err.message || 'Invalid or expired invite code');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 z-50 select-none">
      <div className="bg-[#0f1422] border border-[#1b253b] rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white uppercase tracking-wider font-mono flex items-center space-x-2">
            <Compass className="w-4 h-4 text-[#00e5ff]" />
            <span>JOIN A COMMUNITY NODE</span>
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-slate-400">
          Enter an invite code below to link your client to an existing community node (e.g. <code className="text-[#00ff87]">NEXUS-01</code>).
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-mono text-slate-400 mb-1">
              INVITE CODE *
            </label>
            <input
              type="text"
              required
              value={inviteCode}
              onChange={(e) => setInviteCode(e.target.value)}
              placeholder="e.g. NEXUS-01"
              className="w-full bg-[#141b2b] border border-[#202c42] rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-[#00e5ff]/50 font-mono uppercase"
            />
          </div>

          {error && (
            <div className="text-xs text-red-400 font-mono bg-red-500/10 p-2 rounded border border-red-500/20">
              {error}
            </div>
          )}

          <div className="flex items-center justify-end space-x-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-mono text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!inviteCode.trim() || isSubmitting}
              className="px-5 py-2 rounded-xl bg-[#00e5ff] text-black font-bold text-xs font-mono hover:bg-[#00c4dc] disabled:opacity-40 transition-all shadow-[0_0_15px_rgba(0,229,255,0.3)]"
            >
              {isSubmitting ? 'Joining...' : 'Join Node'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface CreateChannelModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreateChannelModal: React.FC<CreateChannelModalProps> = ({ isOpen, onClose }) => {
  const { createChannel } = useChat();
  const [name, setName] = useState('');
  const [topic, setTopic] = useState('');
  const [type, setType] = useState<'text' | 'voice'>('text');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setIsSubmitting(true);
    setError('');
    try {
      await createChannel(name.trim(), type, topic.trim());
      setName('');
      setTopic('');
      setType('text');
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to create channel');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 z-50 select-none">
      <div className="bg-[#0f1422] border border-[#1b253b] rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white uppercase tracking-wider font-mono">
            CREATE TRANSMISSION CHANNEL
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Channel Type Picker */}
          <div>
            <label className="block text-xs font-mono text-slate-400 mb-2">
              CHANNEL TYPE
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setType('text')}
                className={`p-3 rounded-xl border flex items-center space-x-3 text-left transition-all ${
                  type === 'text'
                    ? 'bg-[#00ff87]/15 border-[#00ff87] text-[#00ff87]'
                    : 'bg-[#141b2b] border-[#202c42] text-slate-300 hover:border-slate-600'
                }`}
              >
                <Hash className="w-5 h-5 shrink-0" />
                <div>
                  <div className="text-xs font-bold font-mono">Text</div>
                  <div className="text-[10px] text-slate-400">Transmissions & files</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setType('voice')}
                className={`p-3 rounded-xl border flex items-center space-x-3 text-left transition-all ${
                  type === 'voice'
                    ? 'bg-[#00e5ff]/15 border-[#00e5ff] text-[#00e5ff]'
                    : 'bg-[#141b2b] border-[#202c42] text-slate-300 hover:border-slate-600'
                }`}
              >
                <Volume2 className="w-5 h-5 shrink-0" />
                <div>
                  <div className="text-xs font-bold font-mono">Voice</div>
                  <div className="text-[10px] text-slate-400">Spatial voice & screen</div>
                </div>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-400 mb-1">
              CHANNEL NAME *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. protocol-logs"
              className="w-full bg-[#141b2b] border border-[#202c42] rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-[#00ff87]/50 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-400 mb-1">
              TOPIC (OPTIONAL)
            </label>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Channel transmission guidelines"
              className="w-full bg-[#141b2b] border border-[#202c42] rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-[#00ff87]/50 font-mono"
            />
          </div>

          {error && (
            <div className="text-xs text-red-400 font-mono bg-red-500/10 p-2 rounded border border-red-500/20">
              {error}
            </div>
          )}

          <div className="flex items-center justify-end space-x-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-mono text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!name.trim() || isSubmitting}
              className="px-5 py-2 rounded-xl bg-[#00ff87] text-black font-bold text-xs font-mono hover:bg-[#00df76] disabled:opacity-40 transition-all shadow-[0_0_15px_rgba(0,255,135,0.3)]"
            >
              {isSubmitting ? 'Creating...' : 'Create Channel'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
