import React, { useState } from 'react';
import { Download, X, Check, Laptop, Terminal, FolderCheck, AlertCircle, HelpCircle, Sparkles, Monitor, ExternalLink } from 'lucide-react';
import { usePwaInstall } from '../../hooks/usePwaInstall';

interface DownloadZipModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadZipModal: React.FC<DownloadZipModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'pwa' | 'zip'>('pwa');
  const [downloading, setDownloading] = useState(false);
  const [downloadedSize, setDownloadedSize] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { isInstalled, installApp, hasPrompt } = usePwaInstall();
  const [installStatus, setInstallStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    setInstallStatus(null);
    if (hasPrompt) {
      const accepted = await installApp();
      if (accepted) {
        setInstallStatus('Installed successfully! Look for NEXUS on your Windows Desktop and Start Menu.');
      }
    } else {
      setInstallStatus('In Google Chrome or Microsoft Edge, look at the right side of the address bar at the top of your screen: click the [Install NEXUS] icon or go to Menu (3 dots) -> Apps -> Install NEXUS.');
    }
  };

  const handleDownload = async () => {
    setDownloading(true);
    setError(null);

    try {
      const res = await fetch('/api/download/project-zip');
      if (!res.ok) {
        throw new Error(`Server returned HTTP ${res.status}`);
      }

      const blob = await res.blob();
      if (blob.size === 0) {
        throw new Error('Downloaded archive was 0 bytes.');
      }

      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = 'nexus-windows-app.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      setTimeout(() => {
        window.URL.revokeObjectURL(blobUrl);
      }, 10000);

      setDownloadedSize(`${Math.round(blob.size / 1024)} KB`);
    } catch (err: any) {
      console.error('Download error:', err);
      setError(err.message || 'Failed to download archive');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 z-50 select-none animate-in fade-in duration-200">
      <div className="bg-[#0b0e15] border border-[var(--nexus-accent)]/50 rounded-2xl p-6 max-w-xl w-full shadow-[0_0_50px_var(--nexus-accent-glow)] space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-xl bg-[var(--nexus-accent)]/15 border border-[var(--nexus-accent)]/50 flex items-center justify-center text-[var(--nexus-accent)]">
              <Monitor className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white uppercase font-mono tracking-wider">
                GET NEXUS FOR WINDOWS
              </h2>
              <p className="text-[11px] text-[var(--nexus-accent)] font-mono">
                Choose your preferred way to run NEXUS on Windows
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex rounded-xl bg-[#080b10] p-1 border border-slate-800 font-mono text-xs">
          <button
            onClick={() => setActiveTab('pwa')}
            className={`flex-1 py-2 px-3 rounded-lg flex items-center justify-center space-x-2 transition-all ${
              activeTab === 'pwa'
                ? 'bg-[var(--nexus-accent)] text-black font-bold shadow-[0_0_15px_var(--nexus-accent-glow)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>1-Click Install App (Recommended)</span>
          </button>
          <button
            onClick={() => setActiveTab('zip')}
            className={`flex-1 py-2 px-3 rounded-lg flex items-center justify-center space-x-2 transition-all ${
              activeTab === 'zip'
                ? 'bg-[var(--nexus-accent)] text-black font-bold shadow-[0_0_15px_var(--nexus-accent-glow)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download ZIP Package</span>
          </button>
        </div>

        {/* TAB 1: 1-Click Install directly as Windows App */}
        {activeTab === 'pwa' && (
          <div className="space-y-3 font-mono text-xs">
            <div className="bg-[#101522] border border-[var(--nexus-accent)]/30 rounded-xl p-3.5 space-y-2.5">
              <div className="flex items-center space-x-2 text-[var(--nexus-accent)] font-bold text-xs">
                <Sparkles className="w-4 h-4 shrink-0" />
                <span>THE NEW WAY: NATIVE WINDOWS APP (NO ZIP, NO TERMINAL)</span>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                Install NEXUS directly onto your Windows PC with 1 click. It gets its own desktop icon, Start menu shortcut, taskbar pinning, and runs in a native standalone window.
              </p>
              <ul className="text-slate-400 text-[10px] space-y-1 list-disc list-inside">
                <li>No Node.js or command prompts needed</li>
                <li>Never crashes or closes unexpectedly</li>
                <li>Real P2P WebRTC mesh, voice/video calls & screen share</li>
                <li>Custom circular avatar cropping & animated banners ready</li>
              </ul>
            </div>

            <div className="p-3 bg-[#080b10] border border-slate-800 rounded-xl space-y-2 text-[11px]">
              <div className="text-slate-200 font-bold flex items-center justify-between">
                <span>INSTALLATION STATUS:</span>
                {isInstalled ? (
                  <span className="text-[var(--nexus-accent)] flex items-center space-x-1">
                    <Check className="w-3 h-3" />
                    <span>Already Installed as Desktop App</span>
                  </span>
                ) : (
                  <span className="text-[#00e5ff]">Ready to Install</span>
                )}
              </div>

              {installStatus && (
                <div className="p-2.5 bg-[#00ff87]/10 border border-[#00ff87]/30 rounded text-[#00ff87] text-[10px]">
                  {installStatus}
                </div>
              )}

              <button
                onClick={handleInstallClick}
                className="w-full py-3 rounded-xl bg-[var(--nexus-accent)] text-black font-bold text-xs flex items-center justify-center space-x-2 shadow-[0_0_20px_var(--nexus-accent-glow)] hover:opacity-95 transition-opacity cursor-pointer"
              >
                <Monitor className="w-4 h-4" />
                <span>{hasPrompt ? 'Install NEXUS as Windows App Now' : 'Click Here to Install NEXUS on Windows'}</span>
              </button>
              <p className="text-[10px] text-slate-500 text-center">
                Supported in Chrome, Microsoft Edge, Brave, and Opera on Windows 10 & 11.
              </p>
            </div>
          </div>
        )}

        {/* TAB 2: Standalone ZIP Archive */}
        {activeTab === 'zip' && (
          <div className="space-y-3 font-mono text-xs">
            <div className="bg-[#101522] border border-[#1b2538] rounded-xl p-3.5 space-y-2 text-[11px]">
              <div className="text-slate-200 font-bold flex items-center space-x-1.5">
                <FolderCheck className="w-4 h-4 text-[var(--nexus-accent)]" />
                <span>UPDATED BULLETPROOF WINDOWS PACKAGE:</span>
              </div>
              <p className="text-slate-300 text-[10px]">
                The ZIP now includes multiple fail-safe options that <strong>NEVER close automatically</strong>:
              </p>
              <ul className="text-slate-400 text-[10px] space-y-1 list-disc list-inside">
                <li><strong className="text-white">START-HERE.html</strong>: Double-click to open immediately in your browser (no terminal!)</li>
                <li><strong className="text-white">START.bat</strong>: Wrapped in <code className="text-[var(--nexus-accent)]">cmd /k</code> so the window STAYS OPEN unconditionally</li>
                <li><strong className="text-white">run-windows.bat</strong>: Checks for Node.js cleanly with clear pause prompts</li>
                <li><strong className="text-white">Launch-Nexus.ps1</strong>: PowerShell launcher option</li>
              </ul>
            </div>

            <div className="p-3 bg-[#080b10] border border-slate-800 rounded-xl space-y-1.5 text-[10px] text-slate-300">
              <div className="font-bold text-[var(--nexus-accent)]">HOW TO EXTRACT CORRECTLY:</div>
              <ol className="list-decimal list-inside space-y-1">
                <li>Download <strong>nexus-windows-app.zip</strong> below.</li>
                <li>Right-click the ZIP in Downloads ➔ click <strong>&quot;Extract All...&quot;</strong> ➔ click <strong>Extract</strong>.</li>
                <li>In the extracted folder, double-click <strong>START-HERE.html</strong> or <strong>START.bat</strong>!</li>
              </ol>
            </div>

            {error && (
              <div className="p-2.5 rounded-lg bg-red-500/15 border border-red-500/30 text-xs font-mono text-red-400 flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {downloadedSize && (
              <div className="p-2.5 rounded-lg bg-[#00ff87]/15 border border-[#00ff87]/30 text-xs font-mono text-[#00ff87] flex items-center space-x-2">
                <Check className="w-4 h-4 shrink-0" />
                <span>Downloaded {downloadedSize}. Extract it to any folder and run START-HERE.html!</span>
              </div>
            )}

            <button
              onClick={handleDownload}
              disabled={downloading}
              className="w-full py-3 rounded-xl bg-[var(--nexus-accent)] text-black font-bold text-xs flex items-center justify-center space-x-2 shadow-[0_0_20px_var(--nexus-accent-glow)] hover:opacity-95 transition-opacity disabled:opacity-50 cursor-pointer"
            >
              {downloading ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  <span>Preparing & Downloading ZIP...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>Download nexus-windows-app.zip</span>
                </>
              )}
            </button>
          </div>
        )}

        {/* Footer */}
        <div className="pt-2 flex items-center justify-between border-t border-slate-800 text-[11px] font-mono">
          <span className="text-slate-500">P2P Mesh · Real WebRTC · Zero-Config</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/50"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
