import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { BUILT_IN_THEMES } from '../../lib/theme';
import { ThemeConfig } from '../../types/index';
import { soundEngine } from '../../lib/sound';
import { AvatarCropModal } from './AvatarCropModal';
import {
  User as UserIcon,
  Shield,
  Palette,
  Volume2,
  Monitor,
  LogOut,
  X,
  Check,
  AlertCircle,
  Trash2,
  Sparkles,
  Download,
  Laptop,
  Radio,
  Upload,
  Crop,
  Image as ImageIcon
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenDownloadModal: () => void;
}

// Pre-configured futuristic animated avatars & banners
const ANIMATED_AVATARS = [
  { name: 'Neon Cyber Skull', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=160&auto=format&fit=crop&q=80' },
  { name: 'Holographic Matrix', url: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=160&auto=format&fit=crop&q=80' },
  { name: 'Quantum Core', url: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=160&auto=format&fit=crop&q=80' },
  { name: 'Cyber Android', url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80' }
];

const ANIMATED_BANNERS = [
  { name: 'Tokyo Neon Grid', url: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&auto=format&fit=crop&q=80' },
  { name: 'Matrix Data Stream', url: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80' },
  { name: 'Synthwave Horizon', url: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=800&auto=format&fit=crop&q=80' },
  { name: 'Cyberpunk Hyperdrive', url: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&auto=format&fit=crop&q=80' }
];

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, onOpenDownloadModal }) => {
  const {
    user,
    sessions,
    refreshSessions,
    revokeSession,
    revokeOtherSessions,
    updateProfile,
    updateUsername,
    activeTheme,
    setTheme,
    customThemes,
    saveCustomTheme,
    deleteCustomTheme,
    soundEnabled,
    soundVolume,
    setSoundEnabled,
    setSoundVolume,
    logout
  } = useAuth();

  const [activeTab, setActiveTab] = useState<'account' | 'sessions' | 'appearance' | 'p2p' | 'sound' | 'desktop'>('account');

  // Account editing form state
  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [username, setUsername] = useState(user?.username || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [statusMessage, setStatusMessage] = useState(user?.statusMessage || '');
  const [avatarUrl, setAvatarUrl] = useState(user?.avatarUrl || '');
  const [bannerUrl, setBannerUrl] = useState(user?.bannerUrl || '');
  const [accentColor, setAccentColor] = useState(user?.accentColor || '#00ff87');
  const [profileMsg, setProfileMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Avatar cropping state
  const [cropModalOpen, setCropModalOpen] = useState(false);
  const [pendingAvatarSrc, setPendingAvatarSrc] = useState<string>('');
  const [isPendingGif, setIsPendingGif] = useState<boolean>(false);

  const avatarInputRef = useRef<HTMLInputElement>(null);
  const bannerInputRef = useRef<HTMLInputElement>(null);

  // Custom Theme Builder state
  const [newThemeName, setNewThemeName] = useState('Cyber Matrix Custom');
  const [themeAccent, setThemeAccent] = useState('#00ff87');
  const [themeBgBase, setThemeBgBase] = useState('#080b10');
  const [themeBgSurface, setThemeBgSurface] = useState('#0e131d');
  const [themeBorder, setThemeBorder] = useState('#1f2a3e');

  useEffect(() => {
    if (isOpen) {
      refreshSessions();
      if (user) {
        setDisplayName(user.displayName);
        setUsername(user.username);
        setBio(user.bio);
        setStatusMessage(user.statusMessage || '');
        setAvatarUrl(user.avatarUrl || '');
        setBannerUrl(user.bannerUrl || '');
        setAccentColor(user.accentColor);
      }
    }
  }, [isOpen, user]);

  if (!isOpen) return null;

  // Handle local avatar file selection from device
  const handleAvatarFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isGif = file.type === 'image/gif' || file.name.toLowerCase().endsWith('.gif');
    setIsPendingGif(isGif);

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setPendingAvatarSrc(reader.result);
        setCropModalOpen(true);
      }
    };
    reader.readAsDataURL(file);

    if (avatarInputRef.current) {
      avatarInputRef.current.value = '';
    }
  };

  // Handle local banner file selection from device (supports animated GIFs)
  const handleBannerFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setBannerUrl(reader.result);
        setProfileMsg({ type: 'success', text: 'Banner loaded from device. Click "Save Identity Changes" to commit.' });
      }
    };
    reader.readAsDataURL(file);

    if (bannerInputRef.current) {
      bannerInputRef.current.value = '';
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileMsg(null);
    try {
      if (username !== user?.username) {
        await updateUsername(username);
      }
      await updateProfile({
        displayName,
        bio,
        statusMessage,
        avatarUrl,
        bannerUrl,
        accentColor
      });
      setProfileMsg({ type: 'success', text: 'Identity & custom media updated across all clients.' });
    } catch (err: any) {
      setProfileMsg({ type: 'error', text: err.message || 'Failed to update profile' });
    }
  };

  const handleCreateCustomTheme = () => {
    const customId = 'custom-' + Date.now();
    const newTheme: ThemeConfig = {
      id: customId,
      name: newThemeName.trim() || 'Custom Theme',
      isCustom: true,
      accent: themeAccent,
      accentHover: themeAccent,
      accentGlow: `${themeAccent}40`,
      bgBase: themeBgBase,
      bgSurface: themeBgSurface,
      bgElevated: '#141b29',
      bgHover: '#1c2538',
      border: themeBorder,
      textPrimary: '#f8fafc',
      textSecondary: '#94a3b8'
    };
    saveCustomTheme(newTheme);
  };

  const allThemes = [...BUILT_IN_THEMES, ...customThemes];

  return (
    <>
      <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50 select-none">
        <div
          className="border rounded-2xl w-full max-w-4xl h-[650px] shadow-2xl flex overflow-hidden transition-colors duration-200"
          style={{
            backgroundColor: 'var(--nexus-bg-base)',
            borderColor: 'var(--nexus-border)'
          }}
        >
          {/* Left Navigation */}
          <div
            className="w-56 border-r p-4 flex flex-col justify-between shrink-0"
            style={{
              backgroundColor: 'var(--nexus-bg-surface)',
              borderColor: 'var(--nexus-border)'
            }}
          >
            <div className="space-y-1">
              <div className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold px-3 pb-2">
                USER SETTINGS
              </div>

              <button
                onClick={() => setActiveTab('account')}
                className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-xs font-mono transition-colors"
                style={{
                  backgroundColor: activeTab === 'account' ? 'var(--nexus-bg-elevated)' : 'transparent',
                  color: activeTab === 'account' ? 'var(--nexus-accent)' : '#94a3b8',
                  borderLeft: activeTab === 'account' ? '2px solid var(--nexus-accent)' : 'none'
                }}
              >
                <UserIcon className="w-4 h-4" />
                <span className="font-bold">My Account</span>
              </button>

              <button
                onClick={() => setActiveTab('appearance')}
                className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-xs font-mono transition-colors"
                style={{
                  backgroundColor: activeTab === 'appearance' ? 'var(--nexus-bg-elevated)' : 'transparent',
                  color: activeTab === 'appearance' ? 'var(--nexus-accent)' : '#94a3b8',
                  borderLeft: activeTab === 'appearance' ? '2px solid var(--nexus-accent)' : 'none'
                }}
              >
                <Palette className="w-4 h-4" />
                <span>Themes & Presets</span>
              </button>

              <button
                onClick={() => setActiveTab('p2p')}
                className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-xs font-mono transition-colors"
                style={{
                  backgroundColor: activeTab === 'p2p' ? 'var(--nexus-bg-elevated)' : 'transparent',
                  color: activeTab === 'p2p' ? 'var(--nexus-accent)' : '#94a3b8',
                  borderLeft: activeTab === 'p2p' ? '2px solid var(--nexus-accent)' : 'none'
                }}
              >
                <Radio className="w-4 h-4" />
                <span>P2P & WebRTC Setup</span>
              </button>

              <button
                onClick={() => setActiveTab('sessions')}
                className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-xs font-mono transition-colors"
                style={{
                  backgroundColor: activeTab === 'sessions' ? 'var(--nexus-bg-elevated)' : 'transparent',
                  color: activeTab === 'sessions' ? 'var(--nexus-accent)' : '#94a3b8',
                  borderLeft: activeTab === 'sessions' ? '2px solid var(--nexus-accent)' : 'none'
                }}
              >
                <Shield className="w-4 h-4" />
                <span>Active Sessions</span>
              </button>

              <div className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold px-3 pt-3 pb-1">
                SYSTEM
              </div>

              <button
                onClick={() => setActiveTab('sound')}
                className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-xs font-mono transition-colors"
                style={{
                  backgroundColor: activeTab === 'sound' ? 'var(--nexus-bg-elevated)' : 'transparent',
                  color: activeTab === 'sound' ? 'var(--nexus-accent)' : '#94a3b8',
                  borderLeft: activeTab === 'sound' ? '2px solid var(--nexus-accent)' : 'none'
                }}
              >
                <Volume2 className="w-4 h-4" />
                <span>Audio Synthesizer</span>
              </button>

              <button
                onClick={() => setActiveTab('desktop')}
                className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-xs font-mono transition-colors"
                style={{
                  backgroundColor: activeTab === 'desktop' ? 'var(--nexus-bg-elevated)' : 'transparent',
                  color: activeTab === 'desktop' ? 'var(--nexus-accent)' : '#94a3b8',
                  borderLeft: activeTab === 'desktop' ? '2px solid var(--nexus-accent)' : 'none'
                }}
              >
                <Monitor className="w-4 h-4" />
                <span>Windows Desktop</span>
              </button>
            </div>

            {/* Logout */}
            <button
              onClick={() => {
                logout();
                onClose();
              }}
              className="w-full flex items-center space-x-2 px-3 py-2 rounded-xl text-xs font-mono text-[#ff0055] hover:bg-[#250d18] transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out</span>
            </button>
          </div>

          {/* Right Content Panel */}
          <div
            className="flex-1 flex flex-col min-w-0"
            style={{
              backgroundColor: 'var(--nexus-bg-base)'
            }}
          >
            {/* Header */}
            <div
              className="h-12 border-b px-6 flex items-center justify-between"
              style={{
                borderColor: 'var(--nexus-border)',
                backgroundColor: 'var(--nexus-bg-surface)'
              }}
            >
              <span className="font-mono text-xs uppercase tracking-wider text-slate-300 font-bold">
                {activeTab === 'account' && 'Account Identity & Profile Media'}
                {activeTab === 'appearance' && 'Theme Customization & Live Preset Engine'}
                {activeTab === 'p2p' && 'How to Apply & Test P2P WebRTC Communication'}
                {activeTab === 'sessions' && 'Active Device Sessions'}
                {activeTab === 'sound' && 'Audio Synthesizer Preferences'}
                {activeTab === 'desktop' && 'Cross-Platform Windows Desktop Package'}
              </span>
              <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content Body */}
            <div className="flex-1 overflow-y-auto p-6">
              {/* TAB: ACCOUNT */}
              {activeTab === 'account' && (
                <form onSubmit={handleSaveProfile} className="space-y-5 max-w-xl">
                  {/* Hidden file pickers */}
                  <input
                    type="file"
                    ref={avatarInputRef}
                    accept="image/*,.gif"
                    onChange={handleAvatarFileSelect}
                    className="hidden"
                  />
                  <input
                    type="file"
                    ref={bannerInputRef}
                    accept="image/*,.gif"
                    onChange={handleBannerFileSelect}
                    className="hidden"
                  />

                  {/* Profile Card Preview */}
                  <div
                    className="relative rounded-2xl overflow-hidden border shadow-xl"
                    style={{
                      backgroundColor: 'var(--nexus-bg-surface)',
                      borderColor: 'var(--nexus-border)'
                    }}
                  >
                    {/* Banner with edit button overlay */}
                    <div
                      className="h-28 w-full bg-cover bg-center relative group"
                      style={{
                        backgroundImage: bannerUrl
                          ? `url(${bannerUrl})`
                          : `linear-gradient(to right, var(--nexus-accent), #00b8ff)`
                      }}
                    >
                      <button
                        type="button"
                        onClick={() => bannerInputRef.current?.click()}
                        className="absolute top-2 right-2 px-2.5 py-1 rounded-lg bg-black/70 hover:bg-black text-white text-[11px] font-mono flex items-center space-x-1.5 transition-all opacity-80 hover:opacity-100"
                        title="Upload banner or animated GIF from device"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>Change Banner (Device)</span>
                      </button>
                    </div>

                    <div className="p-4 pt-0 relative flex items-end justify-between">
                      {/* Avatar with circular crop trigger overlay */}
                      <div className="relative -mt-12 group">
                        <img
                          src={avatarUrl || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=160&auto=format&fit=crop&q=80'}
                          alt="Avatar preview"
                          className="w-20 h-20 rounded-full object-cover border-4 border-black shadow-lg"
                        />
                        <button
                          type="button"
                          onClick={() => avatarInputRef.current?.click()}
                          className="absolute inset-0 rounded-full bg-black/60 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-white transition-opacity text-[10px] font-mono"
                          title="Upload & Crop Avatar from Device"
                        >
                          <Crop className="w-4 h-4 text-[var(--nexus-accent)] mb-0.5" />
                          <span>Crop</span>
                        </button>
                      </div>

                      <div className="text-right">
                        <div className="text-sm font-bold text-white font-mono">{displayName || 'User'}</div>
                        <div className="text-[11px] text-slate-400 font-mono">@{username}#{user?.tag}</div>
                      </div>
                    </div>
                  </div>

                  {/* Device Media Buttons */}
                  <div className="p-3 border rounded-xl flex items-center justify-between" style={{ backgroundColor: 'var(--nexus-bg-surface)', borderColor: 'var(--nexus-border)' }}>
                    <div>
                      <div className="text-xs font-bold text-white font-mono flex items-center space-x-1.5">
                        <Crop className="w-3.5 h-3.5 text-[var(--nexus-accent)]" />
                        <span>Device Avatar & Banner Upload</span>
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        Discord-style circular crop tool & animated GIFs supported
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        type="button"
                        onClick={() => avatarInputRef.current?.click()}
                        className="px-3 py-1.5 rounded-lg border font-mono text-xs flex items-center space-x-1.5 text-slate-200 hover:text-white transition-colors"
                        style={{ backgroundColor: 'var(--nexus-bg-elevated)', borderColor: 'var(--nexus-accent)' }}
                      >
                        <Upload className="w-3 h-3 text-[var(--nexus-accent)]" />
                        <span>Upload Avatar</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => bannerInputRef.current?.click()}
                        className="px-3 py-1.5 rounded-lg border font-mono text-xs flex items-center space-x-1.5 text-slate-200 hover:text-white transition-colors"
                        style={{ backgroundColor: 'var(--nexus-bg-elevated)', borderColor: 'var(--nexus-border)' }}
                      >
                        <ImageIcon className="w-3 h-3 text-[#00e5ff]" />
                        <span>Upload Banner</span>
                      </button>
                    </div>
                  </div>

                  {/* Preset Animated Media Gallery */}
                  <div className="space-y-2">
                    <div className="text-xs font-mono uppercase tracking-wider text-slate-400 font-semibold flex items-center space-x-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-[var(--nexus-accent)]" />
                      <span>ANIMATED CYBER PRESETS (QUICK SELECT)</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                      {ANIMATED_AVATARS.map((av, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setAvatarUrl(av.url)}
                          className="p-2 rounded-xl border flex items-center space-x-2.5 text-left transition-all hover:border-[var(--nexus-accent)]"
                          style={{ backgroundColor: 'var(--nexus-bg-surface)', borderColor: 'var(--nexus-border)' }}
                        >
                          <img src={av.url} alt={av.name} className="w-8 h-8 rounded-full object-cover border border-slate-700" />
                          <div className="truncate">
                            <div className="text-slate-200 font-bold truncate">{av.name}</div>
                            <div className="text-[10px] text-[var(--nexus-accent)]">Animated Avatar</div>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Standard Text Inputs */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-mono text-slate-400 mb-1">DISPLAY NAME</label>
                      <input
                        type="text"
                        value={displayName}
                        onChange={(e) => setDisplayName(e.target.value)}
                        className="w-full bg-[#121826] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-mono text-slate-400 mb-1">USERNAME (UNIQUE)</label>
                      <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        className="w-full bg-[#121826] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-mono text-slate-400 mb-1">STATUS MESSAGE</label>
                    <input
                      type="text"
                      value={statusMessage}
                      onChange={(e) => setStatusMessage(e.target.value)}
                      className="w-full bg-[#121826] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-mono text-slate-400 mb-1">ABOUT ME / BIOGRAPHY</label>
                    <textarea
                      rows={2}
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      className="w-full bg-[#121826] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono resize-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-mono text-slate-400 mb-1">AVATAR URL (OR DATA URL)</label>
                      <input
                        type="text"
                        value={avatarUrl}
                        onChange={(e) => setAvatarUrl(e.target.value)}
                        className="w-full bg-[#121826] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-mono text-slate-400 mb-1">BANNER URL (OR DATA URL)</label>
                      <input
                        type="text"
                        value={bannerUrl}
                        onChange={(e) => setBannerUrl(e.target.value)}
                        className="w-full bg-[#121826] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                      />
                    </div>
                  </div>

                  {profileMsg && (
                    <div
                      className={`p-3 rounded-lg text-xs font-mono flex items-center space-x-2 ${
                        profileMsg.type === 'success'
                          ? 'bg-[#00ff87]/15 text-[#00ff87] border border-[#00ff87]/30'
                          : 'bg-[#ff0055]/15 text-[#ff0055] border border-[#ff0055]/30'
                      }`}
                    >
                      {profileMsg.type === 'success' ? <Check className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                      <span>{profileMsg.text}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl text-black font-bold text-xs font-mono transition-all"
                    style={{
                      backgroundColor: 'var(--nexus-accent)',
                      boxShadow: `0 0 15px var(--nexus-accent-glow)`
                    }}
                  >
                    Save Identity Changes
                  </button>
                </form>
              )}

              {/* TAB: APPEARANCE & THEMES */}
              {activeTab === 'appearance' && (
                <div className="space-y-6 max-w-2xl">
                  <div>
                    <h3 className="text-xs font-mono uppercase tracking-wider text-slate-300 font-semibold mb-3">
                      CLICK TO ACTIVATE PRESET THEME (INSTANT LIVE PREVIEW)
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {allThemes.map((theme) => {
                        const isSelected = activeTheme.id === theme.id;
                        return (
                          <div
                            key={theme.id}
                            onClick={() => {
                              setTheme(theme.id);
                              setAccentColor(theme.accent);
                              setProfileMsg({ type: 'success', text: `Theme "${theme.name}" active! Interface tokens and accent color updated.` });
                            }}
                            className="p-3.5 rounded-xl border cursor-pointer transition-all relative overflow-hidden"
                            style={{
                              backgroundColor: theme.bgSurface,
                              borderColor: isSelected ? theme.accent : 'rgba(255,255,255,0.1)',
                              borderWidth: isSelected ? '2px' : '1px',
                              boxShadow: isSelected ? `0 0 20px ${theme.accentGlow}` : 'none'
                            }}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-xs font-bold text-white font-mono truncate">
                                {theme.name}
                              </span>
                              {isSelected && (
                                <Check className="w-4 h-4 shrink-0" style={{ color: theme.accent }} />
                              )}
                              {theme.isCustom && !isSelected && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    deleteCustomTheme(theme.id);
                                  }}
                                  className="text-slate-500 hover:text-red-400 p-0.5"
                                  title="Delete Custom Theme"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                            <div className="flex items-center space-x-2">
                              <span
                                className="w-6 h-6 rounded-full border border-black/50 shadow"
                                style={{ backgroundColor: theme.accent }}
                                title="Accent Color"
                              />
                              <span
                                className="w-6 h-6 rounded-full border border-white/20 shadow"
                                style={{ backgroundColor: theme.bgBase }}
                                title="Background Base"
                              />
                              <span
                                className="w-6 h-6 rounded-full border border-white/20 shadow"
                                style={{ backgroundColor: theme.bgSurface }}
                                title="Surface Panel"
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Custom Theme Builder */}
                  <div
                    className="p-4 border rounded-2xl space-y-4"
                    style={{
                      backgroundColor: 'var(--nexus-bg-surface)',
                      borderColor: 'var(--nexus-border)'
                    }}
                  >
                    <h3
                      className="text-xs font-mono uppercase tracking-wider font-bold flex items-center space-x-2"
                      style={{ color: 'var(--nexus-accent)' }}
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>CUSTOM THEME BUILDER</span>
                    </h3>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-mono text-slate-400 mb-1">THEME NAME</label>
                        <input
                          type="text"
                          value={newThemeName}
                          onChange={(e) => setNewThemeName(e.target.value)}
                          className="w-full bg-[#141b2a] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-mono text-slate-400 mb-1">PRIMARY ACCENT</label>
                        <div className="flex items-center space-x-2">
                          <input
                            type="color"
                            value={themeAccent}
                            onChange={(e) => setThemeAccent(e.target.value)}
                            className="w-8 h-8 rounded border-none cursor-pointer bg-transparent"
                          />
                          <input
                            type="text"
                            value={themeAccent}
                            onChange={(e) => setThemeAccent(e.target.value)}
                            className="flex-1 bg-[#141b2a] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-mono"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-mono text-slate-400 mb-1">BACKGROUND BASE</label>
                        <div className="flex items-center space-x-2">
                          <input
                            type="color"
                            value={themeBgBase}
                            onChange={(e) => setThemeBgBase(e.target.value)}
                            className="w-8 h-8 rounded border-none cursor-pointer bg-transparent"
                          />
                          <input
                            type="text"
                            value={themeBgBase}
                            onChange={(e) => setThemeBgBase(e.target.value)}
                            className="flex-1 bg-[#141b2a] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-mono"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-[11px] font-mono text-slate-400 mb-1">PANEL SURFACE</label>
                        <div className="flex items-center space-x-2">
                          <input
                            type="color"
                            value={themeBgSurface}
                            onChange={(e) => setThemeBgSurface(e.target.value)}
                            className="w-8 h-8 rounded border-none cursor-pointer bg-transparent"
                          />
                          <input
                            type="text"
                            value={themeBgSurface}
                            onChange={(e) => setThemeBgSurface(e.target.value)}
                            className="flex-1 bg-[#141b2a] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-mono"
                          />
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={handleCreateCustomTheme}
                      className="px-4 py-2 rounded-xl text-black font-bold text-xs font-mono transition-all"
                      style={{
                        backgroundColor: 'var(--nexus-accent)',
                        boxShadow: `0 0 15px var(--nexus-accent-glow)`
                      }}
                    >
                      Save & Activate Custom Theme
                    </button>
                  </div>
                </div>
              )}

              {/* TAB: P2P */}
              {activeTab === 'p2p' && (
                <div className="space-y-4 max-w-2xl font-mono text-xs">
                  <div
                    className="p-4 border rounded-2xl space-y-3"
                    style={{
                      backgroundColor: 'var(--nexus-bg-surface)',
                      borderColor: 'var(--nexus-border)'
                    }}
                  >
                    <h3
                      className="text-sm font-bold uppercase flex items-center space-x-2"
                      style={{ color: 'var(--nexus-accent)' }}
                    >
                      <Radio className="w-4 h-4 animate-pulse" />
                      <span>HOW TO APPLY AND USE P2P IN NEXUS</span>
                    </h3>
                    <p className="text-slate-300 text-xs leading-relaxed">
                      NEXUS establishes real <strong>Peer-to-Peer (P2P) WebRTC connections</strong> directly between clients using STUN NAT traversal. Once signaling completes via WebSocket, voice, video, and screen sharing streams bypass the central server and stream directly device-to-device.
                    </p>

                    <div className="space-y-2 pt-2">
                      <div className="p-3 bg-[#121826] rounded-xl border border-slate-800 space-y-1">
                        <div style={{ color: 'var(--nexus-accent)' }} className="font-bold">
                          Method 1: Direct 1-on-1 Call with Any Contact
                        </div>
                        <div className="text-slate-400 text-[11px]">
                          Open Direct Messages with a friend or operator (e.g. <code>valkyrie</code>), then click the <strong>Phone</strong> (Voice P2P) or <strong>Video</strong> (Camera & Screen Share P2P) button in the top right.
                        </div>
                      </div>

                      <div className="p-3 bg-[#121826] rounded-xl border border-slate-800 space-y-1">
                        <div style={{ color: 'var(--nexus-accent)' }} className="font-bold">
                          Method 2: Dual-Tab Simulation Test
                        </div>
                        <div className="text-slate-400 text-[11px]">
                          Open this app in two tabs (or regular tab + incognito). In Tab 1 sign in as <code>nexus_admin</code>, in Tab 2 sign in as <code>valkyrie</code>. Start a call from Tab 1; Tab 2 will ring in real time. Click Accept to link both tabs via P2P WebRTC!
                        </div>
                      </div>

                      <div className="p-3 bg-[#121826] rounded-xl border border-slate-800 space-y-1">
                        <div style={{ color: 'var(--nexus-accent)' }} className="font-bold">
                          Method 3: Instant Self P2P Loopback Test
                        </div>
                        <div className="text-slate-400 text-[11px]">
                          Click the <strong>P2P WebRTC Mesh Active</strong> button in the top titlebar anytime to run an on-demand hardware and ICE negotiation diagnostic test right on your current screen.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB: SESSIONS */}
              {activeTab === 'sessions' && (
                <div className="space-y-4 max-w-2xl">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-bold text-white font-mono uppercase">
                        ACTIVE SESSIONS ({sessions.length})
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Devices currently authorized with your NEXUS account.
                      </p>
                    </div>
                    <button
                      onClick={revokeOtherSessions}
                      className="px-3 py-1.5 rounded-lg bg-red-600/20 text-red-400 hover:bg-red-600 hover:text-white border border-red-500/30 text-xs font-mono transition-colors"
                    >
                      Sign Out All Other Devices
                    </button>
                  </div>

                  <div className="space-y-2 pt-2">
                    {sessions.map((sess) => (
                      <div
                        key={sess.id}
                        className="p-3 border rounded-xl flex items-center justify-between"
                        style={{
                          backgroundColor: 'var(--nexus-bg-surface)',
                          borderColor: 'var(--nexus-border)'
                        }}
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-9 h-9 rounded-xl bg-[#151c2a] flex items-center justify-center text-slate-300">
                            {sess.platform === 'desktop-windows' ? <Laptop className="w-5 h-5 text-[#00ff87]" /> : <Monitor className="w-5 h-5" />}
                          </div>
                          <div>
                            <div className="flex items-center space-x-2">
                              <span className="text-xs font-bold text-white font-mono">{sess.deviceName}</span>
                              {sess.isCurrent && (
                                <span
                                  className="text-[10px] font-mono px-2 py-0.5 rounded font-bold border"
                                  style={{
                                    backgroundColor: 'rgba(0,255,135,0.15)',
                                    borderColor: 'var(--nexus-accent)',
                                    color: 'var(--nexus-accent)'
                                  }}
                                >
                                  THIS CLIENT
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                              Platform: {sess.platform} · Last active: {new Date(sess.lastActiveAt).toLocaleTimeString()}
                            </div>
                          </div>
                        </div>

                        {!sess.isCurrent && (
                          <button
                            onClick={() => revokeSession(sess.id)}
                            className="px-3 py-1 rounded bg-[#182030] text-slate-400 hover:text-red-400 hover:bg-[#250d18] text-xs font-mono transition-colors"
                          >
                            Revoke
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB: SOUND */}
              {activeTab === 'sound' && (
                <div className="space-y-4 max-w-xl">
                  <div>
                    <h3 className="text-sm font-bold text-white font-mono uppercase">
                      AUDIO SYNTHESIZER PREFERENCES
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      NEXUS uses an on-device Web Audio API synthesizer for clean futuristic sound effects without missing assets.
                    </p>
                  </div>

                  <div
                    className="p-4 border rounded-2xl space-y-4"
                    style={{
                      backgroundColor: 'var(--nexus-bg-surface)',
                      borderColor: 'var(--nexus-border)'
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-xs font-bold text-white font-mono">Master Sound Effects</div>
                        <div className="text-[11px] text-slate-400 font-mono">Enable or mute all incoming transmission chimes</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={soundEnabled}
                        onChange={(e) => setSoundEnabled(e.target.checked)}
                        className="w-5 h-5 accent-[var(--nexus-accent)] cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between text-xs font-mono text-slate-400 mb-1">
                        <span>Synthesizer Volume</span>
                        <span>{Math.round(soundVolume * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.05}
                        value={soundVolume}
                        onChange={(e) => setSoundVolume(parseFloat(e.target.value))}
                        className="w-full cursor-pointer"
                      />
                    </div>

                    <div className="pt-2 border-t border-slate-700 flex items-center space-x-2">
                      <button
                        onClick={() => soundEngine.playMessageReceived()}
                        className="px-3 py-1.5 rounded-lg bg-[#151c2a] text-slate-200 hover:text-white text-xs font-mono border border-slate-700"
                      >
                        Test Message Chime
                      </button>
                      <button
                        onClick={() => soundEngine.playFriendAlert()}
                        className="px-3 py-1.5 rounded-lg bg-[#151c2a] text-slate-200 hover:text-white text-xs font-mono border border-slate-700"
                      >
                        Test Friend Alert
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB: DESKTOP */}
              {activeTab === 'desktop' && (
                <div className="space-y-4 max-w-2xl">
                  <div>
                    <h3 className="text-sm font-bold text-white font-mono uppercase">
                      WINDOWS DESKTOP APPLICATION ARCHITECTURE
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      The desktop application and web client share 100% of the UI components, WebSocket communication, and WebRTC streaming layer.
                    </p>
                  </div>

                  <div
                    className="p-4 border rounded-2xl space-y-3 font-mono text-xs"
                    style={{
                      backgroundColor: 'var(--nexus-bg-surface)',
                      borderColor: 'var(--nexus-border)'
                    }}
                  >
                    <div style={{ color: 'var(--nexus-accent)' }} className="font-bold">
                      1. Run Desktop Client Locally:
                    </div>
                    <pre className="bg-black/60 p-3 rounded-lg text-slate-300 overflow-x-auto text-[11px]">
{`npm install
npm run electron:start`}
                    </pre>

                    <div className="text-[#00e5ff] font-bold pt-2">2. Package Windows Installer (.exe / NSIS):</div>
                    <pre className="bg-black/60 p-3 rounded-lg text-slate-300 overflow-x-auto text-[11px]">
{`npm run build
npx electron-builder --win`}
                    </pre>

                    <button
                      onClick={onOpenDownloadModal}
                      className="w-full mt-2 py-3 rounded-xl bg-gradient-to-r from-[var(--nexus-accent)] to-[#00e5ff] text-black font-bold text-xs font-mono flex items-center justify-center space-x-2 hover:opacity-90 transition-opacity"
                    >
                      <Download className="w-4 h-4" />
                      <span>Download Full NEXUS Project ZIP with Windows Desktop Files</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Discord-style Avatar Circular Crop Modal */}
      <AvatarCropModal
        isOpen={cropModalOpen}
        imageSrc={pendingAvatarSrc}
        isGif={isPendingGif}
        onClose={() => setCropModalOpen(false)}
        onCropComplete={(croppedDataUrl) => {
          setAvatarUrl(croppedDataUrl);
          setProfileMsg({ type: 'success', text: 'Avatar cropped successfully! Click "Save Identity Changes" to commit.' });
        }}
      />
    </>
  );
};
