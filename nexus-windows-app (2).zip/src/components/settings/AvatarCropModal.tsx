import React, { useState, useRef, useEffect } from 'react';
import { X, ZoomIn, ZoomOut, Check, RotateCcw, Sparkles, Move } from 'lucide-react';

interface AvatarCropModalProps {
  isOpen: boolean;
  imageSrc: string;
  isGif?: boolean;
  onClose: () => void;
  onCropComplete: (croppedDataUrl: string) => void;
}

export const AvatarCropModal: React.FC<AvatarCropModalProps> = ({
  isOpen,
  imageSrc,
  isGif = false,
  onClose,
  onCropComplete
}) => {
  const [zoom, setZoom] = useState<number>(1);
  const [offset, setOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [naturalSize, setNaturalSize] = useState<{ width: number; height: number }>({ width: 0, height: 0 });

  const imageRef = useRef<HTMLImageElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      setZoom(1);
      setOffset({ x: 0, y: 0 });
    }
  }, [isOpen, imageSrc]);

  if (!isOpen || !imageSrc) return null;

  // Mouse drag handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
    setDragStart({ x: e.clientX - offset.x, y: e.clientY - offset.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setOffset({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Touch drag handlers (for touchpads and mobile screens)
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setIsDragging(true);
      setDragStart({
        x: e.touches[0].clientX - offset.x,
        y: e.touches[0].clientY - offset.y
      });
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || e.touches.length !== 1) return;
    setOffset({
      x: e.touches[0].clientX - dragStart.x,
      y: e.touches[0].clientY - dragStart.y
    });
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  // Wheel zoom handler
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY < 0 ? 0.08 : -0.08;
    setZoom(prev => Math.min(3.5, Math.max(0.6, parseFloat((prev + delta).toFixed(2)))));
  };

  const handleImageLoaded = (e: React.SyntheticEvent<HTMLImageElement>) => {
    const img = e.currentTarget;
    setNaturalSize({ width: img.naturalWidth, height: img.naturalHeight });
  };

  const handleApplyCrop = () => {
    if (!imageRef.current) return;

    // If it's an animated GIF and user hasn't zoomed or shifted:
    if (isGif && zoom === 1 && offset.x === 0 && offset.y === 0) {
      onCropComplete(imageSrc);
      onClose();
      return;
    }

    const canvas = document.createElement('canvas');
    const outputSize = 400; // Crisp avatar resolution
    canvas.width = outputSize;
    canvas.height = outputSize;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = imageRef.current;
    const cropCircleDiameter = 260; // diameter in pixels on screen
    const scaleFactor = outputSize / cropCircleDiameter;

    // Clip to circle
    ctx.beginPath();
    ctx.arc(outputSize / 2, outputSize / 2, outputSize / 2, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();

    // Calculate dimensions
    const imgWidth = naturalSize.width || img.naturalWidth || 300;
    const imgHeight = naturalSize.height || img.naturalHeight || 300;

    // Base size on screen so the smaller dimension fills the crop circle
    const minDim = Math.min(imgWidth, imgHeight);
    const baseScale = cropCircleDiameter / minDim;

    const renderedWidth = imgWidth * baseScale * zoom;
    const renderedHeight = imgHeight * baseScale * zoom;

    const drawX = (outputSize / 2) - (renderedWidth * scaleFactor / 2) + (offset.x * scaleFactor);
    const drawY = (outputSize / 2) - (renderedHeight * scaleFactor / 2) + (offset.y * scaleFactor);

    ctx.drawImage(img, drawX, drawY, renderedWidth * scaleFactor, renderedHeight * scaleFactor);

    const resultDataUrl = canvas.toDataURL('image/png', 0.95);
    onCropComplete(resultDataUrl);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 z-50 select-none animate-in fade-in duration-200">
      <div
        className="border rounded-2xl max-w-md w-full shadow-2xl overflow-hidden flex flex-col"
        style={{
          backgroundColor: 'var(--nexus-bg-surface, #0e131d)',
          borderColor: 'var(--nexus-accent, #00ff87)',
          boxShadow: '0 0 40px var(--nexus-accent-glow, rgba(0, 255, 135, 0.25))'
        }}
      >
        {/* Header */}
        <div
          className="h-14 border-b px-5 flex items-center justify-between"
          style={{
            backgroundColor: 'var(--nexus-bg-base, #080b10)',
            borderColor: 'var(--nexus-border, #1f2a3e)'
          }}
        >
          <div className="flex items-center space-x-2">
            <Move className="w-4 h-4" style={{ color: 'var(--nexus-accent)' }} />
            <div>
              <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                Position & Crop Avatar
              </h3>
              <p className="text-[11px] font-mono" style={{ color: 'var(--nexus-accent)' }}>
                Drag image inside the circle · Use slider or scroll wheel to zoom
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Crop Viewport */}
        <div
          className="p-6 flex flex-col items-center justify-center space-y-4"
          style={{ backgroundColor: 'var(--nexus-bg-base, #080b10)' }}
        >
          {/* Circular Interactive Mask Container */}
          <div
            ref={containerRef}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
            onWheel={handleWheel}
            className="w-[260px] h-[260px] rounded-full border-2 overflow-hidden relative cursor-grab active:cursor-grabbing bg-black flex items-center justify-center shadow-xl select-none"
            style={{
              borderColor: 'var(--nexus-accent, #00ff87)',
              boxShadow: '0 0 30px var(--nexus-accent-glow, rgba(0, 255, 135, 0.25))'
            }}
          >
            <img
              ref={imageRef}
              src={imageSrc}
              alt="Crop target"
              draggable={false}
              onLoad={handleImageLoaded}
              style={{
                transform: `translate(${offset.x}px, ${offset.y}px) scale(${zoom})`,
                transition: isDragging ? 'none' : 'transform 0.05s ease-out',
                minWidth: '100%',
                minHeight: '100%',
                objectFit: 'cover'
              }}
              className="pointer-events-none select-none max-w-none max-h-none"
            />

            {/* Inner Discord circle border guide */}
            <div className="absolute inset-0 pointer-events-none rounded-full border-2 border-white/20" />
          </div>

          {/* Animated GIF Notice */}
          {isGif && (
            <div
              className="w-full p-2.5 rounded-xl border text-[11px] font-mono flex items-center space-x-2"
              style={{
                backgroundColor: 'var(--nexus-bg-elevated, #141b29)',
                borderColor: 'var(--nexus-border, #1f2a3e)',
                color: 'var(--nexus-text-primary, #f8fafc)'
              }}
            >
              <Sparkles className="w-4 h-4 shrink-0" style={{ color: 'var(--nexus-accent)' }} />
              <span>Animated GIF detected. Select "Keep Animated Motion" below to preserve full loop!</span>
            </div>
          )}

          {/* Zoom Slider Control */}
          <div className="w-full max-w-xs space-y-2 pt-1">
            <div className="flex items-center justify-between text-xs font-mono text-slate-400">
              <div className="flex items-center space-x-1">
                <ZoomOut className="w-3.5 h-3.5" />
                <span>Zoom Scale</span>
              </div>
              <span className="text-white font-bold font-mono">{Math.round(zoom * 100)}%</span>
            </div>
            <div className="flex items-center space-x-3">
              <input
                type="range"
                min="0.6"
                max="3"
                step="0.05"
                value={zoom}
                onChange={(e) => setZoom(parseFloat(e.target.value))}
                className="w-full cursor-pointer"
                style={{ accentColor: 'var(--nexus-accent)' }}
              />
              <button
                onClick={() => {
                  setZoom(1);
                  setOffset({ x: 0, y: 0 });
                }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white border transition-colors"
                style={{
                  backgroundColor: 'var(--nexus-bg-elevated, #141b29)',
                  borderColor: 'var(--nexus-border, #1f2a3e)'
                }}
                title="Reset Position and Zoom"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div
          className="h-16 border-t px-5 flex items-center justify-between"
          style={{
            backgroundColor: 'var(--nexus-bg-surface, #0e131d)',
            borderColor: 'var(--nexus-border, #1f2a3e)'
          }}
        >
          {isGif ? (
            <button
              onClick={() => {
                onCropComplete(imageSrc);
                onClose();
              }}
              className="px-3.5 py-2 rounded-xl text-xs font-mono border hover:opacity-90 transition-all text-slate-200"
              style={{
                backgroundColor: 'var(--nexus-bg-elevated, #141b29)',
                borderColor: 'var(--nexus-border, #1f2a3e)'
              }}
            >
              Keep Animated Motion (GIF)
            </button>
          ) : (
            <div className="text-[11px] font-mono text-slate-400">
              Drag to position circle
            </div>
          )}

          <div className="flex items-center space-x-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-mono text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleApplyCrop}
              className="px-5 py-2.5 rounded-xl text-black font-bold text-xs font-mono flex items-center space-x-1.5 hover:opacity-90 transition-all shadow-md"
              style={{
                backgroundColor: 'var(--nexus-accent, #00ff87)',
                boxShadow: '0 0 15px var(--nexus-accent-glow, rgba(0, 255, 135, 0.25))'
              }}
            >
              <Check className="w-4 h-4" />
              <span>Save & Apply Avatar</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
