import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Shield, Sparkles, Terminal, ArrowRight, Lock, User as UserIcon } from 'lucide-react';

export const AuthScreen: React.FC = () => {
  const { login, register, error, isDesktopMode } = useAuth();
  const [isRegister, setIsRegister] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    if (!username.trim() || !password.trim()) {
      setLocalError('Please enter both username and password.');
      return;
    }

    setSubmitting(true);
    try {
      if (isRegister) {
        await register(username.trim(), password, displayName.trim() || undefined);
      } else {
        await login(username.trim(), password);
      }
    } catch (err: any) {
      setLocalError(err.message || 'Authentication failed');
    } finally {
      setSubmitting(false);
    }
  };

  // Quick Demo Login helper for immediate testing
  const handleDemoLogin = async (demoUname: string) => {
    setSubmitting(true);
    setLocalError(null);
    try {
      await login(demoUname, 'nexus123');
    } catch (err: any) {
      setLocalError(err.message || 'Demo login failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#07090e] flex items-center justify-center p-4 relative overflow-hidden select-none">
      {/* Background cyber grid & glow */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_20%,rgba(0,255,135,0.08),transparent_60%)] pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_80%,rgba(0,229,255,0.06),transparent_60%)] pointer-events-none" />

      <div className="max-w-md w-full bg-[#0b0e15] border border-[#1b253b] rounded-3xl p-8 shadow-2xl relative z-10 space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#00ff87] to-[#00b8ff] mx-auto flex items-center justify-center font-black text-black text-xl shadow-[0_0_20px_rgba(0,255,135,0.4)]">
            N
          </div>
          <h1 className="text-xl font-bold font-mono tracking-widest text-white uppercase">
            NEXUS <span className="text-[#00ff87] text-xs">NETWORK</span>
          </h1>
          <p className="text-xs text-slate-400 font-mono">
            {isRegister ? 'Register your neural node identifier' : 'Authenticate your cross-platform session'}
          </p>
        </div>

        {/* Quick Demo Operators */}
        <div className="p-3 bg-[#101522] border border-[#1a2336] rounded-2xl space-y-2">
          <div className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold flex items-center space-x-1.5">
            <Terminal className="w-3.5 h-3.5 text-[#00ff87]" />
            <span>QUICK PRESET OPERATORS (INSTANT ACCESS)</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => handleDemoLogin('nexus_admin')}
              disabled={submitting}
              className="p-2 rounded-xl bg-[#151c2a] hover:bg-[#1a253a] border border-slate-700 hover:border-[#00ff87]/50 text-left transition-all"
            >
              <div className="text-xs font-bold text-white font-mono truncate">Sentinel (Admin)</div>
              <div className="text-[10px] text-[#00ff87] font-mono">@nexus_admin</div>
            </button>
            <button
              type="button"
              onClick={() => handleDemoLogin('valkyrie')}
              disabled={submitting}
              className="p-2 rounded-xl bg-[#151c2a] hover:bg-[#1a253a] border border-slate-700 hover:border-[#00e5ff]/50 text-left transition-all"
            >
              <div className="text-xs font-bold text-white font-mono truncate">Valkyrie (Hacker)</div>
              <div className="text-[10px] text-[#00e5ff] font-mono">@valkyrie</div>
            </button>
          </div>
        </div>

        {/* Tab switch */}
        <div className="flex bg-[#101522] p-1 rounded-xl border border-[#182236]">
          <button
            type="button"
            onClick={() => setIsRegister(false)}
            className={`flex-1 py-2 text-xs font-mono font-bold rounded-lg transition-all ${
              !isRegister
                ? 'bg-[#00ff87] text-black shadow-[0_0_10px_rgba(0,255,135,0.3)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => setIsRegister(true)}
            className={`flex-1 py-2 text-xs font-mono font-bold rounded-lg transition-all ${
              isRegister
                ? 'bg-[#00ff87] text-black shadow-[0_0_10px_rgba(0,255,135,0.3)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Register
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegister && (
            <div>
              <label className="block text-[11px] font-mono text-slate-400 mb-1">
                DISPLAY NAME (OPTIONAL)
              </label>
              <div className="relative">
                <UserIcon className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="e.g. Neo Tokyo Scout"
                  className="w-full bg-[#121826] border border-[#1b2538] focus:border-[#00ff87]/50 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none font-mono"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-[11px] font-mono text-slate-400 mb-1">
              USERNAME *
            </label>
            <div className="relative">
              <span className="text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 font-mono text-xs">@</span>
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="lowercase, e.g. cyber_operator"
                className="w-full bg-[#121826] border border-[#1b2538] focus:border-[#00ff87]/50 rounded-xl pl-8 pr-3 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-mono text-slate-400 mb-1">
              PASSWORD *
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="At least 6 characters"
                className="w-full bg-[#121826] border border-[#1b2538] focus:border-[#00ff87]/50 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none font-mono"
              />
            </div>
          </div>

          {(localError || error) && (
            <div className="text-xs text-red-400 font-mono bg-red-500/10 p-2.5 rounded-xl border border-red-500/20">
              {localError || error}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-[#00ff87] to-[#00b8ff] text-black font-bold text-xs font-mono uppercase tracking-wider hover:opacity-95 disabled:opacity-50 transition-all flex items-center justify-center space-x-2 shadow-[0_0_20px_rgba(0,255,135,0.3)]"
          >
            <span>{submitting ? 'Authenticating...' : (isRegister ? 'Initialize Account' : 'Connect to NEXUS')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
