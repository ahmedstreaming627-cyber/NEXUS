import React, { useState, useEffect } from 'react';
import { useChat } from '../../context/ChatContext';
import { useAuth } from '../../context/AuthContext';
import { useCall } from '../../context/CallContext';
import { api } from '../../lib/api';
import { User, UserStatus } from '../../types/index';
import {
  Users,
  UserPlus,
  MessageSquare,
  Phone,
  Video,
  Check,
  X,
  Search,
  Compass,
  Sparkles,
  AlertCircle
} from 'lucide-react';

export const FriendsView: React.FC = () => {
  const { user } = useAuth();
  const {
    friends,
    incomingRequests,
    outgoingRequests,
    respondFriendRequest,
    cancelFriendRequest,
    removeFriend,
    sendFriendRequest,
    openDMWithUser
  } = useChat();

  const { startCall } = useCall();

  const [activeTab, setActiveTab] = useState<'online' | 'all' | 'pending' | 'add' | 'discover'>('online');
  const [searchFilter, setSearchFilter] = useState('');
  const [addInput, setAddInput] = useState('');
  const [addStatus, setAddStatus] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isSubmittingAdd, setIsSubmittingAdd] = useState(false);

  // Discovery state
  const [discoveredUsers, setDiscoveredUsers] = useState<User[]>([]);
  const [discoveryQuery, setDiscoveryQuery] = useState('');
  const [isSearchingUsers, setIsSearchingUsers] = useState(false);

  useEffect(() => {
    if (activeTab === 'discover') {
      loadDiscovery();
    }
  }, [activeTab]);

  const loadDiscovery = async (q: string = '') => {
    setIsSearchingUsers(true);
    try {
      const res = await api.searchUsers(q);
      setDiscoveredUsers(res.users);
    } catch (err) {
      console.error('Discovery load error:', err);
    } finally {
      setIsSearchingUsers(false);
    }
  };

  const handleSendRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!addInput.trim()) return;

    setIsSubmittingAdd(true);
    setAddStatus(null);

    try {
      await sendFriendRequest(addInput.trim());
      setAddStatus({ type: 'success', text: `Transmission request sent to ${addInput.trim()}` });
      setAddInput('');
    } catch (err: any) {
      setAddStatus({ type: 'error', text: err.message || 'Failed to send request' });
    } finally {
      setIsSubmittingAdd(false);
    }
  };

  const getStatusColor = (status: UserStatus) => {
    switch (status) {
      case 'online': return 'bg-[#00ff87] shadow-[0_0_8px_#00ff87]';
      case 'idle': return 'bg-[#f59e0b] shadow-[0_0_8px_#f59e0b]';
      case 'dnd': return 'bg-[#ff0055] shadow-[0_0_8px_#ff0055]';
      default: return 'bg-slate-500';
    }
  };

  const onlineFriends = friends.filter(f => f.status === 'online' || f.status === 'idle' || f.status === 'dnd');

  const filteredFriends = (activeTab === 'online' ? onlineFriends : friends).filter(f =>
    f.displayName.toLowerCase().includes(searchFilter.toLowerCase()) ||
    f.username.toLowerCase().includes(searchFilter.toLowerCase()) ||
    f.tag.includes(searchFilter)
  );

  return (
    <div
      className="flex-1 flex flex-col h-full select-none transition-colors duration-200"
      style={{ backgroundColor: 'var(--nexus-bg-base)' }}
    >
      {/* Top Header & Tab Navigation */}
      <div
        className="h-14 border-b px-4 flex items-center justify-between backdrop-blur z-10"
        style={{
          backgroundColor: 'var(--nexus-bg-surface)',
          borderColor: 'var(--nexus-border)'
        }}
      >
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 text-slate-200 font-bold text-sm">
            <Users className="w-4 h-4" style={{ color: 'var(--nexus-accent)' }} />
            <span>Friends</span>
          </div>

          <div className="h-4 w-px bg-slate-800" />

          {/* Tabs */}
          <div className="flex items-center space-x-1">
            <button
              onClick={() => setActiveTab('online')}
              className="px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-colors"
              style={{
                backgroundColor: activeTab === 'online' ? 'var(--nexus-bg-elevated)' : 'transparent',
                color: activeTab === 'online' ? 'var(--nexus-accent)' : '#94a3b8',
                borderBottom: activeTab === 'online' ? '2px solid var(--nexus-accent)' : 'none'
              }}
            >
              Online ({onlineFriends.length})
            </button>

            <button
              onClick={() => setActiveTab('all')}
              className="px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-colors"
              style={{
                backgroundColor: activeTab === 'all' ? 'var(--nexus-bg-elevated)' : 'transparent',
                color: activeTab === 'all' ? 'var(--nexus-accent)' : '#94a3b8',
                borderBottom: activeTab === 'all' ? '2px solid var(--nexus-accent)' : 'none'
              }}
            >
              All ({friends.length})
            </button>

            <button
              onClick={() => setActiveTab('pending')}
              className="px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-colors relative"
              style={{
                backgroundColor: activeTab === 'pending' ? 'var(--nexus-bg-elevated)' : 'transparent',
                color: activeTab === 'pending' ? 'var(--nexus-accent)' : '#94a3b8',
                borderBottom: activeTab === 'pending' ? '2px solid var(--nexus-accent)' : 'none'
              }}
            >
              <span>Pending</span>
              {incomingRequests.length > 0 && (
                <span className="ml-1.5 bg-[#ff0055] text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full">
                  {incomingRequests.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('add')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-colors ${
                activeTab === 'add'
                  ? 'bg-[#00ff87]/20 text-[#00ff87] font-bold'
                  : 'bg-[#00ff87]/10 text-[#00ff87] hover:bg-[#00ff87]/20'
              }`}
            >
              + Add Friend
            </button>

            <button
              onClick={() => setActiveTab('discover')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-colors flex items-center space-x-1 ${
                activeTab === 'discover'
                  ? 'bg-[#151c2c] text-[#00e5ff] font-semibold border-b-2 border-[#00e5ff]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#10141f]'
              }`}
            >
              <Compass className="w-3.5 h-3.5" />
              <span>Discover</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-6">
        {/* TAB: ADD FRIEND */}
        {activeTab === 'add' && (
          <div className="max-w-xl mx-auto space-y-4">
            <div>
              <h2 className="text-base font-bold text-slate-100 uppercase tracking-wider font-mono">
                ADD FRIEND
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                You can add friends with their NEXUS username or full tag (e.g., <code className="text-[#00ff87]">valkyrie</code> or <code className="text-[#00ff87]">valkyrie#1337</code>).
              </p>
            </div>

            <form onSubmit={handleSendRequest} className="relative flex items-center bg-[#101522] border border-[#1b2538] focus-within:border-[#00ff87]/50 rounded-xl p-1.5 transition-all">
              <input
                type="text"
                placeholder="Enter a username or username#tag..."
                value={addInput}
                onChange={(e) => setAddInput(e.target.value)}
                className="flex-1 bg-transparent px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none font-mono"
              />
              <button
                type="submit"
                disabled={!addInput.trim() || isSubmittingAdd}
                className="px-4 py-2 bg-[#00ff87] text-black font-bold text-xs font-mono rounded-lg hover:bg-[#00df76] disabled:opacity-40 transition-all shadow-[0_0_10px_rgba(0,255,135,0.3)]"
              >
                {isSubmittingAdd ? 'Transmitting...' : 'Send Friend Request'}
              </button>
            </form>

            {addStatus && (
              <div
                className={`p-3 rounded-lg text-xs font-mono flex items-center space-x-2 ${
                  addStatus.type === 'success'
                    ? 'bg-[#00ff87]/15 text-[#00ff87] border border-[#00ff87]/30'
                    : 'bg-[#ff0055]/15 text-[#ff0055] border border-[#ff0055]/30'
                }`}
              >
                {addStatus.type === 'success' ? <Check className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                <span>{addStatus.text}</span>
              </div>
            )}
          </div>
        )}

        {/* TAB: PENDING REQUESTS */}
        {activeTab === 'pending' && (
          <div className="max-w-3xl mx-auto space-y-6">
            {/* Incoming */}
            <div>
              <div className="text-xs font-mono uppercase tracking-wider text-slate-400 font-semibold mb-3">
                Incoming Requests — {incomingRequests.length}
              </div>
              {incomingRequests.length === 0 ? (
                <div className="text-xs text-slate-500 font-mono py-4 border border-dashed border-[#1c2638] rounded-xl text-center">
                  There are no incoming friend transmissions waiting.
                </div>
              ) : (
                <div className="space-y-2">
                  {incomingRequests.map((req) => (
                    <div
                      key={req.id}
                      className="flex items-center justify-between p-3 bg-[#101522] border border-[#1b2538] rounded-xl hover:border-slate-700 transition-colors"
                    >
                      <div className="flex items-center space-x-3">
                        <img
                          src={req.user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                          alt={req.user.displayName}
                          className="w-10 h-10 rounded-full object-cover border border-slate-700"
                        />
                        <div>
                          <div className="text-xs font-bold text-slate-200">
                            {req.user.displayName}
                            <span className="text-slate-500 font-mono text-[11px] ml-1.5">#{req.user.tag}</span>
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono">Incoming Friend Request</div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => respondFriendRequest(req.id, true)}
                          className="p-2 rounded-lg bg-[#00ff87]/20 text-[#00ff87] hover:bg-[#00ff87] hover:text-black transition-all"
                          title="Accept"
                        >
                          <Check className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => respondFriendRequest(req.id, false)}
                          className="p-2 rounded-lg bg-[#ff0055]/20 text-[#ff0055] hover:bg-[#ff0055] hover:text-white transition-all"
                          title="Ignore"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Outgoing */}
            <div>
              <div className="text-xs font-mono uppercase tracking-wider text-slate-400 font-semibold mb-3">
                Outgoing Requests — {outgoingRequests.length}
              </div>
              {outgoingRequests.length === 0 ? (
                <div className="text-xs text-slate-500 font-mono py-4 border border-dashed border-[#1c2638] rounded-xl text-center">
                  No pending outgoing friend requests.
                </div>
              ) : (
                <div className="space-y-2">
                  {outgoingRequests.map((req) => (
                    <div
                      key={req.id}
                      className="flex items-center justify-between p-3 bg-[#101522] border border-[#1b2538] rounded-xl"
                    >
                      <div className="flex items-center space-x-3">
                        <img
                          src={req.user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                          alt={req.user.displayName}
                          className="w-10 h-10 rounded-full object-cover border border-slate-700"
                        />
                        <div>
                          <div className="text-xs font-bold text-slate-200">
                            {req.user.displayName}
                            <span className="text-slate-500 font-mono text-[11px] ml-1.5">#{req.user.tag}</span>
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono">Outgoing Friend Request</div>
                        </div>
                      </div>

                      <button
                        onClick={() => cancelFriendRequest(req.id)}
                        className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors text-xs font-mono"
                        title="Cancel Request"
                      >
                        Cancel
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB: DISCOVER USERS */}
        {activeTab === 'discover' && (
          <div className="max-w-3xl mx-auto space-y-4">
            <div>
              <h2 className="text-base font-bold text-slate-100 uppercase tracking-wider font-mono">
                DISCOVER NEXUS OPERATORS
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Explore registered users on the neural grid and initiate direct transmissions.
              </p>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                placeholder="Search registered network users..."
                value={discoveryQuery}
                onChange={(e) => {
                  setDiscoveryQuery(e.target.value);
                  loadDiscovery(e.target.value);
                }}
                className="w-full bg-[#101522] border border-[#1b2538] rounded-xl pl-9 pr-4 py-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-[#00e5ff]/50 font-mono"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
              {discoveredUsers.map((discUser) => {
                const isFriend = friends.some(f => f.id === discUser.id);
                return (
                  <div
                    key={discUser.id}
                    className="p-3 bg-[#101522] border border-[#1b2538] hover:border-[#00e5ff]/40 rounded-xl flex items-center justify-between transition-all"
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <div className="relative shrink-0">
                        <img
                          src={discUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                          alt={discUser.displayName}
                          className="w-10 h-10 rounded-full object-cover border border-slate-700"
                        />
                        <span
                          className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-[#101522] ${getStatusColor(
                            discUser.status
                          )}`}
                        />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-slate-200 truncate">
                          {discUser.displayName}
                        </div>
                        <div className="text-[11px] font-mono text-slate-500 truncate">
                          @{discUser.username}#{discUser.tag}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-1.5 shrink-0">
                      <button
                        onClick={() => openDMWithUser(discUser.id)}
                        className="p-2 rounded-lg bg-[#151c2a] text-slate-300 hover:text-[#00ff87] hover:bg-[#1c2638] transition-colors"
                        title="Send Direct Transmission"
                      >
                        <MessageSquare className="w-4 h-4" />
                      </button>

                      {!isFriend && (
                        <button
                          onClick={() => sendFriendRequest(discUser.username)}
                          className="p-2 rounded-lg bg-[#00ff87]/15 text-[#00ff87] hover:bg-[#00ff87] hover:text-black transition-all"
                          title="Add Friend"
                        >
                          <UserPlus className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB: ONLINE & ALL FRIENDS */}
        {(activeTab === 'online' || activeTab === 'all') && (
          <div className="max-w-4xl mx-auto space-y-4">
            {/* Filter */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                placeholder="Search friends..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="w-full bg-[#101522] border border-[#1b2538] rounded-xl pl-9 pr-4 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-[#00ff87]/50 font-mono"
              />
            </div>

            <div className="text-xs font-mono uppercase tracking-wider text-slate-400 font-semibold pt-2">
              {activeTab === 'online' ? `Online Friends — ${filteredFriends.length}` : `All Friends — ${filteredFriends.length}`}
            </div>

            {filteredFriends.length === 0 ? (
              <div className="text-center py-12 text-slate-500 font-mono space-y-2">
                <Sparkles className="w-8 h-8 mx-auto text-slate-600" />
                <p className="text-xs">No operators found matching your status filter.</p>
              </div>
            ) : (
              <div className="space-y-1.5">
                {filteredFriends.map((friend) => (
                  <div
                    key={friend.id}
                    className="flex items-center justify-between p-3 bg-[#101522] border border-[#1b2538] hover:border-[#1e2a3f] hover:bg-[#131a29] rounded-xl transition-all group"
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <div className="relative shrink-0">
                        <img
                          src={friend.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                          alt={friend.displayName}
                          className="w-10 h-10 rounded-full object-cover border border-slate-700"
                        />
                        <span
                          className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-[#101522] ${getStatusColor(
                            friend.status
                          )}`}
                        />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-slate-200 flex items-center space-x-1.5">
                          <span className="truncate">{friend.displayName}</span>
                          <span className="text-slate-500 font-mono text-[11px]">#{friend.tag}</span>
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono truncate">
                          {friend.statusMessage || (friend.status === 'online' ? 'Active in Grid' : 'Offline')}
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center space-x-1.5">
                      <button
                        onClick={() => openDMWithUser(friend.id)}
                        className="p-2 rounded-lg bg-[#151c2a] text-slate-300 hover:text-[#00ff87] hover:bg-[#1d273a] transition-colors"
                        title="Send Direct Transmission"
                      >
                        <MessageSquare className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => startCall(friend, 'voice')}
                        className="p-2 rounded-lg bg-[#151c2a] text-slate-300 hover:text-[#00ff87] hover:bg-[#1d273a] transition-colors"
                        title="Start Voice Transmission (WebRTC)"
                      >
                        <Phone className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => startCall(friend, 'video')}
                        className="p-2 rounded-lg bg-[#151c2a] text-slate-300 hover:text-[#00e5ff] hover:bg-[#1d273a] transition-colors"
                        title="Start Video & Screen Transmission (WebRTC)"
                      >
                        <Video className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => removeFriend(friend.id)}
                        className="p-2 rounded-lg bg-[#151c2a] text-slate-400 hover:text-[#ff0055] hover:bg-[#250d18] transition-colors"
                        title="Remove Friend"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
