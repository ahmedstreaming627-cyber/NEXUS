import React, { useState } from 'react';
import { useChat } from '../../context/ChatContext';
import { useAuth } from '../../context/AuthContext';
import { useCall } from '../../context/CallContext';
import { UserStatus, Channel } from '../../types/index';
import {
  Users,
  Plus,
  Hash,
  Volume2,
  Mic,
  MicOff,
  Settings,
  Copy,
  Check,
  ChevronDown,
  LogOut,
  PhoneCall,
  Radio
} from 'lucide-react';

interface ChannelBarProps {
  onOpenSettings: () => void;
  onOpenCreateChannel: () => void;
}

export const ChannelBar: React.FC<ChannelBarProps> = ({
  onOpenSettings,
  onOpenCreateChannel
}) => {
  const {
    activeView,
    setActiveView,
    activeCommunity,
    activeChannel,
    selectChannel,
    dms,
    activeDMId,
    selectDM,
    incomingRequests,
    leaveCommunity
  } = useChat();

  const { user, updateProfile } = useAuth();
  const {
    activeVoiceChannel,
    joinVoiceChannel,
    leaveVoiceChannel,
    isMuted,
    toggleMute
  } = useCall();

  const [copiedInvite, setCopiedInvite] = useState(false);
  const [showStatusMenu, setShowStatusMenu] = useState(false);
  const [showCommunityMenu, setShowCommunityMenu] = useState(false);

  const isDMsView = activeView === 'friends' || activeView === 'dms';

  const handleCopyInvite = () => {
    if (activeCommunity?.inviteCode) {
      navigator.clipboard.writeText(activeCommunity.inviteCode);
      setCopiedInvite(true);
      setTimeout(() => setCopiedInvite(false), 2000);
    }
  };

  const handleStatusChange = (status: UserStatus) => {
    updateProfile({ status });
    setShowStatusMenu(false);
  };

  const getStatusColor = (status?: UserStatus) => {
    switch (status) {
      case 'online': return 'bg-[#00ff87] shadow-[0_0_8px_#00ff87]';
      case 'idle': return 'bg-[#f59e0b] shadow-[0_0_8px_#f59e0b]';
      case 'dnd': return 'bg-[#ff0055] shadow-[0_0_8px_#ff0055]';
      default: return 'bg-slate-500';
    }
  };

  return (
    <div
      className="w-60 border-r flex flex-col h-full select-none shrink-0 transition-colors duration-200"
      style={{
        backgroundColor: 'var(--nexus-bg-surface)',
        borderColor: 'var(--nexus-border)'
      }}
    >
      {/* Top Header */}
      {isDMsView ? (
        <div className="p-3 border-b" style={{ borderColor: 'var(--nexus-border)' }}>
          <button
            onClick={() => setActiveView('friends')}
            className="w-full flex items-center justify-between px-3 py-2 rounded-lg font-medium text-sm transition-all"
            style={{
              backgroundColor: activeView === 'friends' ? 'var(--nexus-bg-elevated)' : 'transparent',
              color: activeView === 'friends' ? 'var(--nexus-accent)' : '#94a3b8',
              border: activeView === 'friends' ? '1px solid var(--nexus-accent)' : '1px solid transparent'
            }}
          >
            <div className="flex items-center space-x-2.5">
              <Users className="w-4 h-4" />
              <span>Friends & Transmissions</span>
            </div>
            {incomingRequests.length > 0 && (
              <span className="bg-[#ff0055] text-white text-[11px] font-bold px-1.5 py-0.2 rounded-full">
                {incomingRequests.length}
              </span>
            )}
          </button>
        </div>
      ) : (
        <div className="relative border-b" style={{ borderColor: 'var(--nexus-border)' }}>
          <button
            onClick={() => setShowCommunityMenu(!showCommunityMenu)}
            className="w-full p-3 flex items-center justify-between hover:opacity-90 transition-opacity"
          >
            <div className="flex items-center space-x-2 overflow-hidden">
              <span className="font-bold text-slate-100 text-sm truncate font-mono tracking-wide">
                {activeCommunity?.name}
              </span>
            </div>
            <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
          </button>

          {/* Community Dropdown */}
          {showCommunityMenu && activeCommunity && (
            <div
              className="absolute top-full left-2 right-2 mt-1 border rounded-xl shadow-2xl p-1.5 z-30 space-y-1"
              style={{
                backgroundColor: 'var(--nexus-bg-elevated)',
                borderColor: 'var(--nexus-border)'
              }}
            >
              <button
                onClick={handleCopyInvite}
                className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-mono text-slate-300 hover:text-white transition-colors"
                style={{
                  backgroundColor: 'var(--nexus-bg-surface)'
                }}
              >
                <span>Invite Code: <strong style={{ color: 'var(--nexus-accent)' }}>{activeCommunity.inviteCode}</strong></span>
                {copiedInvite ? <Check className="w-3.5 h-3.5 text-[#00ff87]" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
              </button>

              <button
                onClick={() => {
                  setShowCommunityMenu(false);
                  onOpenCreateChannel();
                }}
                className="w-full flex items-center space-x-2 px-3 py-2 rounded-lg text-xs text-slate-300 hover:text-white transition-colors"
              >
                <Plus className="w-3.5 h-3.5" style={{ color: 'var(--nexus-accent)' }} />
                <span>Create Channel</span>
              </button>

              {activeCommunity.ownerId !== user?.id && (
                <button
                  onClick={() => {
                    setShowCommunityMenu(false);
                    leaveCommunity(activeCommunity.id);
                  }}
                  className="w-full flex items-center space-x-2 px-3 py-2 rounded-lg text-xs text-[#ff0055] hover:bg-[#250d18] transition-colors"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Leave Community</span>
                </button>
              )}
            </div>
          )}
        </div>
      )}

      {/* Middle Scrollable Section */}
      <div className="flex-1 overflow-y-auto px-2 py-3 space-y-4">
        {isDMsView ? (
          <div>
            <div className="px-2 pb-2 text-[11px] font-mono tracking-wider uppercase text-slate-500 font-semibold">
              Direct Messages
            </div>
            <div className="space-y-0.5">
              {dms.length === 0 ? (
                <div className="px-2 py-4 text-center text-xs text-slate-500 font-mono">
                  No active transmissions yet. Find friends or add users!
                </div>
              ) : (
                dms.map(dm => {
                  if (!dm.participant) return null;
                  const isSelected = activeView === 'dms' && activeDMId === dm.id;
                  return (
                    <button
                      key={dm.id}
                      onClick={() => selectDM(dm.id, dm.participant!)}
                      className="w-full flex items-center space-x-2.5 px-2.5 py-2 rounded-lg text-left transition-all"
                      style={{
                        backgroundColor: isSelected ? 'var(--nexus-bg-elevated)' : 'transparent',
                        borderLeft: isSelected ? `2px solid var(--nexus-accent)` : 'none',
                        color: isSelected ? '#fff' : '#cbd5e1'
                      }}
                    >
                      <div className="relative shrink-0">
                        <img
                          src={dm.participant.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                          alt={dm.participant.displayName}
                          className="w-8 h-8 rounded-full object-cover border border-slate-700"
                        />
                        <span
                          className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-black ${getStatusColor(
                            dm.participant.status
                          )}`}
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold truncate text-slate-200">
                            {dm.participant.displayName}
                          </span>
                        </div>
                        {dm.lastMessage && (
                          <p className="text-[11px] text-slate-500 truncate">
                            {dm.lastMessage.content || 'File attachment'}
                          </p>
                        )}
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>
        ) : (
          activeCommunity && (
            <div className="space-y-4">
              {/* Text Channels */}
              <div>
                <div className="flex items-center justify-between px-2 pb-1 text-[11px] font-mono tracking-wider uppercase text-slate-500 font-semibold">
                  <span>Text Channels</span>
                  <button
                    onClick={onOpenCreateChannel}
                    className="hover:text-slate-300 transition-colors p-0.5"
                    title="Add Channel"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="space-y-0.5">
                  {activeCommunity.channels
                    .filter(c => c.type === 'text')
                    .map(channel => {
                      const isSelected = activeChannel?.id === channel.id;
                      return (
                        <button
                          key={channel.id}
                          onClick={() => selectChannel(channel)}
                          className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg text-left text-xs font-medium transition-all"
                          style={{
                            backgroundColor: isSelected ? 'var(--nexus-bg-elevated)' : 'transparent',
                            color: isSelected ? 'var(--nexus-accent)' : '#94a3b8',
                            borderLeft: isSelected ? `2px solid var(--nexus-accent)` : 'none'
                          }}
                        >
                          <Hash className="w-3.5 h-3.5 shrink-0 opacity-70" />
                          <span className="truncate">{channel.name}</span>
                        </button>
                      );
                    })}
                </div>
              </div>

              {/* Voice Lounges */}
              <div>
                <div className="px-2 pb-1 text-[11px] font-mono tracking-wider uppercase text-slate-500 font-semibold">
                  Voice Channels
                </div>
                <div className="space-y-1">
                  {activeCommunity.channels
                    .filter(c => c.type === 'voice')
                    .map(channel => {
                      const isConnectedToThis = activeVoiceChannel?.channelId === channel.id;
                      return (
                        <div key={channel.id} className="space-y-1">
                          <button
                            onClick={() => {
                              if (isConnectedToThis) {
                                leaveVoiceChannel();
                              } else {
                                joinVoiceChannel(activeCommunity.id, channel.id, channel.name);
                              }
                            }}
                            className="w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-left text-xs transition-all"
                            style={{
                              backgroundColor: isConnectedToThis ? 'var(--nexus-bg-elevated)' : 'transparent',
                              color: isConnectedToThis ? 'var(--nexus-accent)' : '#94a3b8',
                              border: isConnectedToThis ? '1px solid var(--nexus-accent)' : 'none'
                            }}
                          >
                            <div className="flex items-center space-x-2 truncate">
                              <Volume2 className="w-3.5 h-3.5 shrink-0" />
                              <span className="truncate">{channel.name}</span>
                            </div>
                            {isConnectedToThis ? (
                              <span
                                className="text-[10px] font-mono px-1.5 py-0.5 rounded font-bold"
                                style={{
                                  backgroundColor: 'var(--nexus-bg-base)',
                                  color: 'var(--nexus-accent)'
                                }}
                              >
                                CONNECTED
                              </span>
                            ) : (
                              <span className="text-[10px] font-mono text-slate-500">
                                JOIN
                              </span>
                            )}
                          </button>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          )
        )}
      </div>

      {/* Voice Status Pill if Connected */}
      {activeVoiceChannel && (
        <div
          className="p-2.5 mx-2 mb-2 border rounded-xl flex items-center justify-between"
          style={{
            backgroundColor: 'var(--nexus-bg-elevated)',
            borderColor: 'var(--nexus-accent)'
          }}
        >
          <div className="flex items-center space-x-2">
            <Radio className="w-4 h-4 animate-pulse" style={{ color: 'var(--nexus-accent)' }} />
            <div className="min-w-0">
              <div className="text-[11px] font-bold truncate" style={{ color: 'var(--nexus-accent)' }}>
                Voice Connected
              </div>
              <div className="text-[10px] text-slate-400 truncate font-mono">
                {activeVoiceChannel.channelName}
              </div>
            </div>
          </div>
          <button
            onClick={leaveVoiceChannel}
            className="p-1.5 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors"
            title="Disconnect Voice"
          >
            <PhoneCall className="w-3.5 h-3.5 rotate-135" />
          </button>
        </div>
      )}

      {/* Bottom User Controls Bar */}
      <div
        className="p-2 border-t flex items-center justify-between relative"
        style={{
          backgroundColor: 'var(--nexus-bg-base)',
          borderColor: 'var(--nexus-border)'
        }}
      >
        {/* User Info & Status Toggle */}
        <div className="flex items-center space-x-2 min-w-0">
          <div className="relative cursor-pointer" onClick={() => setShowStatusMenu(!showStatusMenu)}>
            <img
              src={user?.avatarUrl || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=160&auto=format&fit=crop&q=80'}
              alt={user?.displayName || 'User'}
              className="w-8 h-8 rounded-full object-cover border border-slate-700"
            />
            <span
              className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-black ${getStatusColor(
                user?.status
              )}`}
            />
          </div>

          <div className="min-w-0">
            <div className="text-xs font-bold text-slate-200 truncate leading-tight">
              {user?.displayName || user?.username}
            </div>
            <div className="text-[10px] font-mono text-slate-500 truncate leading-tight">
              #{user?.tag}
            </div>
          </div>
        </div>

        {/* Status Dropdown */}
        {showStatusMenu && (
          <div
            className="absolute bottom-full left-2 mb-2 w-48 border rounded-xl shadow-2xl p-1.5 z-40 space-y-1"
            style={{
              backgroundColor: 'var(--nexus-bg-elevated)',
              borderColor: 'var(--nexus-border)'
            }}
          >
            <button
              onClick={() => handleStatusChange('online')}
              className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg text-xs text-slate-200 hover:opacity-90"
            >
              <span className="w-2.5 h-2.5 rounded-full bg-[#00ff87]" />
              <span>Online</span>
            </button>
            <button
              onClick={() => handleStatusChange('idle')}
              className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg text-xs text-slate-200 hover:opacity-90"
            >
              <span className="w-2.5 h-2.5 rounded-full bg-[#f59e0b]" />
              <span>Idle</span>
            </button>
            <button
              onClick={() => handleStatusChange('dnd')}
              className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg text-xs text-slate-200 hover:opacity-90"
            >
              <span className="w-2.5 h-2.5 rounded-full bg-[#ff0055]" />
              <span>Do Not Disturb</span>
            </button>
            <button
              onClick={() => handleStatusChange('offline')}
              className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg text-xs text-slate-200 hover:opacity-90"
            >
              <span className="w-2.5 h-2.5 rounded-full bg-slate-500" />
              <span>Invisible / Offline</span>
            </button>
          </div>
        )}

        {/* Quick Audio & Settings buttons */}
        <div className="flex items-center space-x-1 text-slate-400">
          <button
            onClick={toggleMute}
            className={`p-1.5 rounded-lg hover:text-slate-100 transition-colors ${
              isMuted ? 'text-red-400' : ''
            }`}
            title={isMuted ? 'Unmute Microphone' : 'Mute Microphone'}
          >
            {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          <button
            onClick={onOpenSettings}
            className="p-1.5 rounded-lg transition-colors hover:text-white"
            style={{
              color: 'var(--nexus-accent)'
            }}
            title="User Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
