import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Minus, Square, X, Download, Monitor, Globe, Radio, Sparkles } from 'lucide-react';

interface TitleBarProps {
  onOpenDownloadModal: () => void;
  onOpenP2PModal: () => void;
}

export const TitleBar: React.FC<TitleBarProps> = ({ onOpenDownloadModal, onOpenP2PModal }) => {
  const { isDesktopMode, toggleDesktopMode, activeTheme } = useAuth();
  const [isMaximized, setIsMaximized] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined' && (window as any).nexusDesktop) {
      const desktop = (window as any).nexusDesktop;
      desktop.onWindowStateChange?.((state: { isMaximized: boolean }) => {
        setIsMaximized(state.isMaximized);
      });
      desktop.isMaximized?.().then?.((max: boolean) => setIsMaximized(max));
    }
  }, []);

  const handleMinimize = () => {
    if ((window as any).nexusDesktop?.minimize) {
      (window as any).nexusDesktop.minimize();
    }
  };

  const handleMaximize = () => {
    if ((window as any).nexusDesktop?.maximize) {
      (window as any).nexusDesktop.maximize();
    } else {
      setIsMaximized(!isMaximized);
    }
  };

  const handleClose = () => {
    if ((window as any).nexusDesktop?.close) {
      (window as any).nexusDesktop.close();
    }
  };

  return (
    <div
      className="h-10 w-full border-b flex items-center justify-between px-3 text-xs select-none app-drag-region z-50 transition-colors duration-200"
      style={{
        backgroundColor: 'var(--nexus-bg-base)',
        borderColor: 'var(--nexus-border)'
      }}
    >
      {/* Brand & Connection State */}
      <div className="flex items-center space-x-3 app-no-drag">
        <div className="flex items-center space-x-2">
          <div
            className="w-5 h-5 rounded flex items-center justify-center font-black text-black text-[10px] shadow-sm transition-all"
            style={{
              backgroundColor: 'var(--nexus-accent)',
              boxShadow: `0 0 10px var(--nexus-accent-glow)`
            }}
          >
            N
          </div>
          <span className="font-bold tracking-widest text-slate-200 uppercase font-mono">
            NEXUS <span style={{ color: 'var(--nexus-accent)' }} className="text-[10px]">v2.5</span>
          </span>
        </div>

        <div className="h-3 w-px bg-slate-800" />

        <div className="flex items-center space-x-1.5 text-slate-400">
          <span
            className="w-1.5 h-1.5 rounded-full animate-pulse"
            style={{
              backgroundColor: 'var(--nexus-accent)',
              boxShadow: `0 0 8px var(--nexus-accent)`
            }}
          />
          <span className="font-mono text-[10px] text-slate-400 hidden sm:inline">NETWORK SYNCHRONIZED</span>
        </div>
      </div>

      {/* Center status message / mode */}
      <div className="hidden md:flex items-center space-x-2 text-slate-400 font-mono text-[11px]">
        <button
          onClick={onOpenP2PModal}
          className="flex items-center space-x-1.5 px-2.5 py-1 rounded-lg border hover:opacity-90 transition-all cursor-pointer app-no-drag"
          style={{
            backgroundColor: 'var(--nexus-bg-surface)',
            borderColor: 'var(--nexus-accent)',
            color: 'var(--nexus-accent)'
          }}
          title="Open P2P WebRTC Direct Connect & Diagnostics Panel"
        >
          <Radio className="w-3.5 h-3.5 animate-pulse" />
          <span className="font-bold">P2P WebRTC Mesh Active</span>
          <span className="text-[10px] opacity-80">(Live Test)</span>
        </button>
      </div>

      {/* Right controls */}
      <div className="flex items-center space-x-2 app-no-drag">
        {/* P2P Mobile/Small Screen Button */}
        <button
          onClick={onOpenP2PModal}
          className="md:hidden flex items-center space-x-1 px-2 py-1 rounded border text-xs font-mono"
          style={{
            backgroundColor: 'var(--nexus-bg-surface)',
            borderColor: 'var(--nexus-accent)',
            color: 'var(--nexus-accent)'
          }}
          title="P2P Diagnostics"
        >
          <Radio className="w-3.5 h-3.5" />
          <span>P2P</span>
        </button>

        {/* Install Windows Desktop App Button */}
        <button
          onClick={onOpenDownloadModal}
          className="flex items-center space-x-1.5 px-2.5 py-1 rounded border text-black font-bold transition-all font-mono text-[11px] cursor-pointer"
          style={{
            backgroundColor: 'var(--nexus-accent)',
            borderColor: 'var(--nexus-accent)',
            boxShadow: '0 0 10px var(--nexus-accent-glow)'
          }}
          title="Install NEXUS directly on Windows as a native desktop application"
        >
          <Sparkles className="w-3.5 h-3.5 text-black" />
          <span className="hidden sm:inline">Install App</span>
        </button>

        {/* Download complete Source & Desktop package ZIP */}
        <button
          onClick={onOpenDownloadModal}
          className="flex items-center space-x-1.5 px-2.5 py-1 rounded border text-slate-200 transition-all font-mono text-[11px] cursor-pointer hover:border-[var(--nexus-accent)]"
          style={{
            backgroundColor: 'var(--nexus-bg-surface)',
            borderColor: 'var(--nexus-border)'
          }}
          title="Download Complete Project ZIP & Windows Desktop Installer package"
        >
          <Download className="w-3.5 h-3.5" style={{ color: 'var(--nexus-accent)' }} />
          <span className="hidden sm:inline">Download ZIP</span>
        </button>

        {/* Client View Toggle (Web / Windows Desktop layout simulation) */}
        <button
          onClick={toggleDesktopMode}
          className="flex items-center space-x-1.5 px-2 py-1 rounded font-mono text-[11px] transition-all border"
          style={{
            backgroundColor: isDesktopMode ? 'var(--nexus-bg-elevated)' : 'var(--nexus-bg-surface)',
            borderColor: isDesktopMode ? 'var(--nexus-accent)' : 'var(--nexus-border)',
            color: isDesktopMode ? 'var(--nexus-accent)' : '#94a3b8'
          }}
          title="Toggle Windows Desktop native frame vs Web Client frame"
        >
          {isDesktopMode ? (
            <>
              <Monitor className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Desktop Mode</span>
            </>
          ) : (
            <>
              <Globe className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Web Client</span>
            </>
          )}
        </button>

        {/* Windows Window Controls */}
        {isDesktopMode && (
          <div className="flex items-center pl-1 space-x-1 border-l border-slate-800">
            <button
              onClick={handleMinimize}
              className="w-7 h-7 flex items-center justify-center text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded transition-colors"
              title="Minimize"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleMaximize}
              className="w-7 h-7 flex items-center justify-center text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded transition-colors"
              title="Maximize"
            >
              <Square className="w-3 h-3" />
            </button>
            <button
              onClick={handleClose}
              className="w-7 h-7 flex items-center justify-center text-slate-400 hover:text-white hover:bg-red-500 rounded transition-colors"
              title="Close"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
