import React from 'react';
import { useChat } from '../../context/ChatContext';
import { MessageSquare, Plus, Compass } from 'lucide-react';

interface ServerBarProps {
  onOpenCreateCommunity: () => void;
  onOpenJoinCommunity: () => void;
}

export const ServerBar: React.FC<ServerBarProps> = ({
  onOpenCreateCommunity,
  onOpenJoinCommunity
}) => {
  const { activeView, setActiveView, communities, activeCommunity, selectCommunity, incomingRequests } = useChat();

  const isDMsActive = activeView === 'friends' || activeView === 'dms';

  return (
    <div
      className="w-[72px] border-r flex flex-col items-center py-3 space-y-2 select-none z-20 shrink-0 transition-colors duration-200"
      style={{
        backgroundColor: 'var(--nexus-bg-base)',
        borderColor: 'var(--nexus-border)'
      }}
    >
      {/* Home / Direct Messages & Friends Button */}
      <div className="relative group">
        <div
          className={`absolute left-0 top-1/2 -translate-y-1/2 w-1 rounded-r transition-all duration-200 ${
            isDMsActive ? 'h-10' : 'h-0 group-hover:h-5'
          }`}
          style={{
            backgroundColor: 'var(--nexus-accent)',
            boxShadow: `0 0 10px var(--nexus-accent-glow)`
          }}
        />
        <button
          onClick={() => setActiveView('friends')}
          className="w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-200 relative"
          style={{
            backgroundColor: isDMsActive ? 'var(--nexus-accent)' : 'var(--nexus-bg-surface)',
            color: isDMsActive ? '#000' : '#cbd5e1',
            boxShadow: isDMsActive ? `0 0 15px var(--nexus-accent-glow)` : 'none'
          }}
          title="Direct Transmissions & Friends"
        >
          <MessageSquare className="w-6 h-6" />
          {incomingRequests.length > 0 && (
            <span className="absolute -top-1 -right-1 bg-[#ff0055] text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-black shadow-[0_0_8px_#ff0055]">
              {incomingRequests.length}
            </span>
          )}
        </button>
      </div>

      <div className="w-8 h-px my-1" style={{ backgroundColor: 'var(--nexus-border)' }} />

      {/* Community Servers List */}
      <div className="flex-1 w-full flex flex-col items-center space-y-2 overflow-y-auto overflow-x-hidden no-scrollbar">
        {communities.map((comm) => {
          const isActive = activeView === 'community' && activeCommunity?.id === comm.id;
          return (
            <div key={comm.id} className="relative group">
              <div
                className={`absolute left-0 top-1/2 -translate-y-1/2 w-1 rounded-r transition-all duration-200 ${
                  isActive ? 'h-10' : 'h-0 group-hover:h-5'
                }`}
                style={{
                  backgroundColor: 'var(--nexus-accent)',
                  boxShadow: `0 0 10px var(--nexus-accent-glow)`
                }}
              />
              <button
                onClick={() => selectCommunity(comm.id)}
                className="w-12 h-12 flex items-center justify-center font-bold text-sm transition-all duration-200 overflow-hidden relative rounded-2xl hover:rounded-xl"
                style={{
                  backgroundColor: isActive ? 'var(--nexus-bg-elevated)' : 'var(--nexus-bg-surface)',
                  border: isActive ? `2px solid var(--nexus-accent)` : '1px solid transparent',
                  boxShadow: isActive ? `0 0 12px var(--nexus-accent-glow)` : 'none'
                }}
                title={comm.name}
              >
                {comm.iconUrl ? (
                  <img src={comm.iconUrl} alt={comm.name} className="w-full h-full object-cover" />
                ) : (
                  <span className="font-mono text-xs uppercase tracking-wider text-slate-200">
                    {comm.name.substring(0, 2)}
                  </span>
                )}
              </button>
            </div>
          );
        })}

        {/* Add Community (+) Button */}
        <div className="relative group pt-1">
          <button
            onClick={onOpenCreateCommunity}
            className="w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-200 border border-dashed hover:rounded-xl"
            style={{
              backgroundColor: 'var(--nexus-bg-surface)',
              borderColor: 'var(--nexus-border)',
              color: 'var(--nexus-accent)'
            }}
            title="Create New Community"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        {/* Join with Invite Code Button */}
        <div className="relative group">
          <button
            onClick={onOpenJoinCommunity}
            className="w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-200 border hover:rounded-xl text-slate-400 hover:text-white"
            style={{
              backgroundColor: 'var(--nexus-bg-surface)',
              borderColor: 'var(--nexus-border)'
            }}
            title="Join Community via Invite Code"
          >
            <Compass className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
