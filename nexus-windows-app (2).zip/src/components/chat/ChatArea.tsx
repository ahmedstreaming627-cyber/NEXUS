import React, { useState, useRef, useEffect } from 'react';
import { useChat } from '../../context/ChatContext';
import { useAuth } from '../../context/AuthContext';
import { useCall } from '../../context/CallContext';
import { Message } from '../../types/index';
import { api } from '../../lib/api';
import {
  Phone,
  Video,
  Search,
  Paperclip,
  Smile,
  Send,
  Trash2,
  Edit2,
  CornerUpLeft,
  X,
  FileText,
  Download,
  Users,
  Hash,
  Sparkles
} from 'lucide-react';

export const ChatArea: React.FC = () => {
  const { user } = useAuth();
  const {
    activeView,
    activeDMUser,
    activeChannel,
    messages,
    sendMessage,
    deleteMessage,
    editMessage,
    reactToMessage,
    typingUsers,
    sendTyping
  } = useChat();

  const { startCall } = useCall();

  const [inputContent, setInputContent] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editingContent, setEditingContent] = useState('');
  const [attachments, setAttachments] = useState<any[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Handle typing debounce
  useEffect(() => {
    if (inputContent.length > 0) {
      sendTyping(true);
      const timer = setTimeout(() => sendTyping(false), 2000);
      return () => clearTimeout(timer);
    } else {
      sendTyping(false);
    }
  }, [inputContent]);

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputContent.trim() && attachments.length === 0) return;

    try {
      await sendMessage(inputContent.trim(), attachments, replyingTo?.id);
      setInputContent('');
      setAttachments([]);
      setReplyingTo(null);
    } catch (err) {
      console.error('Send error:', err);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const att = await api.uploadFile(file);
      setAttachments(prev => [...prev, att]);
    } catch (err: any) {
      alert('Upload failed: ' + err.message);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleSaveEdit = async (messageId: string) => {
    if (!editingContent.trim()) return;
    try {
      await editMessage(messageId, editingContent.trim());
      setEditingMessageId(null);
      setEditingContent('');
    } catch (err) {
      console.error('Edit error:', err);
    }
  };

  const formatTimestamp = (time: number) => {
    const date = new Date(time);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const quickEmojis = ['⚡', '🔥', '👍', '❤️', '🚀', '🤖'];

  // Filter messages by search query if present
  const displayMessages = searchQuery.trim()
    ? messages.filter(m => m.content.toLowerCase().includes(searchQuery.toLowerCase()))
    : messages;

  return (
    <div
      className="flex-1 flex flex-col h-full relative transition-colors duration-200"
      style={{ backgroundColor: 'var(--nexus-bg-base)' }}
    >
      {/* Top Header */}
      <div
        className="h-14 border-b px-4 flex items-center justify-between backdrop-blur z-10"
        style={{
          backgroundColor: 'var(--nexus-bg-surface)',
          borderColor: 'var(--nexus-border)'
        }}
      >
        <div className="flex items-center space-x-3">
          {activeView === 'dms' && activeDMUser ? (
            <div className="flex items-center space-x-2.5">
              <div className="relative">
                <img
                  src={activeDMUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                  alt={activeDMUser.displayName}
                  className="w-8 h-8 rounded-full object-cover border border-slate-700"
                />
                <span
                  className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-[#0a0d14] ${
                    activeDMUser.status === 'online' ? 'bg-[#00ff87]' : 'bg-slate-500'
                  }`}
                />
              </div>
              <div>
                <div className="flex items-center space-x-1.5">
                  <span className="font-bold text-slate-100 text-sm">{activeDMUser.displayName}</span>
                  <span className="text-[11px] font-mono text-slate-500">#{activeDMUser.tag}</span>
                </div>
                <div className="text-[10px] text-slate-400 font-mono truncate max-w-xs">
                  {activeDMUser.statusMessage || 'Secured Direct Channel'}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center space-x-2">
              <Hash className="w-5 h-5 text-[#00ff87]" />
              <div>
                <span className="font-bold text-slate-100 text-sm font-mono tracking-wide">
                  {activeChannel?.name || 'general'}
                </span>
                {activeChannel?.topic && (
                  <span className="hidden md:inline ml-3 text-xs text-slate-400 border-l border-slate-700 pl-3">
                    {activeChannel.topic}
                  </span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Right header actions: Calls & Search */}
        <div className="flex items-center space-x-2">
          {activeView === 'dms' && activeDMUser && (
            <>
              <button
                onClick={() => startCall(activeDMUser, 'voice')}
                className="p-2 rounded-lg bg-[#121826] text-slate-300 hover:text-[#00ff87] hover:bg-[#1a2336] transition-colors border border-[#1e2a3f]"
                title="Start Voice Transmission (WebRTC)"
              >
                <Phone className="w-4 h-4" />
              </button>
              <button
                onClick={() => startCall(activeDMUser, 'video')}
                className="p-2 rounded-lg bg-[#121826] text-slate-300 hover:text-[#00e5ff] hover:bg-[#1a2336] transition-colors border border-[#1e2a3f]"
                title="Start Video & Screen Transmission (WebRTC)"
              >
                <Video className="w-4 h-4" />
              </button>
            </>
          )}

          {/* Search in conversation */}
          <div className="relative hidden sm:block">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search stream..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-[#101522] border border-[#1b2538] rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-[#00ff87]/50 w-36 focus:w-52 transition-all font-mono"
            />
          </div>
        </div>
      </div>

      {/* Message Stream */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {displayMessages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500 space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-[#101726] border border-[#1d293d] flex items-center justify-center text-[#00ff87] shadow-[0_0_15px_rgba(0,255,135,0.15)]">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-slate-200 font-bold text-base font-mono">
                {activeView === 'dms' ? 'Encrypted Neural Channel' : `Welcome to #${activeChannel?.name || 'channel'}`}
              </h3>
              <p className="text-xs text-slate-400 max-w-sm mt-1">
                {activeView === 'dms'
                  ? `Transmissions between you and ${activeDMUser?.displayName || 'user'} are synced across all your web and desktop devices.`
                  : 'This is the start of the channel transmissions. All messages sync instantly in real time.'}
              </p>
            </div>
          </div>
        ) : (
          displayMessages.map((msg) => {
            const isMe = msg.senderId === user?.id;
            const isEditing = editingMessageId === msg.id;

            return (
              <div
                key={msg.id}
                className="group relative flex items-start space-x-3 p-2 rounded-xl hover:bg-[#0f1420]/80 transition-colors"
              >
                {/* Avatar */}
                <div className="shrink-0 mt-0.5">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#1b2538] to-[#0d1424] flex items-center justify-center font-mono font-bold text-xs text-slate-300 border border-slate-700/60 overflow-hidden">
                    <img
                      src={
                        isMe
                          ? (user?.avatarUrl || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=160&auto=format&fit=crop&q=80')
                          : (activeDMUser?.avatarUrl || 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=160&auto=format&fit=crop&q=80')
                      }
                      alt="Avatar"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  {/* Reply Context if present */}
                  {msg.replyToMessage && (
                    <div className="flex items-center space-x-1.5 text-slate-500 text-[11px] mb-1 font-mono pl-1 border-l-2 border-slate-700">
                      <CornerUpLeft className="w-3 h-3 text-slate-500" />
                      <span className="font-semibold text-slate-400">@{msg.replyToMessage.senderName}:</span>
                      <span className="truncate">{msg.replyToMessage.content}</span>
                    </div>
                  )}

                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-xs text-slate-200">
                      {isMe ? user?.displayName : (activeDMUser?.displayName || 'Nexus User')}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {formatTimestamp(msg.createdAt)}
                    </span>
                    {msg.editedAt && (
                      <span className="text-[9px] text-slate-600 font-mono">(edited)</span>
                    )}
                  </div>

                  {/* Body text / Editor */}
                  {isEditing ? (
                    <div className="mt-1 space-y-1.5">
                      <input
                        type="text"
                        value={editingContent}
                        onChange={(e) => setEditingContent(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleSaveEdit(msg.id);
                          if (e.key === 'Escape') setEditingMessageId(null);
                        }}
                        className="w-full bg-[#141b2a] border border-[#00ff87]/50 rounded px-2.5 py-1 text-xs text-white focus:outline-none font-mono"
                        autoFocus
                      />
                      <div className="flex items-center space-x-2 text-[10px] font-mono text-slate-400">
                        <span>escape to cancel · enter to save</span>
                        <button
                          onClick={() => handleSaveEdit(msg.id)}
                          className="px-2 py-0.5 rounded bg-[#00ff87] text-black font-bold"
                        >
                          Save
                        </button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-xs text-slate-300 mt-0.5 break-words leading-relaxed whitespace-pre-wrap select-text">
                      {msg.content}
                    </p>
                  )}

                  {/* Attachments */}
                  {msg.attachments && msg.attachments.length > 0 && (
                    <div className="mt-2 space-y-2">
                      {msg.attachments.map((att, idx) => {
                        const isImg = att.type?.startsWith('image/') || att.url?.startsWith('data:image/');
                        return isImg ? (
                          <div key={idx} className="max-w-md rounded-lg overflow-hidden border border-[#1e2a3f]">
                            <img src={att.url} alt={att.name} className="max-h-72 w-auto object-cover rounded" />
                          </div>
                        ) : (
                          <a
                            key={idx}
                            href={att.url}
                            download={att.name}
                            className="inline-flex items-center space-x-2 px-3 py-2 rounded-lg bg-[#141b29] border border-[#202c42] hover:border-[#00ff87]/40 text-xs text-slate-200 transition-colors"
                          >
                            <FileText className="w-4 h-4 text-[#00ff87]" />
                            <span className="font-mono">{att.name}</span>
                            <Download className="w-3.5 h-3.5 text-slate-400" />
                          </a>
                        );
                      })}
                    </div>
                  )}

                  {/* Reactions */}
                  {msg.reactions && msg.reactions.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {msg.reactions.map((rx, rIdx) => {
                        const hasReacted = rx.userIds.includes(user?.id || '');
                        return (
                          <button
                            key={rIdx}
                            onClick={() => reactToMessage(msg.id, rx.emoji)}
                            className={`flex items-center space-x-1 px-2 py-0.5 rounded-md text-xs font-mono transition-colors border ${
                              hasReacted
                                ? 'bg-[#00ff87]/15 border-[#00ff87]/40 text-[#00ff87]'
                                : 'bg-[#101522] border-[#1b2538] text-slate-400 hover:border-slate-600'
                            }`}
                          >
                            <span>{rx.emoji}</span>
                            <span className="text-[10px]">{rx.count}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Hover Message Action Bar */}
                <div className="absolute top-2 right-4 hidden group-hover:flex items-center space-x-1 bg-[#101522] border border-[#1b2538] rounded-lg p-0.5 shadow-xl">
                  {/* Quick Reactions */}
                  {quickEmojis.slice(0, 3).map((em) => (
                    <button
                      key={em}
                      onClick={() => reactToMessage(msg.id, em)}
                      className="px-1.5 py-1 hover:bg-[#182236] rounded text-xs transition-colors"
                    >
                      {em}
                    </button>
                  ))}

                  <div className="h-3 w-px bg-slate-700" />

                  {/* Reply */}
                  <button
                    onClick={() => setReplyingTo(msg)}
                    className="p-1 hover:bg-[#182236] rounded text-slate-400 hover:text-slate-100 transition-colors"
                    title="Reply"
                  >
                    <CornerUpLeft className="w-3.5 h-3.5" />
                  </button>

                  {/* Edit (if me) */}
                  {isMe && (
                    <button
                      onClick={() => {
                        setEditingMessageId(msg.id);
                        setEditingContent(msg.content);
                      }}
                      className="p-1 hover:bg-[#182236] rounded text-slate-400 hover:text-slate-100 transition-colors"
                      title="Edit"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {/* Delete (if me) */}
                  {isMe && (
                    <button
                      onClick={() => deleteMessage(msg.id)}
                      className="p-1 hover:bg-[#2e1019] rounded text-slate-400 hover:text-red-400 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Typing indicator */}
      {typingUsers.length > 0 && (
        <div className="px-4 py-1 text-[11px] font-mono text-[#00ff87] flex items-center space-x-1.5 animate-pulse">
          <span className="w-1.5 h-1.5 rounded-full bg-[#00ff87]" />
          <span>Active neural transmission in progress...</span>
        </div>
      )}

      {/* Bottom Message Input Box */}
      <div
        className="p-3 border-t"
        style={{
          backgroundColor: 'var(--nexus-bg-surface)',
          borderColor: 'var(--nexus-border)'
        }}
      >
        {/* Reply Context preview */}
        {replyingTo && (
          <div
            className="flex items-center justify-between px-3 py-1.5 mb-2 rounded-lg border-l-2 text-xs font-mono text-slate-300"
            style={{
              backgroundColor: 'var(--nexus-bg-elevated)',
              borderLeftColor: 'var(--nexus-accent)'
            }}
          >
            <div className="flex items-center space-x-2 truncate">
              <CornerUpLeft className="w-3.5 h-3.5" style={{ color: 'var(--nexus-accent)' }} />
              <span>Replying to <strong className="text-white">transmission</strong>:</span>
              <span className="text-slate-400 truncate">{replyingTo.content}</span>
            </div>
            <button onClick={() => setReplyingTo(null)} className="hover:text-white p-0.5">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Attachment preview */}
        {attachments.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-2">
            {attachments.map((att, i) => (
              <div
                key={i}
                className="flex items-center space-x-2 border rounded-lg px-2.5 py-1 text-xs font-mono"
                style={{
                  backgroundColor: 'var(--nexus-bg-elevated)',
                  borderColor: 'var(--nexus-border)'
                }}
              >
                <FileText className="w-3.5 h-3.5" style={{ color: 'var(--nexus-accent)' }} />
                <span className="truncate max-w-xs">{att.name}</span>
                <button
                  onClick={() => setAttachments(prev => prev.filter((_, idx) => idx !== i))}
                  className="hover:text-red-400"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        )}

        <form
          onSubmit={handleSend}
          className="relative flex items-center border rounded-xl px-3 py-2 transition-all"
          style={{
            backgroundColor: 'var(--nexus-bg-elevated)',
            borderColor: 'var(--nexus-border)'
          }}
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            className="hidden"
          />

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white transition-colors"
            title="Attach Media or Files"
          >
            <Paperclip className="w-4 h-4" />
          </button>

          <input
            type="text"
            value={inputContent}
            onChange={(e) => setInputContent(e.target.value)}
            placeholder={
              activeView === 'dms'
                ? `Transmit message to @${activeDMUser?.displayName || 'user'}...`
                : `Transmit to #${activeChannel?.name || 'general'}...`
            }
            className="flex-1 bg-transparent px-3 text-xs text-slate-100 placeholder-slate-500 focus:outline-none font-mono"
          />

          {/* Quick Emoji Menu Button */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowEmojiPicker(showEmojiPicker ? null : 'active')}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white transition-colors"
              title="Add Reaction / Emoji"
            >
              <Smile className="w-4 h-4" />
            </button>

            {showEmojiPicker && (
              <div
                className="absolute bottom-full right-0 mb-2 border rounded-xl p-2 shadow-2xl flex items-center space-x-1.5 z-40"
                style={{
                  backgroundColor: 'var(--nexus-bg-surface)',
                  borderColor: 'var(--nexus-border)'
                }}
              >
                {quickEmojis.map(emoji => (
                  <button
                    key={emoji}
                    type="button"
                    onClick={() => {
                      setInputContent(prev => prev + ' ' + emoji);
                      setShowEmojiPicker(null);
                    }}
                    className="p-1.5 hover:bg-white/10 rounded text-base transition-colors"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Send Button */}
          <button
            type="submit"
            disabled={!inputContent.trim() && attachments.length === 0}
            className="ml-2 p-1.5 rounded-lg text-black font-bold disabled:opacity-40 transition-all shadow-md"
            style={{
              backgroundColor: 'var(--nexus-accent)',
              boxShadow: `0 0 10px var(--nexus-accent-glow)`
            }}
            title="Send Transmission"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};

