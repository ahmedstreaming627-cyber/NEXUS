export type UserStatus = 'online' | 'idle' | 'dnd' | 'offline';

export interface User {
  id: string;
  username: string;
  displayName: string;
  tag: string; // e.g. "0042"
  bio: string;
  statusMessage?: string;
  avatarUrl?: string;
  bannerUrl?: string;
  accentColor: string;
  status: UserStatus;
  createdAt: number;
  lastActiveAt: number;
}

export interface Session {
  id: string;
  userId: string;
  token: string;
  deviceName: string;
  platform: 'web' | 'desktop-windows' | 'mobile' | 'electron';
  ipAddress?: string;
  userAgent?: string;
  createdAt: number;
  lastActiveAt: number;
  isCurrent?: boolean;
}

export interface FriendRequest {
  id: string;
  fromUserId: string;
  toUserId: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: number;
}

export interface DirectMessageChannel {
  id: string;
  participantIds: string[]; // 2 user IDs
  createdAt: number;
  lastMessageAt: number;
}

export interface MessageAttachment {
  id: string;
  name: string;
  size: number;
  type: string;
  url: string; // base64 or stored url
}

export interface MessageReaction {
  emoji: string;
  count: number;
  userIds: string[];
}

export interface Message {
  id: string;
  conversationId: string; // DM id or Channel id
  senderId: string;
  content: string;
  attachments?: MessageAttachment[];
  reactions?: MessageReaction[];
  replyToId?: string;
  replyToMessage?: {
    id: string;
    senderId: string;
    senderName: string;
    content: string;
  };
  editedAt?: number;
  createdAt: number;
}

export interface Channel {
  id: string;
  communityId: string;
  name: string;
  topic?: string;
  type: 'text' | 'voice';
  position: number;
  createdAt: number;
}

export interface CommunityMember {
  userId: string;
  communityId: string;
  role: 'owner' | 'admin' | 'member';
  joinedAt: number;
  nickname?: string;
}

export interface Community {
  id: string;
  name: string;
  description: string;
  iconUrl?: string;
  bannerUrl?: string;
  ownerId: string;
  inviteCode: string;
  channels: Channel[];
  createdAt: number;
}

export interface ThemeConfig {
  id: string;
  name: string;
  isCustom?: boolean;
  accent: string;       // e.g. #00ff87
  accentHover: string;  // e.g. #00df76
  accentGlow: string;   // e.g. rgba(0, 255, 135, 0.25)
  bgBase: string;       // e.g. #080b10
  bgSurface: string;    // e.g. #0e131d
  bgElevated: string;   // e.g. #151c2a
  bgHover: string;      // e.g. #1c2538
  border: string;       // e.g. #1e283d
  textPrimary: string;  // e.g. #f1f5f9
  textSecondary: string;// e.g. #94a3b8
}

export interface UserPreferences {
  themeId: string;
  customThemes: ThemeConfig[];
  soundEnabled: boolean;
  soundVolume: number;
  notificationsEnabled: boolean;
  micMuted?: boolean;
  cameraOff?: boolean;
  screenShareQuality?: '1080p' | '720p';
}

export interface CallSignalData {
  callId: string;
  fromUserId: string;
  toUserId?: string;
  channelId?: string; // for group voice channel
  type: 'offer' | 'answer' | 'candidate' | 'call-invite' | 'call-accept' | 'call-reject' | 'call-leave';
  sdp?: any;
  candidate?: any;
  hasVideo?: boolean;
  isScreenSharing?: boolean;
}
