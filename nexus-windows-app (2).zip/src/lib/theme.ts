import { ThemeConfig } from '../types/index';

export const BUILT_IN_THEMES: ThemeConfig[] = [
  {
    id: 'nexus-neon',
    name: 'NEXUS Cyber (Neon Green)',
    accent: '#00ff87',
    accentHover: '#00df76',
    accentGlow: 'rgba(0, 255, 135, 0.35)',
    bgBase: '#080b10',
    bgSurface: '#0e131d',
    bgElevated: '#141b29',
    bgHover: '#1c2538',
    border: '#1f2a3e',
    textPrimary: '#f8fafc',
    textSecondary: '#94a3b8'
  },
  {
    id: 'midnight-cyan',
    name: 'Midnight Electric Cyan',
    accent: '#00e5ff',
    accentHover: '#00c4dc',
    accentGlow: 'rgba(0, 229, 255, 0.35)',
    bgBase: '#050b14',
    bgSurface: '#0a1424',
    bgElevated: '#102038',
    bgHover: '#182e4e',
    border: '#1b3254',
    textPrimary: '#f0f9ff',
    textSecondary: '#7dd3fc'
  },
  {
    id: 'synthwave-violet',
    name: 'Synthwave Ultraviolet',
    accent: '#b026ff',
    accentHover: '#9818e6',
    accentGlow: 'rgba(176, 38, 255, 0.38)',
    bgBase: '#0d0716',
    bgSurface: '#160c24',
    bgElevated: '#221338',
    bgHover: '#301a4e',
    border: '#3c1f62',
    textPrimary: '#faf5ff',
    textSecondary: '#d8b4fe'
  },
  {
    id: 'crimson-protocol',
    name: 'Crimson Protocol',
    accent: '#ff0055',
    accentHover: '#e0004b',
    accentGlow: 'rgba(255, 0, 85, 0.35)',
    bgBase: '#10050b',
    bgSurface: '#1b0913',
    bgElevated: '#280e1c',
    bgHover: '#381427',
    border: '#451830',
    textPrimary: '#fff1f2',
    textSecondary: '#fda4af'
  },
  {
    id: 'amber-terminal',
    name: 'Amber Cyberpunk',
    accent: '#f59e0b',
    accentHover: '#d97706',
    accentGlow: 'rgba(245, 158, 11, 0.35)',
    bgBase: '#0d0904',
    bgSurface: '#181208',
    bgElevated: '#241b0c',
    bgHover: '#332712',
    border: '#3d2e16',
    textPrimary: '#fef3c7',
    textSecondary: '#fcd34d'
  },
  {
    id: 'minimal-slate',
    name: 'Stealth Monochrome',
    accent: '#38bdf8',
    accentHover: '#0284c7',
    accentGlow: 'rgba(56, 189, 248, 0.3)',
    bgBase: '#090a0f',
    bgSurface: '#11131a',
    bgElevated: '#191c26',
    bgHover: '#232736',
    border: '#24283b',
    textPrimary: '#f8fafc',
    textSecondary: '#94a3b8'
  }
];

export function applyThemeTokens(theme: ThemeConfig) {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  root.style.setProperty('--nexus-accent', theme.accent);
  root.style.setProperty('--nexus-accent-hover', theme.accentHover);
  root.style.setProperty('--nexus-accent-glow', theme.accentGlow);
  root.style.setProperty('--nexus-bg-base', theme.bgBase);
  root.style.setProperty('--nexus-bg-surface', theme.bgSurface);
  root.style.setProperty('--nexus-bg-elevated', theme.bgElevated);
  root.style.setProperty('--nexus-bg-hover', theme.bgHover);
  root.style.setProperty('--nexus-border', theme.border);
  root.style.setProperty('--nexus-text-primary', theme.textPrimary);
  root.style.setProperty('--nexus-text-secondary', theme.textSecondary);

  if (document.body) {
    document.body.style.backgroundColor = theme.bgBase;
  }
}
