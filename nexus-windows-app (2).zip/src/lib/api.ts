import { User, Session, FriendRequest, Message, Community, Channel, CommunityMember, DirectMessageChannel } from '../types/index';

const API_BASE = '/api';

class ApiClient {
  private token: string | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.token = localStorage.getItem('nexus_token');
    }
  }

  public setToken(token: string | null) {
    this.token = token;
    if (token) {
      localStorage.setItem('nexus_token', token);
    } else {
      localStorage.removeItem('nexus_token');
    }
  }

  public getToken(): string | null {
    return this.token;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string> || {})
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const res = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      throw new Error(data.error || `HTTP error ${res.status}`);
    }

    return data as T;
  }

  // Auth
  public async register(payload: { username: string; password: string; displayName?: string; platform?: string; deviceName?: string }) {
    const data = await this.request<{ user: User; session: Session }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
    this.setToken(data.session.token);
    return data;
  }

  public async login(payload: { username: string; password: string; platform?: string; deviceName?: string }) {
    const data = await this.request<{ user: User; session: Session }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
    this.setToken(data.session.token);
    return data;
  }

  public async getMe() {
    return this.request<{ user: User; session: Session }>('/auth/me');
  }

  public async logout() {
    try {
      await this.request('/auth/logout', { method: 'POST' });
    } finally {
      this.setToken(null);
    }
  }

  public async getSessions() {
    return this.request<{ sessions: Session[] }>('/auth/sessions');
  }

  public async revokeSession(sessionId: string) {
    return this.request<{ success: boolean }>(`/auth/sessions/${sessionId}`, { method: 'DELETE' });
  }

  public async revokeOtherSessions() {
    return this.request<{ success: boolean }>('/auth/sessions-other', { method: 'DELETE' });
  }

  // User & Profile
  public async updateProfile(updates: Partial<User>) {
    return this.request<{ user: User }>('/users/profile', {
      method: 'PATCH',
      body: JSON.stringify(updates)
    });
  }

  public async updateUsername(username: string) {
    return this.request<{ user: User }>('/users/username', {
      method: 'PATCH',
      body: JSON.stringify({ username })
    });
  }

  public async searchUsers(query: string) {
    return this.request<{ users: User[] }>(`/users/search?q=${encodeURIComponent(query)}`);
  }

  // Friends
  public async getFriends() {
    return this.request<{
      friends: User[];
      incoming: (FriendRequest & { user: User })[];
      outgoing: (FriendRequest & { user: User })[];
    }>('/friends');
  }

  public async sendFriendRequest(target: string) {
    return this.request<{ success: boolean; request?: any; accepted?: boolean; friend?: User }>('/friends/request', {
      method: 'POST',
      body: JSON.stringify({ target })
    });
  }

  public async respondFriendRequest(requestId: string, accept: boolean) {
    return this.request<{ success: boolean; accepted: boolean; friend?: User }>('/friends/respond', {
      method: 'POST',
      body: JSON.stringify({ requestId, accept })
    });
  }

  public async cancelFriendRequest(requestId: string) {
    return this.request<{ success: boolean }>(`/friends/cancel/${requestId}`, { method: 'DELETE' });
  }

  public async removeFriend(friendId: string) {
    return this.request<{ success: boolean }>(`/friends/${friendId}`, { method: 'DELETE' });
  }

  // Direct Messages
  public async getDMs() {
    return this.request<{
      dms: {
        id: string;
        participant: User | null;
        lastMessage: Message | null;
        lastMessageAt: number;
      }[];
    }>('/dms');
  }

  public async openDM(targetUserId: string) {
    return this.request<{ dmId: string; participant: User }>('/dms/open', {
      method: 'POST',
      body: JSON.stringify({ targetUserId })
    });
  }

  public async getDMMessages(channelId: string) {
    return this.request<{ messages: Message[] }>(`/dms/${channelId}/messages`);
  }

  public async sendDMMessage(channelId: string, content: string, attachments?: any[], replyToId?: string) {
    return this.request<{ message: Message }>(`/dms/${channelId}/messages`, {
      method: 'POST',
      body: JSON.stringify({ content, attachments, replyToId })
    });
  }

  // Communities
  public async getCommunities() {
    return this.request<{ communities: Community[] }>('/communities');
  }

  public async createCommunity(name: string, description?: string, iconUrl?: string) {
    return this.request<{ community: Community }>('/communities', {
      method: 'POST',
      body: JSON.stringify({ name, description, iconUrl })
    });
  }

  public async getCommunity(communityId: string) {
    return this.request<{
      community: Community;
      members: (CommunityMember & { user: User })[];
    }>(`/communities/${communityId}`);
  }

  public async createChannel(communityId: string, name: string, type: 'text' | 'voice', topic?: string) {
    return this.request<{ channel: Channel }>(`/communities/${communityId}/channels`, {
      method: 'POST',
      body: JSON.stringify({ name, type, topic })
    });
  }

  public async joinCommunity(inviteCode: string) {
    return this.request<{ success: boolean; community: Community }>('/communities/join', {
      method: 'POST',
      body: JSON.stringify({ inviteCode })
    });
  }

  public async leaveCommunity(communityId: string) {
    return this.request<{ success: boolean }>(`/communities/${communityId}/leave`, {
      method: 'POST'
    });
  }

  // Channels
  public async getChannelMessages(channelId: string) {
    return this.request<{ messages: Message[] }>(`/channels/${channelId}/messages`);
  }

  public async sendChannelMessage(channelId: string, content: string, attachments?: any[], replyToId?: string) {
    return this.request<{ message: Message }>(`/channels/${channelId}/messages`, {
      method: 'POST',
      body: JSON.stringify({ content, attachments, replyToId })
    });
  }

  // Messages Actions
  public async deleteMessage(messageId: string) {
    return this.request<{ success: boolean }>(`/messages/${messageId}`, { method: 'DELETE' });
  }

  public async editMessage(messageId: string, content: string) {
    return this.request<{ message: Message }>(`/messages/${messageId}`, {
      method: 'PATCH',
      body: JSON.stringify({ content })
    });
  }

  public async reactToMessage(messageId: string, emoji: string) {
    return this.request<{ reactions: any[] }>(`/messages/${messageId}/react`, {
      method: 'POST',
      body: JSON.stringify({ emoji })
    });
  }

  // Upload
  public async uploadFile(file: File): Promise<{ id: string; name: string; size: number; type: string; url: string }> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const res = await this.request<{ attachment: any }>('/upload', {
            method: 'POST',
            body: JSON.stringify({
              name: file.name,
              size: file.size,
              type: file.type,
              data: reader.result as string
            })
          });
          resolve(res.attachment);
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }
}

export const api = new ApiClient();
