import { socketClient } from './socket';

const RTC_CONFIG: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' }
  ]
};

export class WebRTCManager {
  private peerConnection: RTCPeerConnection | null = null;
  private localStream: MediaStream | null = null;
  private remoteStream: MediaStream | null = null;
  private screenStream: MediaStream | null = null;
  private targetUserId: string | null = null;
  private isInitiator: boolean = false;
  private pendingCandidates: RTCIceCandidateInit[] = [];

  public onRemoteStream?: (stream: MediaStream) => void;
  public onLocalStream?: (stream: MediaStream) => void;
  public onConnectionStateChange?: (state: RTCPeerConnectionState) => void;
  public onScreenShareEnded?: () => void;

  constructor() {
    this.setupSocketListeners();
  }

  private setupSocketListeners() {
    socketClient.on('call:signal', async (data: any) => {
      const { fromUserId, signalData } = data;
      if (this.targetUserId && fromUserId !== this.targetUserId) return;

      if (signalData.type === 'offer') {
        await this.handleRemoteOffer(fromUserId, signalData.sdp);
      } else if (signalData.type === 'answer') {
        await this.handleRemoteAnswer(signalData.sdp);
      } else if (signalData.type === 'candidate' && signalData.candidate) {
        await this.handleRemoteCandidate(signalData.candidate);
      }
    });
  }

  public async startCall(targetUserId: string, withVideo: boolean = false): Promise<MediaStream> {
    this.targetUserId = targetUserId;
    this.isInitiator = true;

    // Get local user media
    const stream = await this.acquireUserMedia(withVideo);
    this.initPeerConnection();

    // Add local tracks
    stream.getTracks().forEach(track => {
      this.peerConnection!.addTrack(track, stream);
    });

    // Create and send offer
    const offer = await this.peerConnection!.createOffer({
      offerToReceiveAudio: true,
      offerToReceiveVideo: true
    });
    await this.peerConnection!.setLocalDescription(offer);

    socketClient.send('call:signal', {
      targetUserId,
      signalData: {
        type: 'offer',
        sdp: offer
      }
    });

    return stream;
  }

  public async answerCall(targetUserId: string, withVideo: boolean = false): Promise<MediaStream> {
    this.targetUserId = targetUserId;
    this.isInitiator = false;

    const stream = await this.acquireUserMedia(withVideo);
    this.initPeerConnection();

    stream.getTracks().forEach(track => {
      this.peerConnection!.addTrack(track, stream);
    });

    // Process queued candidates if any
    for (const cand of this.pendingCandidates) {
      await this.peerConnection!.addIceCandidate(new RTCIceCandidate(cand));
    }
    this.pendingCandidates = [];

    return stream;
  }

  private initPeerConnection() {
    if (this.peerConnection) {
      this.peerConnection.close();
    }

    this.peerConnection = new RTCPeerConnection(RTC_CONFIG);
    this.remoteStream = new MediaStream();

    this.peerConnection.onicecandidate = (event) => {
      if (event.candidate && this.targetUserId) {
        socketClient.send('call:signal', {
          targetUserId: this.targetUserId,
          signalData: {
            type: 'candidate',
            candidate: event.candidate.toJSON()
          }
        });
      }
    };

    this.peerConnection.ontrack = (event) => {
      event.streams[0]?.getTracks().forEach(track => {
        this.remoteStream?.addTrack(track);
      });
      if (this.onRemoteStream && this.remoteStream) {
        this.onRemoteStream(this.remoteStream);
      }
    };

    this.peerConnection.onconnectionstatechange = () => {
      if (this.peerConnection && this.onConnectionStateChange) {
        this.onConnectionStateChange(this.peerConnection.connectionState);
      }
    };
  }

  private async acquireUserMedia(withVideo: boolean): Promise<MediaStream> {
    try {
      this.localStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        },
        video: withVideo ? { width: { ideal: 1280 }, height: { ideal: 720 } } : false
      });

      if (this.onLocalStream) {
        this.onLocalStream(this.localStream);
      }
      return this.localStream;
    } catch (err: any) {
      console.warn('Failed with video, falling back to audio only:', err);
      // Fallback to audio-only if camera unavailable or denied
      this.localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      if (this.onLocalStream) {
        this.onLocalStream(this.localStream);
      }
      return this.localStream;
    }
  }

  private async handleRemoteOffer(fromUserId: string, sdp: RTCSessionDescriptionInit) {
    if (!this.peerConnection) {
      this.initPeerConnection();
    }
    await this.peerConnection!.setRemoteDescription(new RTCSessionDescription(sdp));
    const answer = await this.peerConnection!.createAnswer();
    await this.peerConnection!.setLocalDescription(answer);

    socketClient.send('call:signal', {
      targetUserId: fromUserId,
      signalData: {
        type: 'answer',
        sdp: answer
      }
    });
  }

  private async handleRemoteAnswer(sdp: RTCSessionDescriptionInit) {
    if (this.peerConnection) {
      await this.peerConnection.setRemoteDescription(new RTCSessionDescription(sdp));
    }
  }

  private async handleRemoteCandidate(candidate: RTCIceCandidateInit) {
    if (this.peerConnection && this.peerConnection.remoteDescription) {
      await this.peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
    } else {
      this.pendingCandidates.push(candidate);
    }
  }

  // Real Screen Sharing
  public async startScreenShare(): Promise<MediaStream | null> {
    if (!this.peerConnection) return null;

    try {
      this.screenStream = await navigator.mediaDevices.getDisplayMedia({
        video: { cursor: 'always' } as any,
        audio: true
      });

      const screenVideoTrack = this.screenStream.getVideoTracks()[0];
      const videoSender = this.peerConnection.getSenders().find(s => s.track && s.track.kind === 'video');

      if (videoSender) {
        videoSender.replaceTrack(screenVideoTrack);
      } else {
        this.peerConnection.addTrack(screenVideoTrack, this.screenStream);
      }

      screenVideoTrack.onended = () => {
        this.stopScreenShare();
      };

      if (this.onLocalStream && this.localStream) {
        // Also emit local stream update with screen share
        this.onLocalStream(this.screenStream);
      }

      return this.screenStream;
    } catch (err) {
      console.warn('Screen share canceled or denied:', err);
      return null;
    }
  }

  public stopScreenShare() {
    if (this.screenStream) {
      this.screenStream.getTracks().forEach(t => t.stop());
      this.screenStream = null;

      // Restore camera track if present
      if (this.peerConnection && this.localStream) {
        const camTrack = this.localStream.getVideoTracks()[0] || null;
        const videoSender = this.peerConnection.getSenders().find(s => s.track && s.track.kind === 'video');
        if (videoSender) {
          videoSender.replaceTrack(camTrack);
        }
        if (this.onLocalStream) {
          this.onLocalStream(this.localStream);
        }
      }

      if (this.onScreenShareEnded) {
        this.onScreenShareEnded();
      }
    }
  }

  public setAudioMuted(muted: boolean) {
    if (this.localStream) {
      this.localStream.getAudioTracks().forEach(track => {
        track.enabled = !muted;
      });
    }
  }

  public setVideoEnabled(enabled: boolean) {
    if (this.localStream) {
      this.localStream.getVideoTracks().forEach(track => {
        track.enabled = enabled;
      });
    }
  }

  public endCall() {
    if (this.screenStream) {
      this.screenStream.getTracks().forEach(t => t.stop());
      this.screenStream = null;
    }

    if (this.localStream) {
      this.localStream.getTracks().forEach(t => t.stop());
      this.localStream = null;
    }

    if (this.peerConnection) {
      this.peerConnection.close();
      this.peerConnection = null;
    }

    this.remoteStream = null;
    this.targetUserId = null;
    this.pendingCandidates = [];
  }

  public getLocalStream(): MediaStream | null {
    return this.screenStream || this.localStream;
  }

  public getRemoteStream(): MediaStream | null {
    return this.remoteStream;
  }
}

export const webrtcManager = new WebRTCManager();
