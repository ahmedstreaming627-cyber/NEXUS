import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { User } from '../types/index';
import { webrtcManager } from '../lib/webrtc';
import { socketClient } from '../lib/socket';
import { soundEngine } from '../lib/sound';
import { useAuth } from './AuthContext';

interface ActiveCallInfo {
  targetUser: User;
  type: 'voice' | 'video';
  callId: string;
  isConnected: boolean;
  startTime?: number;
}

interface IncomingCallInfo {
  caller: User;
  callType: 'voice' | 'video';
  callId: string;
}

interface ActiveVoiceChannelInfo {
  communityId: string;
  channelId: string;
  channelName: string;
}

interface CallContextType {
  activeCall: ActiveCallInfo | null;
  incomingCall: IncomingCallInfo | null;
  activeVoiceChannel: ActiveVoiceChannelInfo | null;
  voiceChannelUsers: User[];
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  isMuted: boolean;
  isCameraOff: boolean;
  isScreenSharing: boolean;
  startCall: (targetUser: User, type: 'voice' | 'video') => Promise<void>;
  acceptCall: () => Promise<void>;
  rejectCall: () => void;
  endCall: () => void;
  toggleMute: () => void;
  toggleCamera: () => void;
  toggleScreenShare: () => Promise<void>;
  joinVoiceChannel: (communityId: string, channelId: string, channelName: string) => Promise<void>;
  leaveVoiceChannel: () => void;
}

const CallContext = createContext<CallContextType | null>(null);

export const CallProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();

  const [activeCall, setActiveCall] = useState<ActiveCallInfo | null>(null);
  const [incomingCall, setIncomingCall] = useState<IncomingCallInfo | null>(null);
  const [activeVoiceChannel, setActiveVoiceChannel] = useState<ActiveVoiceChannelInfo | null>(null);
  const [voiceChannelUsers, setVoiceChannelUsers] = useState<User[]>([]);

  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);

  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isCameraOff, setIsCameraOff] = useState<boolean>(false);
  const [isScreenSharing, setIsScreenSharing] = useState<boolean>(false);

  // Bind WebRTC stream callbacks
  useEffect(() => {
    webrtcManager.onLocalStream = (stream) => {
      setLocalStream(stream);
    };

    webrtcManager.onRemoteStream = (stream) => {
      setRemoteStream(stream);
    };

    webrtcManager.onConnectionStateChange = (state) => {
      if (state === 'connected') {
        soundEngine.stopRingtone();
        soundEngine.playCallConnected();
        setActiveCall(prev => prev ? { ...prev, isConnected: true, startTime: Date.now() } : null);
      } else if (state === 'failed' || state === 'disconnected' || state === 'closed') {
        endCall();
      }
    };

    webrtcManager.onScreenShareEnded = () => {
      setIsScreenSharing(false);
    };
  }, []);

  // Listen to incoming call socket events
  useEffect(() => {
    const unsubIncoming = socketClient.on('call:incoming', (data: { caller: User; callType: 'voice' | 'video'; callId: string }) => {
      setIncomingCall({
        caller: data.caller,
        callType: data.callType,
        callId: data.callId
      });
      soundEngine.startRingtone();
    });

    const unsubResponse = socketClient.on('call:response', (data: { callId: string; accepted: boolean; fromUserId: string }) => {
      soundEngine.stopRingtone();
      if (!data.accepted) {
        soundEngine.playCallEnded();
        setActiveCall(null);
        webrtcManager.endCall();
        setLocalStream(null);
        setRemoteStream(null);
      }
    });

    const unsubEnded = socketClient.on('call:ended', () => {
      soundEngine.stopRingtone();
      soundEngine.playCallEnded();
      setActiveCall(null);
      setIncomingCall(null);
      webrtcManager.endCall();
      setLocalStream(null);
      setRemoteStream(null);
      setIsScreenSharing(false);
    });

    const unsubVoiceJoin = socketClient.on('voice:user_joined', (data: { channelId: string; user: User }) => {
      if (activeVoiceChannel && activeVoiceChannel.channelId === data.channelId) {
        setVoiceChannelUsers(prev => prev.some(u => u.id === data.user.id) ? prev : [...prev, data.user]);
        soundEngine.playCallConnected();
      }
    });

    const unsubVoiceLeave = socketClient.on('voice:user_left', (data: { channelId: string; userId: string }) => {
      if (activeVoiceChannel && activeVoiceChannel.channelId === data.channelId) {
        setVoiceChannelUsers(prev => prev.filter(u => u.id !== data.userId));
        soundEngine.playCallEnded();
      }
    });

    return () => {
      unsubIncoming();
      unsubResponse();
      unsubEnded();
      unsubVoiceJoin();
      unsubVoiceLeave();
    };
  }, [activeVoiceChannel]);

  const startCall = async (targetUser: User, type: 'voice' | 'video') => {
    const callId = 'call_' + Math.random().toString(36).substring(2, 9);
    setActiveCall({
      targetUser,
      type,
      callId,
      isConnected: false
    });

    soundEngine.startRingtone();

    // Send invite to target user
    socketClient.send('call:invite', {
      targetUserId: targetUser.id,
      callId,
      callType: type
    });

    try {
      const stream = await webrtcManager.startCall(targetUser.id, type === 'video');
      setLocalStream(stream);
    } catch (err) {
      console.error('Call initialization failed:', err);
      endCall();
    }
  };

  const acceptCall = async () => {
    if (!incomingCall) return;
    soundEngine.stopRingtone();
    const { caller, callType, callId } = incomingCall;

    setActiveCall({
      targetUser: caller,
      type: callType,
      callId,
      isConnected: true,
      startTime: Date.now()
    });
    setIncomingCall(null);

    socketClient.send('call:respond', {
      targetUserId: caller.id,
      callId,
      accepted: true
    });

    try {
      const stream = await webrtcManager.answerCall(caller.id, callType === 'video');
      setLocalStream(stream);
      soundEngine.playCallConnected();
    } catch (err) {
      console.error('Answering call failed:', err);
      endCall();
    }
  };

  const rejectCall = () => {
    if (!incomingCall) return;
    soundEngine.stopRingtone();
    socketClient.send('call:respond', {
      targetUserId: incomingCall.caller.id,
      callId: incomingCall.callId,
      accepted: false
    });
    setIncomingCall(null);
  };

  const endCall = () => {
    soundEngine.stopRingtone();
    soundEngine.playCallEnded();

    if (activeCall) {
      socketClient.send('call:leave', {
        targetUserId: activeCall.targetUser.id,
        callId: activeCall.callId
      });
    }

    webrtcManager.endCall();
    setActiveCall(null);
    setIncomingCall(null);
    setLocalStream(null);
    setRemoteStream(null);
    setIsScreenSharing(false);
  };

  const toggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    webrtcManager.setAudioMuted(nextMuted);
    soundEngine.playMuteToggled(nextMuted);
  };

  const toggleCamera = () => {
    const nextCameraOff = !isCameraOff;
    setIsCameraOff(nextCameraOff);
    webrtcManager.setVideoEnabled(!nextCameraOff);
  };

  const toggleScreenShare = async () => {
    if (isScreenSharing) {
      webrtcManager.stopScreenShare();
      setIsScreenSharing(false);
    } else {
      const stream = await webrtcManager.startScreenShare();
      if (stream) {
        setIsScreenSharing(true);
        setLocalStream(stream);
      }
    }
  };

  // Group Voice Channel support
  const joinVoiceChannel = async (communityId: string, channelId: string, channelName: string) => {
    if (activeVoiceChannel?.channelId === channelId) return;

    if (activeVoiceChannel) {
      leaveVoiceChannel();
    }

    setActiveVoiceChannel({ communityId, channelId, channelName });
    soundEngine.playCallConnected();

    socketClient.send('voice:join', { channelId });
    if (user) {
      setVoiceChannelUsers([user]);
    }

    try {
      // Connect local mic
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setLocalStream(stream);
    } catch (e) {
      console.warn('Microphone permission denied for voice channel:', e);
    }
  };

  const leaveVoiceChannel = () => {
    if (activeVoiceChannel) {
      socketClient.send('call:leave', { channelId: activeVoiceChannel.channelId });
      soundEngine.playCallEnded();
      setActiveVoiceChannel(null);
      setVoiceChannelUsers([]);
      if (localStream) {
        localStream.getTracks().forEach(t => t.stop());
        setLocalStream(null);
      }
    }
  };

  return (
    <CallContext.Provider
      value={{
        activeCall,
        incomingCall,
        activeVoiceChannel,
        voiceChannelUsers,
        localStream,
        remoteStream,
        isMuted,
        isCameraOff,
        isScreenSharing,
        startCall,
        acceptCall,
        rejectCall,
        endCall,
        toggleMute,
        toggleCamera,
        toggleScreenShare,
        joinVoiceChannel,
        leaveVoiceChannel
      }}
    >
      {children}
    </CallContext.Provider>
  );
};

export const useCall = () => {
  const context = useContext(CallContext);
  if (!context) throw new Error('useCall must be used within a CallProvider');
  return context;
};
