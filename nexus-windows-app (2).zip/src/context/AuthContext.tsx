import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Session, ThemeConfig } from '../types/index';
import { api } from '../lib/api';
import { socketClient } from '../lib/socket';
import { BUILT_IN_THEMES, applyThemeTokens } from '../lib/theme';
import { soundEngine } from '../lib/sound';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  sessions: Session[];
  isLoading: boolean;
  error: string | null;
  isDesktopMode: boolean;
  activeTheme: ThemeConfig;
  customThemes: ThemeConfig[];
  soundEnabled: boolean;
  soundVolume: number;
  login: (username: string, password: string) => Promise<void>;
  register: (username: string, password: string, displayName?: string) => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (updates: Partial<User>) => Promise<void>;
  updateUsername: (username: string) => Promise<void>;
  refreshSessions: () => Promise<void>;
  revokeSession: (sessionId: string) => Promise<void>;
  revokeOtherSessions: () => Promise<void>;
  setTheme: (themeId: string) => void;
  saveCustomTheme: (theme: ThemeConfig) => void;
  deleteCustomTheme: (themeId: string) => void;
  toggleDesktopMode: () => void;
  setSoundEnabled: (enabled: boolean) => void;
  setSoundVolume: (volume: number) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Desktop Client Mode (Auto-detected if in real Electron, or toggleable for full Windows Preview)
  const [isDesktopMode, setIsDesktopMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && (window as any).nexusDesktop?.isElectron) {
      return true;
    }
    return localStorage.getItem('nexus_desktop_mode') === 'true';
  });

  // Themes
  const [customThemes, setCustomThemes] = useState<ThemeConfig[]>(() => {
    try {
      const saved = localStorage.getItem('nexus_custom_themes');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [activeThemeId, setActiveThemeId] = useState<string>(() => {
    return localStorage.getItem('nexus_active_theme') || 'nexus-neon';
  });

  // Sound Preferences
  const [soundEnabled, setSoundEnabledState] = useState<boolean>(() => {
    return localStorage.getItem('nexus_sound_enabled') !== 'false';
  });
  const [soundVolume, setSoundVolumeState] = useState<number>(() => {
    const v = localStorage.getItem('nexus_sound_volume');
    return v ? parseFloat(v) : 0.5;
  });

  const allThemes = [...BUILT_IN_THEMES, ...customThemes];
  const activeTheme = allThemes.find(t => t.id === activeThemeId) || BUILT_IN_THEMES[0];

  // Apply theme tokens
  useEffect(() => {
    applyThemeTokens(activeTheme);
  }, [activeTheme]);

  // Sync sound engine
  useEffect(() => {
    soundEngine.setEnabled(soundEnabled);
    soundEngine.setVolume(soundVolume);
    localStorage.setItem('nexus_sound_enabled', String(soundEnabled));
    localStorage.setItem('nexus_sound_volume', String(soundVolume));
  }, [soundEnabled, soundVolume]);

  const setSoundEnabled = (enabled: boolean) => setSoundEnabledState(enabled);
  const setSoundVolume = (vol: number) => setSoundVolumeState(vol);

  const toggleDesktopMode = () => {
    setIsDesktopMode(prev => {
      const next = !prev;
      localStorage.setItem('nexus_desktop_mode', String(next));
      return next;
    });
  };

  // Check initial session
  useEffect(() => {
    async function initSession() {
      const token = api.getToken();
      if (!token) {
        setIsLoading(false);
        return;
      }

      try {
        const data = await api.getMe();
        setUser(data.user);
        setSession(data.session);

        // Connect WebSocket
        socketClient.connect(
          data.session.token,
          isDesktopMode ? 'desktop-windows' : 'web',
          isDesktopMode ? 'NEXUS Desktop (Windows)' : 'Web Browser'
        );
      } catch (err) {
        console.warn('Session expired or invalid, clearing:', err);
        api.setToken(null);
      } finally {
        setIsLoading(false);
      }
    }

    initSession();
  }, [isDesktopMode]);

  // Socket event listeners for user/session updates
  useEffect(() => {
    const unsubUser = socketClient.on('user:updated', (data: { user: User }) => {
      if (user && data.user.id === user.id) {
        setUser(data.user);
      }
    });

    const unsubRevoked = socketClient.on('session:revoked', () => {
      api.setToken(null);
      setUser(null);
      setSession(null);
      socketClient.disconnect();
    });

    return () => {
      unsubUser();
      unsubRevoked();
    };
  }, [user]);

  const login = async (username: string, password: string) => {
    setError(null);
    try {
      const res = await api.login({
        username,
        password,
        platform: isDesktopMode ? 'desktop-windows' : 'web',
        deviceName: isDesktopMode ? 'NEXUS Desktop (Windows)' : 'Web Browser'
      });
      setUser(res.user);
      setSession(res.session);
      socketClient.connect(
        res.session.token,
        isDesktopMode ? 'desktop-windows' : 'web',
        isDesktopMode ? 'NEXUS Desktop (Windows)' : 'Web Browser'
      );
    } catch (err: any) {
      setError(err.message || 'Login failed');
      throw err;
    }
  };

  const register = async (username: string, password: string, displayName?: string) => {
    setError(null);
    try {
      const res = await api.register({
        username,
        password,
        displayName,
        platform: isDesktopMode ? 'desktop-windows' : 'web',
        deviceName: isDesktopMode ? 'NEXUS Desktop (Windows)' : 'Web Browser'
      });
      setUser(res.user);
      setSession(res.session);
      socketClient.connect(
        res.session.token,
        isDesktopMode ? 'desktop-windows' : 'web',
        isDesktopMode ? 'NEXUS Desktop (Windows)' : 'Web Browser'
      );
    } catch (err: any) {
      setError(err.message || 'Registration failed');
      throw err;
    }
  };

  const logout = async () => {
    try {
      await api.logout();
    } catch {}
    setUser(null);
    setSession(null);
    socketClient.disconnect();
  };

  const updateProfile = async (updates: Partial<User>) => {
    const res = await api.updateProfile(updates);
    setUser(res.user);
  };

  const updateUsername = async (username: string) => {
    const res = await api.updateUsername(username);
    setUser(res.user);
  };

  const refreshSessions = async () => {
    const res = await api.getSessions();
    setSessions(res.sessions);
  };

  const revokeSession = async (sessionId: string) => {
    await api.revokeSession(sessionId);
    setSessions(prev => prev.filter(s => s.id !== sessionId));
  };

  const revokeOtherSessions = async () => {
    await api.revokeOtherSessions();
    if (session) {
      setSessions([session]);
    }
  };

  const setTheme = (themeId: string) => {
    setActiveThemeId(themeId);
    localStorage.setItem('nexus_active_theme', themeId);
    const all = [...BUILT_IN_THEMES, ...customThemes];
    const target = all.find(t => t.id === themeId) || BUILT_IN_THEMES[0];
    applyThemeTokens(target);
    if (user && target.accent) {
      updateProfile({ accentColor: target.accent }).catch((e) => console.warn('Auto-sync accent color error:', e));
    }
  };

  const saveCustomTheme = (theme: ThemeConfig) => {
    setCustomThemes(prev => {
      const filtered = prev.filter(t => t.id !== theme.id);
      const next = [...filtered, theme];
      localStorage.setItem('nexus_custom_themes', JSON.stringify(next));
      return next;
    });
    setTheme(theme.id);
  };

  const deleteCustomTheme = (themeId: string) => {
    setCustomThemes(prev => {
      const next = prev.filter(t => t.id !== themeId);
      localStorage.setItem('nexus_custom_themes', JSON.stringify(next));
      return next;
    });
    if (activeThemeId === themeId) {
      setTheme('nexus-neon');
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        sessions,
        isLoading,
        error,
        isDesktopMode,
        activeTheme,
        customThemes,
        soundEnabled,
        soundVolume,
        login,
        register,
        logout,
        updateProfile,
        updateUsername,
        refreshSessions,
        revokeSession,
        revokeOtherSessions,
        setTheme,
        saveCustomTheme,
        deleteCustomTheme,
        toggleDesktopMode,
        setSoundEnabled,
        setSoundVolume
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
