import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User, Message, Community, Channel, CommunityMember, FriendRequest, DirectMessageChannel } from '../types/index';
import { api } from '../lib/api';
import { socketClient } from '../lib/socket';
import { soundEngine } from '../lib/sound';
import { useAuth } from './AuthContext';

interface ChatContextType {
  activeView: 'dms' | 'community' | 'friends' | 'settings';
  setActiveView: (view: 'dms' | 'community' | 'friends' | 'settings') => void;
  activeDMId: string | null;
  activeDMUser: User | null;
  activeCommunity: Community | null;
  activeChannel: Channel | null;
  communities: Community[];
  dms: { id: string; participant: User | null; lastMessage: Message | null; lastMessageAt: number }[];
  friends: User[];
  incomingRequests: (FriendRequest & { user: User })[];
  outgoingRequests: (FriendRequest & { user: User })[];
  messages: Message[];
  members: (CommunityMember & { user: User })[];
  typingUsers: string[];
  isLoadingMessages: boolean;
  selectDM: (dmId: string, participant: User) => Promise<void>;
  openDMWithUser: (userId: string) => Promise<void>;
  selectCommunity: (communityId: string) => Promise<void>;
  selectChannel: (channel: Channel) => Promise<void>;
  sendMessage: (content: string, attachments?: any[], replyToId?: string) => Promise<void>;
  deleteMessage: (messageId: string) => Promise<void>;
  editMessage: (messageId: string, content: string) => Promise<void>;
  reactToMessage: (messageId: string, emoji: string) => Promise<void>;
  createCommunity: (name: string, description?: string, iconUrl?: string) => Promise<Community>;
  createChannel: (name: string, type: 'text' | 'voice', topic?: string) => Promise<Channel>;
  joinCommunity: (inviteCode: string) => Promise<void>;
  leaveCommunity: (communityId: string) => Promise<void>;
  sendFriendRequest: (target: string) => Promise<{ success: boolean; message?: string }>;
  respondFriendRequest: (requestId: string, accept: boolean) => Promise<void>;
  cancelFriendRequest: (requestId: string) => Promise<void>;
  removeFriend: (friendId: string) => Promise<void>;
  sendTyping: (isTyping: boolean) => void;
  refreshCommunities: () => Promise<void>;
  refreshFriends: () => Promise<void>;
  refreshDMs: () => Promise<void>;
}

const ChatContext = createContext<ChatContextType | null>(null);

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();

  const [activeView, setActiveView] = useState<'dms' | 'community' | 'friends' | 'settings'>('friends');
  const [activeDMId, setActiveDMId] = useState<string | null>(null);
  const [activeDMUser, setActiveDMUser] = useState<User | null>(null);
  const [activeCommunity, setActiveCommunity] = useState<Community | null>(null);
  const [activeChannel, setActiveChannel] = useState<Channel | null>(null);

  const [communities, setCommunities] = useState<Community[]>([]);
  const [dms, setDms] = useState<{ id: string; participant: User | null; lastMessage: Message | null; lastMessageAt: number }[]>([]);
  const [friends, setFriends] = useState<User[]>([]);
  const [incomingRequests, setIncomingRequests] = useState<(FriendRequest & { user: User })[]>([]);
  const [outgoingRequests, setOutgoingRequests] = useState<(FriendRequest & { user: User })[]>([]);

  const [messages, setMessages] = useState<Message[]>([]);
  const [members, setMembers] = useState<(CommunityMember & { user: User })[]>([]);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const [isLoadingMessages, setIsLoadingMessages] = useState<boolean>(false);

  // Load all initial data when user logs in
  const refreshCommunities = useCallback(async () => {
    if (!user) return;
    try {
      const res = await api.getCommunities();
      setCommunities(res.communities);
    } catch {}
  }, [user]);

  const refreshFriends = useCallback(async () => {
    if (!user) return;
    try {
      const res = await api.getFriends();
      setFriends(res.friends);
      setIncomingRequests(res.incoming);
      setOutgoingRequests(res.outgoing);
    } catch {}
  }, [user]);

  const refreshDMs = useCallback(async () => {
    if (!user) return;
    try {
      const res = await api.getDMs();
      setDms(res.dms);
    } catch {}
  }, [user]);

  useEffect(() => {
    if (user) {
      refreshCommunities();
      refreshFriends();
      refreshDMs();
    } else {
      setCommunities([]);
      setDms([]);
      setFriends([]);
      setMessages([]);
      setActiveDMId(null);
      setActiveCommunity(null);
      setActiveChannel(null);
    }
  }, [user, refreshCommunities, refreshFriends, refreshDMs]);

  // Load messages when conversation switches
  const loadMessages = useCallback(async (conversationId: string, type: 'dm' | 'channel') => {
    setIsLoadingMessages(true);
    try {
      if (type === 'dm') {
        const res = await api.getDMMessages(conversationId);
        setMessages(res.messages);
      } else {
        const res = await api.getChannelMessages(conversationId);
        setMessages(res.messages);
      }
    } catch (err) {
      console.error('Failed to load messages:', err);
      setMessages([]);
    } finally {
      setIsLoadingMessages(false);
    }
  }, []);

  // Selection actions
  const selectDM = async (dmId: string, participant: User) => {
    setActiveView('dms');
    setActiveDMId(dmId);
    setActiveDMUser(participant);
    setActiveCommunity(null);
    setActiveChannel(null);
    await loadMessages(dmId, 'dm');
  };

  const openDMWithUser = async (targetUserId: string) => {
    try {
      const res = await api.openDM(targetUserId);
      await refreshDMs();
      await selectDM(res.dmId, res.participant);
    } catch (err) {
      console.error('Error opening DM:', err);
    }
  };

  const selectCommunity = async (communityId: string) => {
    try {
      const res = await api.getCommunity(communityId);
      setActiveCommunity(res.community);
      setMembers(res.members);
      setActiveView('community');
      setActiveDMId(null);
      setActiveDMUser(null);

      // Default to first text channel
      const firstTextChan = res.community.channels.find(c => c.type === 'text') || res.community.channels[0];
      if (firstTextChan) {
        setActiveChannel(firstTextChan);
        await loadMessages(firstTextChan.id, 'channel');
      }
    } catch (err) {
      console.error('Failed to open community:', err);
    }
  };

  const selectChannel = async (channel: Channel) => {
    setActiveChannel(channel);
    if (channel.type === 'text') {
      await loadMessages(channel.id, 'channel');
    }
  };

  // Message Sending & Actions
  const sendMessage = async (content: string, attachments?: any[], replyToId?: string) => {
    if (!user) return;
    try {
      soundEngine.playMessageSent();
      if (activeView === 'dms' && activeDMId) {
        const res = await api.sendDMMessage(activeDMId, content, attachments, replyToId);
        setMessages(prev => {
          if (prev.some(m => m.id === res.message.id)) return prev;
          return [...prev, res.message];
        });
        refreshDMs();
      } else if (activeView === 'community' && activeChannel) {
        const res = await api.sendChannelMessage(activeChannel.id, content, attachments, replyToId);
        setMessages(prev => {
          if (prev.some(m => m.id === res.message.id)) return prev;
          return [...prev, res.message];
        });
      }
    } catch (err) {
      console.error('Failed to send message:', err);
      throw err;
    }
  };

  const deleteMessage = async (messageId: string) => {
    await api.deleteMessage(messageId);
    setMessages(prev => prev.filter(m => m.id !== messageId));
  };

  const editMessage = async (messageId: string, content: string) => {
    const res = await api.editMessage(messageId, content);
    setMessages(prev => prev.map(m => m.id === messageId ? res.message : m));
  };

  const reactToMessage = async (messageId: string, emoji: string) => {
    const res = await api.reactToMessage(messageId, emoji);
    setMessages(prev => prev.map(m => m.id === messageId ? { ...m, reactions: res.reactions } : m));
  };

  const sendTyping = (isTyping: boolean) => {
    const convId = activeView === 'dms' ? activeDMId : activeChannel?.id;
    if (convId) {
      socketClient.send('typing', { conversationId: convId, isTyping });
    }
  };

  // Community Management
  const createCommunity = async (name: string, description?: string, iconUrl?: string) => {
    const res = await api.createCommunity(name, description, iconUrl);
    setCommunities(prev => [...prev, res.community]);
    await selectCommunity(res.community.id);
    return res.community;
  };

  const createChannel = async (name: string, type: 'text' | 'voice', topic?: string) => {
    if (!activeCommunity) throw new Error('No active community');
    const res = await api.createChannel(activeCommunity.id, name, type, topic);
    setActiveCommunity(prev => {
      if (!prev) return prev;
      return { ...prev, channels: [...prev.channels, res.channel] };
    });
    return res.channel;
  };

  const joinCommunity = async (inviteCode: string) => {
    const res = await api.joinCommunity(inviteCode);
    await refreshCommunities();
    await selectCommunity(res.community.id);
  };

  const leaveCommunity = async (communityId: string) => {
    await api.leaveCommunity(communityId);
    setCommunities(prev => prev.filter(c => c.id !== communityId));
    if (activeCommunity?.id === communityId) {
      setActiveCommunity(null);
      setActiveChannel(null);
      setActiveView('friends');
    }
  };

  // Friends Actions
  const sendFriendRequest = async (target: string) => {
    const res = await api.sendFriendRequest(target);
    await refreshFriends();
    return { success: true };
  };

  const respondFriendRequest = async (requestId: string, accept: boolean) => {
    await api.respondFriendRequest(requestId, accept);
    if (accept) {
      soundEngine.playFriendAlert();
    }
    await refreshFriends();
  };

  const cancelFriendRequest = async (requestId: string) => {
    await api.cancelFriendRequest(requestId);
    await refreshFriends();
  };

  const removeFriend = async (friendId: string) => {
    await api.removeFriend(friendId);
    await refreshFriends();
  };

  // Real-Time Socket Event Wireup
  useEffect(() => {
    const unsubMsg = socketClient.on('chat:message', (data: { message: Message; conversationId: string; conversationType: string }) => {
      const isCurrentConversation =
        (activeView === 'dms' && activeDMId === data.conversationId) ||
        (activeView === 'community' && activeChannel?.id === data.conversationId);

      if (isCurrentConversation) {
        setMessages(prev => {
          if (prev.some(m => m.id === data.message.id)) return prev;
          return [...prev, data.message];
        });
      }

      if (data.message.senderId !== user?.id) {
        soundEngine.playMessageReceived();
      }

      if (data.conversationType === 'dm') {
        refreshDMs();
      }
    });

    const unsubMsgDel = socketClient.on('chat:message_deleted', (data: { messageId: string }) => {
      setMessages(prev => prev.filter(m => m.id !== data.messageId));
    });

    const unsubMsgEdit = socketClient.on('chat:message_edited', (data: { message: Message }) => {
      setMessages(prev => prev.map(m => m.id === data.message.id ? data.message : m));
    });

    const unsubReaction = socketClient.on('chat:reaction_updated', (data: { messageId: string; reactions: any[] }) => {
      setMessages(prev => prev.map(m => m.id === data.messageId ? { ...m, reactions: data.reactions } : m));
    });

    const unsubPresence = socketClient.on('presence:update', (data: { userId: string; status: any }) => {
      setFriends(prev => prev.map(f => f.id === data.userId ? { ...f, status: data.status } : f));
      setMembers(prev => prev.map(m => m.userId === data.userId && m.user ? { ...m, user: { ...m.user, status: data.status } } : m));
    });

    const unsubFriendReq = socketClient.on('friend:request_received', (data: { request: any }) => {
      soundEngine.playFriendAlert();
      refreshFriends();
    });

    const unsubFriendAcc = socketClient.on('friend:accepted', (data: { user: User }) => {
      soundEngine.playFriendAlert();
      refreshFriends();
    });

    const unsubFriendRem = socketClient.on('friend:removed', () => {
      refreshFriends();
    });

    const unsubTyping = socketClient.on('typing', (data: { conversationId: string; userId: string; isTyping: boolean }) => {
      const isCurrentConversation =
        (activeView === 'dms' && activeDMId === data.conversationId) ||
        (activeView === 'community' && activeChannel?.id === data.conversationId);

      if (isCurrentConversation) {
        setTypingUsers(prev => {
          if (data.isTyping) {
            return prev.includes(data.userId) ? prev : [...prev, data.userId];
          } else {
            return prev.filter(id => id !== data.userId);
          }
        });
      }
    });

    return () => {
      unsubMsg();
      unsubMsgDel();
      unsubMsgEdit();
      unsubReaction();
      unsubPresence();
      unsubFriendReq();
      unsubFriendAcc();
      unsubFriendRem();
      unsubTyping();
    };
  }, [activeView, activeDMId, activeChannel, user, refreshDMs, refreshFriends]);

  return (
    <ChatContext.Provider
      value={{
        activeView,
        setActiveView,
        activeDMId,
        activeDMUser,
        activeCommunity,
        activeChannel,
        communities,
        dms,
        friends,
        incomingRequests,
        outgoingRequests,
        messages,
        members,
        typingUsers,
        isLoadingMessages,
        selectDM,
        openDMWithUser,
        selectCommunity,
        selectChannel,
        sendMessage,
        deleteMessage,
        editMessage,
        reactToMessage,
        createCommunity,
        createChannel,
        joinCommunity,
        leaveCommunity,
        sendFriendRequest,
        respondFriendRequest,
        cancelFriendRequest,
        removeFriend,
        sendTyping,
        refreshCommunities,
        refreshFriends,
        refreshDMs
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) throw new Error('useChat must be used within a ChatProvider');
  return context;
};
