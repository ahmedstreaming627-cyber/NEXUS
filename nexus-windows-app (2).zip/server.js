// server.ts
import express from "express";
import http from "http";
import { WebSocketServer, WebSocket } from "ws";
import path from "path";
import fs from "fs";
import bcrypt from "bcryptjs";
import crypto from "crypto";
var PORT = parseInt(process.env.PORT || "3000", 10);
var DATA_DIR = path.resolve(process.cwd(), "data");
var DB_FILE = path.join(DATA_DIR, "nexus-store.json");
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
var db = {
  users: [],
  sessions: [],
  friendRequests: [],
  friendships: [],
  dmChannels: [],
  messages: [],
  communities: [],
  communityMembers: []
};
function loadDB() {
  if (fs.existsSync(DB_FILE)) {
    try {
      const raw = fs.readFileSync(DB_FILE, "utf-8");
      db = JSON.parse(raw);
    } catch (e) {
      console.error("Failed to load DB file, reinitializing", e);
      initDefaultData();
    }
  } else {
    initDefaultData();
  }
}
function saveDB() {
  try {
    const tempFile = DB_FILE + ".tmp";
    fs.writeFileSync(tempFile, JSON.stringify(db, null, 2), "utf-8");
    fs.renameSync(tempFile, DB_FILE);
  } catch (err) {
    console.error("Error saving database:", err);
  }
}
function initDefaultData() {
  const salt = bcrypt.genSaltSync(10);
  const demoHash = bcrypt.hashSync("nexus123", salt);
  const demoUser1 = {
    id: "user_nexus_core",
    username: "nexus_admin",
    displayName: "NEXUS Sentinel",
    tag: "0001",
    bio: "Core AI Systems Operator & Nexus Platform Administrator. Welcome to the neural network.",
    statusMessage: "Systems Optimal \xB7 100% Signal",
    accentColor: "#00ff87",
    status: "online",
    createdAt: Date.now() - 864e5 * 30,
    lastActiveAt: Date.now(),
    passwordHash: demoHash,
    avatarUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=160&auto=format&fit=crop&q=80",
    bannerUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&auto=format&fit=crop&q=80"
  };
  const demoUser2 = {
    id: "user_cyber_val",
    username: "valkyrie",
    displayName: "Valkyrie.sys",
    tag: "1337",
    bio: "Hardware hacker & grid speedrunner. Pinging from Neo Tokyo.",
    statusMessage: "Compiling kernel updates...",
    accentColor: "#00e5ff",
    status: "online",
    createdAt: Date.now() - 864e5 * 15,
    lastActiveAt: Date.now(),
    passwordHash: demoHash,
    avatarUrl: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=160&auto=format&fit=crop&q=80",
    bannerUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80"
  };
  const demoCommunityId = "comm_nexus_prime";
  const generalChannel = {
    id: "chan_general",
    communityId: demoCommunityId,
    name: "general-grid",
    topic: "Global nexus hub for network announcements and cyber transmissions",
    type: "text",
    position: 0,
    createdAt: Date.now() - 864e5 * 10
  };
  const devChannel = {
    id: "chan_dev",
    communityId: demoCommunityId,
    name: "dev-terminal",
    topic: "Desktop app builds, protocol discussions, and WebRTC telemetry",
    type: "text",
    position: 1,
    createdAt: Date.now() - 864e5 * 10
  };
  const voiceChannel = {
    id: "chan_voice_lounge",
    communityId: demoCommunityId,
    name: "Neural Lounge",
    topic: "Low-latency spatial voice & screen transmission",
    type: "voice",
    position: 2,
    createdAt: Date.now() - 864e5 * 10
  };
  const demoCommunity = {
    id: demoCommunityId,
    name: "NEXUS Prime HQ",
    description: "The premier verified node of the NEXUS cross-platform ecosystem.",
    iconUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=160&auto=format&fit=crop&q=80",
    bannerUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&auto=format&fit=crop&q=80",
    ownerId: demoUser1.id,
    inviteCode: "NEXUS-01",
    channels: [generalChannel, devChannel, voiceChannel],
    createdAt: Date.now() - 864e5 * 10
  };
  const initialMsg = {
    id: "msg_welcome_1",
    conversationId: generalChannel.id,
    senderId: demoUser1.id,
    content: "Welcome to **NEXUS**. All clients (Web and Windows Desktop) are fully synchronized through our unified real-time infrastructure. Real audio/video WebRTC and screen sharing are active.",
    reactions: [{ emoji: "\u26A1", count: 3, userIds: [demoUser1.id, demoUser2.id] }],
    createdAt: Date.now() - 36e5
  };
  db = {
    users: [demoUser1, demoUser2],
    sessions: [],
    friendRequests: [],
    friendships: [{ userA: demoUser1.id, userB: demoUser2.id, createdAt: Date.now() - 864e5 }],
    dmChannels: [],
    messages: [initialMsg],
    communities: [demoCommunity],
    communityMembers: [
      { userId: demoUser1.id, communityId: demoCommunityId, role: "owner", joinedAt: Date.now() - 864e5 * 10 },
      { userId: demoUser2.id, communityId: demoCommunityId, role: "admin", joinedAt: Date.now() - 864e5 * 5 }
    ]
  };
  saveDB();
}
loadDB();
var app = express();
app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));
var server = http.createServer(app);
var wss = new WebSocketServer({ server, path: "/ws" });
var activeConnections = /* @__PURE__ */ new Map();
function sendToUser(userId, data) {
  const userSockets = activeConnections.get(userId);
  if (!userSockets) return;
  const payload = JSON.stringify(data);
  for (const client of userSockets) {
    if (client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(payload);
    }
  }
}
function broadcastToUsers(userIds, data, excludeUserId) {
  const payload = JSON.stringify(data);
  for (const uid of userIds) {
    if (excludeUserId && uid === excludeUserId) continue;
    const userSockets = activeConnections.get(uid);
    if (userSockets) {
      for (const client of userSockets) {
        if (client.ws.readyState === WebSocket.OPEN) {
          client.ws.send(payload);
        }
      }
    }
  }
}
function broadcastGlobal(data) {
  const payload = JSON.stringify(data);
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(payload);
    }
  });
}
wss.on("connection", (ws, req) => {
  let authenticatedUserId = null;
  let currentSessionId = null;
  ws.on("message", (messageRaw) => {
    try {
      const msg = JSON.parse(messageRaw.toString());
      if (msg.type === "auth") {
        const { token, platform, deviceName } = msg;
        const session = db.sessions.find((s) => s.token === token);
        if (!session) {
          ws.send(JSON.stringify({ type: "auth:error", error: "Invalid or expired session token" }));
          return;
        }
        authenticatedUserId = session.userId;
        currentSessionId = session.id;
        session.lastActiveAt = Date.now();
        if (platform) session.platform = platform;
        if (deviceName) session.deviceName = deviceName;
        saveDB();
        if (!activeConnections.has(authenticatedUserId)) {
          activeConnections.set(authenticatedUserId, /* @__PURE__ */ new Set());
        }
        activeConnections.get(authenticatedUserId).add({ ws, sessionId: session.id, platform: session.platform });
        const user = db.users.find((u) => u.id === authenticatedUserId);
        if (user && user.status === "offline") {
          user.status = "online";
          user.lastActiveAt = Date.now();
          saveDB();
          broadcastGlobal({ type: "presence:update", userId: user.id, status: user.status });
        }
        ws.send(JSON.stringify({
          type: "auth:success",
          user: sanitizeUser(user),
          session
        }));
        return;
      }
      if (!authenticatedUserId) return;
      if (msg.type === "call:signal") {
        const { targetUserId, signalData } = msg;
        if (targetUserId) {
          sendToUser(targetUserId, {
            type: "call:signal",
            fromUserId: authenticatedUserId,
            signalData
          });
        }
      } else if (msg.type === "call:invite") {
        const { targetUserId, callType, callId } = msg;
        const caller = db.users.find((u) => u.id === authenticatedUserId);
        sendToUser(targetUserId, {
          type: "call:incoming",
          callId,
          caller: sanitizeUser(caller),
          callType: callType || "voice"
        });
      } else if (msg.type === "call:respond") {
        const { targetUserId, accepted, callId } = msg;
        sendToUser(targetUserId, {
          type: "call:response",
          callId,
          fromUserId: authenticatedUserId,
          accepted
        });
      } else if (msg.type === "call:leave") {
        const { targetUserId, channelId, callId } = msg;
        if (targetUserId) {
          sendToUser(targetUserId, {
            type: "call:ended",
            callId,
            fromUserId: authenticatedUserId
          });
        } else if (channelId) {
          broadcastGlobal({
            type: "voice:user_left",
            channelId,
            userId: authenticatedUserId
          });
        }
      } else if (msg.type === "voice:join") {
        const { channelId } = msg;
        broadcastGlobal({
          type: "voice:user_joined",
          channelId,
          user: sanitizeUser(db.users.find((u) => u.id === authenticatedUserId))
        });
      } else if (msg.type === "typing") {
        const { conversationId, isTyping } = msg;
        const dm = db.dmChannels.find((d) => d.id === conversationId);
        if (dm) {
          const otherId = dm.participantIds.find((p) => p !== authenticatedUserId);
          if (otherId) {
            sendToUser(otherId, {
              type: "typing",
              conversationId,
              userId: authenticatedUserId,
              isTyping
            });
          }
        }
      }
    } catch (err) {
      console.error("WebSocket message parsing error:", err);
    }
  });
  ws.on("close", () => {
    if (authenticatedUserId && currentSessionId) {
      const set = activeConnections.get(authenticatedUserId);
      if (set) {
        for (const conn of set) {
          if (conn.ws === ws) {
            set.delete(conn);
          }
        }
        if (set.size === 0) {
          activeConnections.delete(authenticatedUserId);
          setTimeout(() => {
            if (!activeConnections.has(authenticatedUserId)) {
              const u = db.users.find((user) => user.id === authenticatedUserId);
              if (u && u.status !== "dnd") {
                u.status = "offline";
                saveDB();
                broadcastGlobal({ type: "presence:update", userId: u.id, status: "offline" });
              }
            }
          }, 3e3);
        }
      }
    }
  });
});
function sanitizeUser(user) {
  const { passwordHash, ...rest } = user;
  return rest;
}
function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    res.status(401).json({ error: "Missing or malformed Authorization header" });
    return;
  }
  const token = authHeader.split(" ")[1];
  const session = db.sessions.find((s) => s.token === token);
  if (!session) {
    res.status(401).json({ error: "Invalid or revoked session token" });
    return;
  }
  const user = db.users.find((u) => u.id === session.userId);
  if (!user) {
    res.status(401).json({ error: "User associated with session not found" });
    return;
  }
  session.lastActiveAt = Date.now();
  user.lastActiveAt = Date.now();
  req.user = user;
  req.session = session;
  next();
}
var api = express.Router();
api.post("/auth/register", async (req, res) => {
  try {
    const { username, password, displayName, platform, deviceName } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: "Username and password are required" });
    }
    const cleanUsername = username.trim().toLowerCase();
    if (!/^[a-z0-9_-]{3,24}$/.test(cleanUsername)) {
      return res.status(400).json({ error: "Username must be 3-24 characters containing only lowercase letters, numbers, hyphens, and underscores" });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: "Password must be at least 6 characters" });
    }
    const existing = db.users.find((u) => u.username.toLowerCase() === cleanUsername);
    if (existing) {
      return res.status(409).json({ error: "Username is already claimed. Please choose another." });
    }
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);
    const tag = Math.floor(1e3 + Math.random() * 9e3).toString();
    const newUser = {
      id: "usr_" + crypto.randomBytes(8).toString("hex"),
      username: cleanUsername,
      displayName: displayName?.trim() || cleanUsername,
      tag,
      bio: "New explorer in the NEXUS grid.",
      accentColor: "#00ff87",
      status: "online",
      createdAt: Date.now(),
      lastActiveAt: Date.now(),
      passwordHash
    };
    db.users.push(newUser);
    const sessionToken = "nexus_" + crypto.randomBytes(24).toString("hex");
    const newSession = {
      id: "sess_" + crypto.randomBytes(8).toString("hex"),
      userId: newUser.id,
      token: sessionToken,
      deviceName: deviceName || "Web Browser",
      platform: platform || "web",
      createdAt: Date.now(),
      lastActiveAt: Date.now()
    };
    db.sessions.push(newSession);
    if (db.communities.length > 0) {
      db.communityMembers.push({
        userId: newUser.id,
        communityId: db.communities[0].id,
        role: "member",
        joinedAt: Date.now()
      });
    }
    saveDB();
    res.status(201).json({
      user: sanitizeUser(newUser),
      session: newSession
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
api.post("/auth/login", async (req, res) => {
  try {
    const { username, password, platform, deviceName } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: "Username and password are required" });
    }
    const cleanUsername = username.trim().toLowerCase();
    const user = db.users.find((u) => u.username.toLowerCase() === cleanUsername);
    if (!user) {
      return res.status(401).json({ error: "Invalid username or password" });
    }
    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      return res.status(401).json({ error: "Invalid username or password" });
    }
    const sessionToken = "nexus_" + crypto.randomBytes(24).toString("hex");
    const newSession = {
      id: "sess_" + crypto.randomBytes(8).toString("hex"),
      userId: user.id,
      token: sessionToken,
      deviceName: deviceName || (platform === "desktop-windows" ? "NEXUS Desktop (Windows)" : "Web Client"),
      platform: platform || "web",
      createdAt: Date.now(),
      lastActiveAt: Date.now()
    };
    db.sessions.push(newSession);
    user.status = "online";
    user.lastActiveAt = Date.now();
    saveDB();
    broadcastGlobal({ type: "presence:update", userId: user.id, status: user.status });
    res.json({
      user: sanitizeUser(user),
      session: newSession
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
api.get("/auth/me", authMiddleware, (req, res) => {
  const user = req.user;
  const currentSession = req.session;
  res.json({
    user: sanitizeUser(user),
    session: currentSession
  });
});
api.post("/auth/logout", authMiddleware, (req, res) => {
  const currentSession = req.session;
  db.sessions = db.sessions.filter((s) => s.id !== currentSession.id);
  saveDB();
  res.json({ success: true, message: "Logged out successfully" });
});
api.get("/auth/sessions", authMiddleware, (req, res) => {
  const user = req.user;
  const currentSession = req.session;
  const userSessions = db.sessions.filter((s) => s.userId === user.id).map((s) => ({
    ...s,
    token: void 0,
    // do not expose session tokens
    isCurrent: s.id === currentSession.id
  }));
  res.json({ sessions: userSessions });
});
api.delete("/auth/sessions/:sessionId", authMiddleware, (req, res) => {
  const user = req.user;
  const targetId = req.params.sessionId;
  const target = db.sessions.find((s) => s.id === targetId && s.userId === user.id);
  if (!target) {
    return res.status(404).json({ error: "Session not found" });
  }
  const sockets = activeConnections.get(user.id);
  if (sockets) {
    for (const c of sockets) {
      if (c.sessionId === targetId) {
        c.ws.send(JSON.stringify({ type: "session:revoked", message: "This device session has been revoked." }));
        c.ws.close();
      }
    }
  }
  db.sessions = db.sessions.filter((s) => s.id !== targetId);
  saveDB();
  res.json({ success: true });
});
api.delete("/auth/sessions-other", authMiddleware, (req, res) => {
  const user = req.user;
  const currentSession = req.session;
  const sockets = activeConnections.get(user.id);
  if (sockets) {
    for (const c of sockets) {
      if (c.sessionId !== currentSession.id) {
        c.ws.send(JSON.stringify({ type: "session:revoked", message: "Signed out from all other devices." }));
        c.ws.close();
      }
    }
  }
  db.sessions = db.sessions.filter((s) => s.userId !== user.id || s.id === currentSession.id);
  saveDB();
  res.json({ success: true });
});
api.patch("/users/profile", authMiddleware, (req, res) => {
  const user = req.user;
  const { displayName, bio, statusMessage, avatarUrl, bannerUrl, accentColor, status } = req.body;
  if (displayName !== void 0) user.displayName = displayName.trim();
  if (bio !== void 0) user.bio = bio;
  if (statusMessage !== void 0) user.statusMessage = statusMessage;
  if (avatarUrl !== void 0) user.avatarUrl = avatarUrl;
  if (bannerUrl !== void 0) user.bannerUrl = bannerUrl;
  if (accentColor !== void 0) user.accentColor = accentColor;
  if (status !== void 0 && ["online", "idle", "dnd", "offline"].includes(status)) {
    user.status = status;
    broadcastGlobal({ type: "presence:update", userId: user.id, status });
  }
  user.lastActiveAt = Date.now();
  saveDB();
  const sanitized = sanitizeUser(user);
  broadcastGlobal({ type: "user:updated", user: sanitized });
  res.json({ user: sanitized });
});
api.patch("/users/username", authMiddleware, (req, res) => {
  const user = req.user;
  const { username } = req.body;
  if (!username) return res.status(400).json({ error: "Username is required" });
  const clean = username.trim().toLowerCase();
  if (!/^[a-z0-9_-]{3,24}$/.test(clean)) {
    return res.status(400).json({ error: "Username must be 3-24 characters containing only lowercase letters, numbers, hyphens, and underscores" });
  }
  const existing = db.users.find((u) => u.username.toLowerCase() === clean && u.id !== user.id);
  if (existing) {
    return res.status(409).json({ error: "Username is already taken" });
  }
  user.username = clean;
  saveDB();
  const sanitized = sanitizeUser(user);
  broadcastGlobal({ type: "user:updated", user: sanitized });
  res.json({ user: sanitized });
});
api.get("/users/search", authMiddleware, (req, res) => {
  const q = (req.query.q || "").toLowerCase().trim();
  const currentUserId = req.user.id;
  const results = db.users.filter((u) => u.id !== currentUserId && (u.username.toLowerCase().includes(q) || u.displayName.toLowerCase().includes(q) || u.tag.includes(q))).slice(0, 20).map(sanitizeUser);
  res.json({ users: results });
});
api.get("/friends", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const friendIds = db.friendships.filter((f) => f.userA === currentUserId || f.userB === currentUserId).map((f) => f.userA === currentUserId ? f.userB : f.userA);
  const friends = db.users.filter((u) => friendIds.includes(u.id)).map(sanitizeUser);
  const incoming = db.friendRequests.filter((r) => r.toUserId === currentUserId && r.status === "pending").map((r) => ({
    ...r,
    user: sanitizeUser(db.users.find((u) => u.id === r.fromUserId))
  }));
  const outgoing = db.friendRequests.filter((r) => r.fromUserId === currentUserId && r.status === "pending").map((r) => ({
    ...r,
    user: sanitizeUser(db.users.find((u) => u.id === r.toUserId))
  }));
  res.json({ friends, incoming, outgoing });
});
api.post("/friends/request", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const { target } = req.body;
  if (!target) return res.status(400).json({ error: "Target user is required" });
  let targetUser;
  if (target.includes("#")) {
    const [uname, tag] = target.split("#");
    targetUser = db.users.find((u) => u.username.toLowerCase() === uname.trim().toLowerCase() && u.tag === tag.trim());
  } else {
    targetUser = db.users.find((u) => u.id === target || u.username.toLowerCase() === target.trim().toLowerCase());
  }
  if (!targetUser) {
    return res.status(404).json({ error: "User not found" });
  }
  if (targetUser.id === currentUserId) {
    return res.status(400).json({ error: "You cannot add yourself as a friend" });
  }
  const alreadyFriends = db.friendships.some(
    (f) => f.userA === currentUserId && f.userB === targetUser.id || f.userA === targetUser.id && f.userB === currentUserId
  );
  if (alreadyFriends) {
    return res.status(400).json({ error: "You are already friends with this user" });
  }
  const existingReq = db.friendRequests.find(
    (r) => (r.fromUserId === currentUserId && r.toUserId === targetUser.id || r.fromUserId === targetUser.id && r.toUserId === currentUserId) && r.status === "pending"
  );
  if (existingReq) {
    if (existingReq.fromUserId === targetUser.id) {
      existingReq.status = "accepted";
      db.friendships.push({ userA: currentUserId, userB: targetUser.id, createdAt: Date.now() });
      saveDB();
      const senderSanitized = sanitizeUser(req.user);
      const targetSanitized = sanitizeUser(targetUser);
      sendToUser(targetUser.id, { type: "friend:accepted", user: senderSanitized });
      sendToUser(currentUserId, { type: "friend:accepted", user: targetSanitized });
      return res.json({ success: true, accepted: true, friend: targetSanitized });
    }
    return res.status(400).json({ error: "Friend request is already pending" });
  }
  const reqObj = {
    id: "freq_" + crypto.randomBytes(8).toString("hex"),
    fromUserId: currentUserId,
    toUserId: targetUser.id,
    status: "pending",
    createdAt: Date.now()
  };
  db.friendRequests.push(reqObj);
  saveDB();
  sendToUser(targetUser.id, {
    type: "friend:request_received",
    request: {
      ...reqObj,
      user: sanitizeUser(req.user)
    }
  });
  res.status(201).json({
    success: true,
    request: {
      ...reqObj,
      user: sanitizeUser(targetUser)
    }
  });
});
api.post("/friends/respond", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const { requestId, accept } = req.body;
  const request = db.friendRequests.find((r) => r.id === requestId && r.toUserId === currentUserId && r.status === "pending");
  if (!request) return res.status(404).json({ error: "Friend request not found or already processed" });
  if (accept) {
    request.status = "accepted";
    db.friendships.push({ userA: request.fromUserId, userB: currentUserId, createdAt: Date.now() });
    saveDB();
    const fromUser = db.users.find((u) => u.id === request.fromUserId);
    const currentUser = req.user;
    sendToUser(request.fromUserId, { type: "friend:accepted", user: sanitizeUser(currentUser) });
    sendToUser(currentUserId, { type: "friend:accepted", user: sanitizeUser(fromUser) });
    res.json({ success: true, accepted: true, friend: sanitizeUser(fromUser) });
  } else {
    request.status = "rejected";
    saveDB();
    sendToUser(request.fromUserId, { type: "friend:rejected", requestId });
    res.json({ success: true, accepted: false });
  }
});
api.delete("/friends/cancel/:requestId", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const reqId = req.params.requestId;
  const request = db.friendRequests.find((r) => r.id === reqId && r.fromUserId === currentUserId);
  if (!request) return res.status(404).json({ error: "Request not found" });
  db.friendRequests = db.friendRequests.filter((r) => r.id !== reqId);
  saveDB();
  sendToUser(request.toUserId, { type: "friend:request_cancelled", requestId: reqId });
  res.json({ success: true });
});
api.delete("/friends/:friendId", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const friendId = req.params.friendId;
  db.friendships = db.friendships.filter(
    (f) => !(f.userA === currentUserId && f.userB === friendId || f.userA === friendId && f.userB === currentUserId)
  );
  saveDB();
  sendToUser(friendId, { type: "friend:removed", userId: currentUserId });
  sendToUser(currentUserId, { type: "friend:removed", userId: friendId });
  res.json({ success: true });
});
api.get("/dms", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const userDms = db.dmChannels.filter((d) => d.participantIds.includes(currentUserId));
  const list = userDms.map((d) => {
    const otherUserId = d.participantIds.find((p) => p !== currentUserId) || currentUserId;
    const otherUser = db.users.find((u) => u.id === otherUserId);
    const lastMsg = db.messages.filter((m) => m.conversationId === d.id).sort((a, b) => b.createdAt - a.createdAt)[0];
    return {
      id: d.id,
      participant: otherUser ? sanitizeUser(otherUser) : null,
      lastMessage: lastMsg || null,
      lastMessageAt: d.lastMessageAt || d.createdAt
    };
  }).sort((a, b) => b.lastMessageAt - a.lastMessageAt);
  res.json({ dms: list });
});
api.post("/dms/open", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const { targetUserId } = req.body;
  if (!targetUserId) return res.status(400).json({ error: "targetUserId is required" });
  const targetUser = db.users.find((u) => u.id === targetUserId);
  if (!targetUser) return res.status(404).json({ error: "Target user not found" });
  let dm = db.dmChannels.find(
    (d) => d.participantIds.length === 2 && d.participantIds.includes(currentUserId) && d.participantIds.includes(targetUserId)
  );
  if (!dm) {
    dm = {
      id: "dm_" + crypto.randomBytes(8).toString("hex"),
      participantIds: [currentUserId, targetUserId],
      createdAt: Date.now(),
      lastMessageAt: Date.now()
    };
    db.dmChannels.push(dm);
    saveDB();
  }
  res.json({
    dmId: dm.id,
    participant: sanitizeUser(targetUser)
  });
});
api.get("/dms/:channelId/messages", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const channelId = req.params.channelId;
  const dm = db.dmChannels.find((d) => d.id === channelId);
  if (!dm || !dm.participantIds.includes(currentUserId)) {
    return res.status(403).json({ error: "Access denied" });
  }
  const msgs = db.messages.filter((m) => m.conversationId === channelId).sort((a, b) => a.createdAt - b.createdAt);
  res.json({ messages: msgs });
});
api.post("/dms/:channelId/messages", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const channelId = req.params.channelId;
  const { content, attachments, replyToId } = req.body;
  const dm = db.dmChannels.find((d) => d.id === channelId);
  if (!dm || !dm.participantIds.includes(currentUserId)) {
    return res.status(403).json({ error: "Access denied" });
  }
  if (!content && (!attachments || attachments.length === 0)) {
    return res.status(400).json({ error: "Message cannot be empty" });
  }
  let replyToMessage;
  if (replyToId) {
    const original = db.messages.find((m) => m.id === replyToId);
    if (original) {
      const sender = db.users.find((u) => u.id === original.senderId);
      replyToMessage = {
        id: original.id,
        senderId: original.senderId,
        senderName: sender?.displayName || "Unknown",
        content: original.content
      };
    }
  }
  const newMsg = {
    id: "msg_" + crypto.randomBytes(8).toString("hex"),
    conversationId: channelId,
    senderId: currentUserId,
    content: (content || "").trim(),
    attachments: attachments || [],
    reactions: [],
    replyToId,
    replyToMessage,
    createdAt: Date.now()
  };
  db.messages.push(newMsg);
  dm.lastMessageAt = newMsg.createdAt;
  saveDB();
  broadcastToUsers(dm.participantIds, {
    type: "chat:message",
    message: newMsg,
    conversationId: channelId,
    conversationType: "dm"
  });
  res.status(201).json({ message: newMsg });
});
api.get("/communities", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const memberships = db.communityMembers.filter((m) => m.userId === currentUserId);
  const communityIds = memberships.map((m) => m.communityId);
  const userCommunities = db.communities.filter((c) => communityIds.includes(c.id));
  res.json({ communities: userCommunities });
});
api.post("/communities", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const { name, description, iconUrl } = req.body;
  if (!name || name.trim().length === 0) {
    return res.status(400).json({ error: "Community name is required" });
  }
  const communityId = "comm_" + crypto.randomBytes(8).toString("hex");
  const generalChannel = {
    id: "chan_" + crypto.randomBytes(8).toString("hex"),
    communityId,
    name: "general",
    topic: "Main channel for communication",
    type: "text",
    position: 0,
    createdAt: Date.now()
  };
  const voiceChannel = {
    id: "chan_" + crypto.randomBytes(8).toString("hex"),
    communityId,
    name: "Voice Lounge",
    topic: "Drop-in real-time voice & screen share",
    type: "voice",
    position: 1,
    createdAt: Date.now()
  };
  const inviteCode = "NEXUS-" + crypto.randomBytes(3).toString("hex").toUpperCase();
  const newCommunity = {
    id: communityId,
    name: name.trim(),
    description: description?.trim() || "A new futuristic hub in the NEXUS network.",
    iconUrl: iconUrl || void 0,
    ownerId: currentUserId,
    inviteCode,
    channels: [generalChannel, voiceChannel],
    createdAt: Date.now()
  };
  db.communities.push(newCommunity);
  db.communityMembers.push({
    userId: currentUserId,
    communityId,
    role: "owner",
    joinedAt: Date.now()
  });
  saveDB();
  res.status(201).json({ community: newCommunity });
});
api.get("/communities/:communityId", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const communityId = req.params.communityId;
  const community = db.communities.find((c) => c.id === communityId);
  if (!community) return res.status(404).json({ error: "Community not found" });
  const isMember = db.communityMembers.some((m) => m.communityId === communityId && m.userId === currentUserId);
  if (!isMember) return res.status(403).json({ error: "You are not a member of this community" });
  const memberRecords = db.communityMembers.filter((m) => m.communityId === communityId);
  const members = memberRecords.map((m) => {
    const user = db.users.find((u) => u.id === m.userId);
    return {
      ...m,
      user: user ? sanitizeUser(user) : null
    };
  }).filter((m) => m.user !== null);
  res.json({ community, members });
});
api.post("/communities/:communityId/channels", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const communityId = req.params.communityId;
  const { name, topic, type } = req.body;
  const community = db.communities.find((c) => c.id === communityId);
  if (!community) return res.status(404).json({ error: "Community not found" });
  const member = db.communityMembers.find((m) => m.communityId === communityId && m.userId === currentUserId);
  if (!member || member.role !== "owner" && member.role !== "admin") {
    return res.status(403).json({ error: "Only admins or the owner can create channels" });
  }
  const cleanName = name.trim().toLowerCase().replace(/\s+/g, "-");
  const channel = {
    id: "chan_" + crypto.randomBytes(8).toString("hex"),
    communityId,
    name: cleanName,
    topic: topic?.trim() || "",
    type: type === "voice" ? "voice" : "text",
    position: community.channels.length,
    createdAt: Date.now()
  };
  community.channels.push(channel);
  saveDB();
  const memberUserIds = db.communityMembers.filter((m) => m.communityId === communityId).map((m) => m.userId);
  broadcastToUsers(memberUserIds, {
    type: "community:channel_created",
    communityId,
    channel
  });
  res.status(201).json({ channel });
});
api.post("/communities/join", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const { inviteCode } = req.body;
  if (!inviteCode) return res.status(400).json({ error: "Invite code is required" });
  const cleanCode = inviteCode.trim().toUpperCase();
  const community = db.communities.find((c) => c.inviteCode.toUpperCase() === cleanCode);
  if (!community) {
    return res.status(404).json({ error: "Invalid or expired invite code" });
  }
  const isMember = db.communityMembers.some((m) => m.communityId === community.id && m.userId === currentUserId);
  if (isMember) {
    return res.json({ message: "Already a member", community });
  }
  db.communityMembers.push({
    userId: currentUserId,
    communityId: community.id,
    role: "member",
    joinedAt: Date.now()
  });
  saveDB();
  const user = db.users.find((u) => u.id === currentUserId);
  const memberUserIds = db.communityMembers.filter((m) => m.communityId === community.id).map((m) => m.userId);
  broadcastToUsers(memberUserIds, {
    type: "community:member_joined",
    communityId: community.id,
    member: {
      userId: currentUserId,
      communityId: community.id,
      role: "member",
      joinedAt: Date.now(),
      user: sanitizeUser(user)
    }
  });
  res.json({ success: true, community });
});
api.post("/communities/:communityId/leave", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const communityId = req.params.communityId;
  const community = db.communities.find((c) => c.id === communityId);
  if (!community) return res.status(404).json({ error: "Community not found" });
  if (community.ownerId === currentUserId) {
    return res.status(400).json({ error: "Community owner cannot leave without transferring ownership" });
  }
  db.communityMembers = db.communityMembers.filter((m) => !(m.communityId === communityId && m.userId === currentUserId));
  saveDB();
  const memberUserIds = db.communityMembers.filter((m) => m.communityId === communityId).map((m) => m.userId);
  broadcastToUsers(memberUserIds, {
    type: "community:member_left",
    communityId,
    userId: currentUserId
  });
  res.json({ success: true });
});
api.get("/channels/:channelId/messages", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const channelId = req.params.channelId;
  let targetCommunity;
  for (const c of db.communities) {
    if (c.channels.some((ch) => ch.id === channelId)) {
      targetCommunity = c;
      break;
    }
  }
  if (!targetCommunity) return res.status(404).json({ error: "Channel not found" });
  const isMember = db.communityMembers.some((m) => m.communityId === targetCommunity.id && m.userId === currentUserId);
  if (!isMember) return res.status(403).json({ error: "Access denied" });
  const msgs = db.messages.filter((m) => m.conversationId === channelId).sort((a, b) => a.createdAt - b.createdAt);
  res.json({ messages: msgs });
});
api.post("/channels/:channelId/messages", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const channelId = req.params.channelId;
  const { content, attachments, replyToId } = req.body;
  let targetCommunity;
  for (const c of db.communities) {
    if (c.channels.some((ch) => ch.id === channelId)) {
      targetCommunity = c;
      break;
    }
  }
  if (!targetCommunity) return res.status(404).json({ error: "Channel not found" });
  const isMember = db.communityMembers.some((m) => m.communityId === targetCommunity.id && m.userId === currentUserId);
  if (!isMember) return res.status(403).json({ error: "Access denied" });
  if (!content && (!attachments || attachments.length === 0)) {
    return res.status(400).json({ error: "Message cannot be empty" });
  }
  let replyToMessage;
  if (replyToId) {
    const original = db.messages.find((m) => m.id === replyToId);
    if (original) {
      const sender = db.users.find((u) => u.id === original.senderId);
      replyToMessage = {
        id: original.id,
        senderId: original.senderId,
        senderName: sender?.displayName || "Unknown",
        content: original.content
      };
    }
  }
  const newMsg = {
    id: "msg_" + crypto.randomBytes(8).toString("hex"),
    conversationId: channelId,
    senderId: currentUserId,
    content: (content || "").trim(),
    attachments: attachments || [],
    reactions: [],
    replyToId,
    replyToMessage,
    createdAt: Date.now()
  };
  db.messages.push(newMsg);
  saveDB();
  const memberUserIds = db.communityMembers.filter((m) => m.communityId === targetCommunity.id).map((m) => m.userId);
  broadcastToUsers(memberUserIds, {
    type: "chat:message",
    message: newMsg,
    conversationId: channelId,
    communityId: targetCommunity.id,
    conversationType: "channel"
  });
  res.status(201).json({ message: newMsg });
});
api.delete("/messages/:messageId", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const messageId = req.params.messageId;
  const msg = db.messages.find((m) => m.id === messageId);
  if (!msg) return res.status(404).json({ error: "Message not found" });
  if (msg.senderId !== currentUserId) {
    return res.status(403).json({ error: "You can only delete your own messages" });
  }
  db.messages = db.messages.filter((m) => m.id !== messageId);
  saveDB();
  broadcastGlobal({
    type: "chat:message_deleted",
    messageId,
    conversationId: msg.conversationId
  });
  res.json({ success: true });
});
api.patch("/messages/:messageId", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const messageId = req.params.messageId;
  const { content } = req.body;
  const msg = db.messages.find((m) => m.id === messageId);
  if (!msg) return res.status(404).json({ error: "Message not found" });
  if (msg.senderId !== currentUserId) {
    return res.status(403).json({ error: "You can only edit your own messages" });
  }
  if (!content || !content.trim()) {
    return res.status(400).json({ error: "Content cannot be empty" });
  }
  msg.content = content.trim();
  msg.editedAt = Date.now();
  saveDB();
  broadcastGlobal({
    type: "chat:message_edited",
    message: msg,
    conversationId: msg.conversationId
  });
  res.json({ message: msg });
});
api.post("/messages/:messageId/react", authMiddleware, (req, res) => {
  const currentUserId = req.user.id;
  const messageId = req.params.messageId;
  const { emoji } = req.body;
  if (!emoji) return res.status(400).json({ error: "Emoji is required" });
  const msg = db.messages.find((m) => m.id === messageId);
  if (!msg) return res.status(404).json({ error: "Message not found" });
  if (!msg.reactions) msg.reactions = [];
  const existingReaction = msg.reactions.find((r) => r.emoji === emoji);
  if (existingReaction) {
    if (existingReaction.userIds.includes(currentUserId)) {
      existingReaction.userIds = existingReaction.userIds.filter((id) => id !== currentUserId);
      existingReaction.count = existingReaction.userIds.length;
      if (existingReaction.count === 0) {
        msg.reactions = msg.reactions.filter((r) => r.emoji !== emoji);
      }
    } else {
      existingReaction.userIds.push(currentUserId);
      existingReaction.count = existingReaction.userIds.length;
    }
  } else {
    msg.reactions.push({
      emoji,
      count: 1,
      userIds: [currentUserId]
    });
  }
  saveDB();
  broadcastGlobal({
    type: "chat:reaction_updated",
    messageId,
    conversationId: msg.conversationId,
    reactions: msg.reactions
  });
  res.json({ reactions: msg.reactions });
});
api.post("/upload", authMiddleware, (req, res) => {
  try {
    const { name, size, type, data } = req.body;
    if (!data) return res.status(400).json({ error: "No data provided" });
    if (size && size > 15 * 1024 * 1024) {
      return res.status(400).json({ error: "File size exceeds maximum 15MB limit" });
    }
    const attachmentId = "att_" + crypto.randomBytes(8).toString("hex");
    res.json({
      attachment: {
        id: attachmentId,
        name: name || "file",
        size: size || 0,
        type: type || "application/octet-stream",
        url: data
        // Direct base64 data URL
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
api.get("/download/project-zip", async (req, res) => {
  try {
    const zipPath = path.resolve(process.cwd(), "nexus-windows-app.zip");
    if (!fs.existsSync(zipPath)) {
      try {
        const { execSync } = await import("child_process");
        execSync("python3 create_zip.py");
      } catch (pyErr) {
        console.warn("python3 not available, checking python:", pyErr);
        try {
          const { execSync } = await import("child_process");
          execSync("python create_zip.py");
        } catch (e) {
          console.warn("python not available, using existing archive if present");
        }
      }
    }
    if (fs.existsSync(zipPath)) {
      const stat = fs.statSync(zipPath);
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", 'attachment; filename="nexus-windows-app.zip"');
      res.setHeader("Content-Length", stat.size);
      const stream = fs.createReadStream(zipPath);
      stream.pipe(res);
    } else {
      res.status(500).json({ error: "Archive not found. Please run: python create_zip.py or python3 create_zip.py" });
    }
  } catch (err) {
    console.error("Error generating project ZIP:", err);
    res.status(500).json({ error: "Failed to generate ZIP archive: " + err.message });
  }
});
app.use("/api", api);
async function startServer() {
  const distPath = path.resolve(process.cwd(), "dist");
  const hasDist = fs.existsSync(path.join(distPath, "index.html"));
  const isAiStudio = Boolean(process.env.CONTROL_PLANE_PORT || process.env.AI_STUDIO_APPLET_ID);
  const shouldServeStatic = hasDist && (!isAiStudio || process.env.NODE_ENV === "production");
  if (!shouldServeStatic) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
    app.use("*", async (req, res, next) => {
      const url = req.originalUrl;
      if (url.startsWith("/api") || url.startsWith("/ws")) {
        return next();
      }
      try {
        const indexPath = path.resolve(process.cwd(), "index.html");
        if (!fs.existsSync(indexPath)) {
          return res.status(404).send("index.html not found");
        }
        let template = fs.readFileSync(indexPath, "utf-8");
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ "Content-Type": "text/html" }).end(template);
      } catch (e) {
        if (vite) vite.ssrFixStacktrace(e);
        console.error("[Vite HTML Transform Error]", e);
        next(e);
      }
    });
  } else {
    console.log("[NEXUS Server] Serving pre-compiled production build from ./dist");
    app.use(express.static(distPath));
    app.use("*", (req, res, next) => {
      if (req.originalUrl.startsWith("/api") || req.originalUrl.startsWith("/ws")) {
        return next();
      }
      res.sendFile(path.join(distPath, "index.html"));
    });
  }
  server.listen(PORT, "0.0.0.0", () => {
    console.log(`
======================================================`);
    console.log(`\u{1F7E2} [NEXUS Server] READY AND LISTENING!`);
    console.log(`\u{1F449} Web Client:      http://localhost:${PORT}`);
    console.log(`\u{1F449} WebSocket Mesh:  ws://localhost:${PORT}/ws`);
    console.log(`\u{1F449} Status:          Ready for connections!`);
    console.log(`======================================================
`);
  });
}
startServer().catch((err) => {
  console.error("[NEXUS Server] Failed to start:", err);
  process.exit(1);
});
