@echo off
title NEXUS - Next-Gen Cross-Platform Launcher
color 0A

:: Ensure script runs in its own directory, even if "Run as Administrator" is used
cd /d "%~dp0"

echo ===================================================================
echo     NEXUS - Next-Gen Cross-Platform Communication Platform
echo ===================================================================
echo.

:: Check if package.json exists in this folder
if exist "%~dp0package.json" goto FOUND_PACKAGE
if exist "%~dp0nexus-windows-app\package.json" (
    cd /d "%~dp0nexus-windows-app"
    goto FOUND_PACKAGE
)
if exist "%~dp0..\package.json" (
    cd /d "%~dp0.."
    goto FOUND_PACKAGE
)

:: If not found, user opened script directly inside an unextracted zip
color 0C
echo [!] ATTENTION: ZIP FILE NOT EXTRACTED!
echo.
echo You opened run-windows.bat directly inside the ZIP file without extracting.
echo Windows cannot run Node.js or npm inside an unextracted zip preview.
echo.
echo -------------------------------------------------------------------
echo HOW TO RUN IN 3 EASY STEPS:
echo -------------------------------------------------------------------
echo 1. Close this window.
echo 2. Right-click your "nexus-windows-app.zip" file.
echo 3. Click "Extract All...", then click "Extract".
echo 4. Open the extracted folder and double-click "run-windows.bat" again!
echo.
echo -------------------------------------------------------------------
echo OR DOUBLE-CLICK "START-HERE.html" TO LAUNCH IN YOUR BROWSER!
echo -------------------------------------------------------------------
echo.
pause
goto END

:FOUND_PACKAGE
echo [*] Project folder detected at: %CD%
echo.

:: Check Node.js
where node >nul 2>nul
if %ERRORLEVEL% equ 0 goto NODE_READY

:: Check standard Windows Node.js installation paths
if exist "%ProgramFiles%\nodejs\node.exe" (
    set "PATH=%ProgramFiles%\nodejs;%PATH%"
    goto NODE_READY
)
if exist "%ProgramFiles(x86)%\nodejs\node.exe" (
    set "PATH=%ProgramFiles(x86)%\nodejs;%PATH%"
    goto NODE_READY
)
if exist "%LOCALAPPDATA%\Programs\node\node.exe" (
    set "PATH=%LOCALAPPDATA%\Programs\node;%PATH%"
    goto NODE_READY
)

:: Node.js is not installed
color 0C
echo ===================================================================
echo   [!] Node.js is NOT installed on this computer!
echo ===================================================================
echo.
echo   To run the local NEXUS server on your PC, Node.js is required.
echo.
echo   1. Download Node.js (LTS recommended) from: https://nodejs.org
echo   2. Run the installer and finish setup.
echo   3. Double-click run-windows.bat again!
echo.
echo ===================================================================
echo.
echo Press any key to open https://nodejs.org in your browser, or close this window.
pause >nul
start https://nodejs.org
goto END

:NODE_READY
color 0A
for /f "tokens=*" %%v in ('node -v 2^>nul') do set "NODE_VERSION=%%v"
echo [*] Node.js version detected: %NODE_VERSION%
echo.

:: Check if node_modules exists
if exist "node_modules\express\" goto DEPENDENCIES_READY
if exist "node_modules\tsx\" goto DEPENDENCIES_READY

echo [*] Installing dependencies (first run only, takes ~1 minute)...
echo [*] Using --legacy-peer-deps to prevent peer dependency conflicts...
echo.
call npm install --legacy-peer-deps

if %ERRORLEVEL% neq 0 (
    echo.
    echo [*] Retrying with --force...
    call npm install --force
)

:DEPENDENCIES_READY
echo.
echo ===================================================================
echo   [SUCCESS] Starting NEXUS Server at: http://localhost:3000
echo ===================================================================
echo.
echo   Opening http://localhost:3000 in your browser automatically...
echo   Keep this black window OPEN while using NEXUS!
echo.
echo   To stop the server at any time, press Ctrl+C or close this window.
echo ===================================================================
echo.

:: Launch browser in background after 2 seconds
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:3000"

:: Start the server using high-speed compiled server.js (zero bundling delay)
if exist "%~dp0server.js" (
    echo [*] Running NEXUS High-Speed Server (zero bundling delay)...
    node "%~dp0server.js"
) else if exist "server.js" (
    echo [*] Running NEXUS High-Speed Server (zero bundling delay)...
    node server.js
) else (
    echo [*] Running NEXUS Development Server...
    call npm run dev
)

echo.
echo ===================================================================
echo   NEXUS Server stopped.
echo ===================================================================
pause

:END
exit /b 0
